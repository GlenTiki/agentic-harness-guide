# Chapter 04: Reference walker

## Purpose

This chapter checks deep references. A link can be valid while the page it reaches no longer says what the link claims. The walker follows links from a root document and checks each one.

## Limits

The config file sets three limits.

1. `max_depth` is the number of links the walker follows from the root. The root has depth 0.
2. `max_path_length` is the longest allowed path to a document, in characters.
3. `max_files` is the largest number of documents the walker opens.

The walker stops at each limit and prints a note. The walker rejects an unknown config key. It rejects a negative number.

## Loop prevention

The walker keeps a set of visited documents. It opens each document once. The walker reads documents in order of depth, so the shortest path to a document sets its depth. When a link returns to a document on the current chain, the walker prints a cycle note and does not follow it.

## Checks on each link

1. The target file exists.
2. The anchor exists, when the link has one.
3. A judge says the target text supports the sentence that holds the link.

The first two are errors when they fail. A failed judge check is an error too.

## The judge

The judge is an interface with one method. It takes a claim and a source text. It returns a verdict and a reason.

This kit ships two judges. The lexical judge counts shared content words. It is deterministic and it is not a language model. It gives false alarms and false passes. The command judge runs a program that you supply. That program can call a language model. This kit contains no code for network calls and no model.

## What the tests prove

The tests use only the lexical judge and the command judge with a stub program. The tests prove the walking, the limits and the loop prevention. They do not prove that a language model judges well.

## Proof that the check can fail

The folder `fixtures/bad` holds a missing file, a missing anchor and two claims that the target does not support. The walker must report errors on it.
