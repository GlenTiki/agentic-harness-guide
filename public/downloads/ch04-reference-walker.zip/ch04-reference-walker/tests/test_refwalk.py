import json
import sys
import tempfile
import unittest
from pathlib import Path

import refwalk

HERE = Path(__file__).resolve().parent.parent
CONFIG = {"max_depth": 3, "max_path_length": 120, "max_files": 50}


class WalkTest(unittest.TestCase):
    def walk(self, files, config=None, judge=None):
        with tempfile.TemporaryDirectory() as tmp:
            for name, body in files.items():
                path = Path(tmp) / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(body, encoding="utf-8")
            findings, opened = refwalk.walk(Path(tmp) / "root.md", tmp, {**CONFIG, **(config or {})}, judge)
            return sorted((f.rule, f.is_error) for f in findings), opened

    def test_clean_chain(self):
        self.assertEqual(self.walk({"root.md": "[a](a.md)", "a.md": "x"}), ([], 2))

    def test_missing_file_and_anchor_are_errors(self):
        findings, _ = self.walk({"root.md": "[a](a.md#nope) [b](b.md)", "a.md": "# Yes\n"})
        self.assertEqual(findings, [("missing-anchor", True), ("missing-file", True)])

    def test_cycle_terminates_and_is_a_note(self):
        findings, opened = self.walk({"root.md": "[a](a.md)", "a.md": "[r](root.md)"})
        self.assertEqual((findings, opened), ([("cycle", False)], 2))

    def test_self_link_terminates(self):
        self.assertEqual(self.walk({"root.md": "[me](root.md)"}), ([("cycle", False)], 1))

    def test_visited_set_opens_each_file_once(self):
        files = {"root.md": "[a](a.md) [b](b.md)", "a.md": "[c](c.md)", "b.md": "[c](c.md)", "c.md": "x"}
        self.assertEqual(self.walk(files), ([], 4))

    def test_depth_limit_stops_the_walk(self):
        files = {"root.md": "[a](a.md)", "a.md": "[b](b.md)", "b.md": "[c](c.md)", "c.md": "x"}
        findings, opened = self.walk(files, {"max_depth": 2})
        self.assertEqual((findings, opened), ([("depth-limit", False)], 3))

    def test_depth_zero_follows_nothing(self):
        self.assertEqual(self.walk({"root.md": "[a](a.md)", "a.md": "x"}, {"max_depth": 0}), ([("depth-limit", False)], 1))

    def test_shortest_path_wins_the_depth_limit(self):
        files = {"root.md": "[a](a.md) [c](c.md)", "a.md": "[b](b.md)", "b.md": "[c](c.md)", "c.md": "[d](d.md)",
                 "d.md": "x"}
        findings, opened = self.walk(files, {"max_depth": 2})
        self.assertEqual((findings, opened), ([], 5))

    def test_path_length_limit(self):
        files = {"root.md": "[a](sub/a.md)", "sub/a.md": "x"}
        findings, _ = self.walk(files, {"max_path_length": 5})
        self.assertEqual(findings, [("path-too-long", True)])

    def test_file_limit(self):
        files = {"root.md": "[a](a.md)", "a.md": "[b](b.md)", "b.md": "x"}
        findings, opened = self.walk(files, {"max_files": 2})
        self.assertEqual((findings, opened), ([("file-limit", True)], 2))

    def test_images_external_and_non_markdown_links_are_ignored(self):
        self.assertEqual(self.walk({"root.md": "![i](i.png) [x](https://e.org/a.md) [t](t.txt)"}), ([], 1))


class ConfigTest(unittest.TestCase):
    def write(self, data):
        handle = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
        handle.write(json.dumps(data))
        handle.close()
        self.addCleanup(Path(handle.name).unlink)
        return handle.name

    def test_defaults(self):
        self.assertEqual(refwalk.load_config(None), refwalk.DEFAULTS)

    def test_unknown_key_fails_fast(self):
        with self.assertRaises(ValueError):
            refwalk.load_config(self.write({"max_dept": 3}))

    def test_negative_value_fails_fast(self):
        with self.assertRaises(ValueError):
            refwalk.load_config(self.write({"max_depth": -1}))


class JudgeTest(unittest.TestCase):
    def test_lexical_judge_is_deterministic(self):
        judge = refwalk.LexicalJudge()
        results = {judge.judge("The tool writes the time stamp", "It writes a time stamp") for _ in range(5)}
        self.assertEqual(len(results), 1)

    def test_lexical_judge_rejects_unrelated_text(self):
        self.assertFalse(refwalk.LexicalJudge().judge("Notes use quantum encryption", "A tab and a stamp").supported)

    def test_section_text_stops_at_next_heading_of_same_level(self):
        text = "# T\n\n## A\n\nalpha\n\n### Sub\n\nbeta\n\n## B\n\ngamma\n"
        section = refwalk.section_text(text, "a")
        self.assertIn("alpha", section)
        self.assertIn("beta", section)
        self.assertNotIn("gamma", section)

    def test_claim_is_the_sentence_with_the_link(self):
        line = "First sentence. The [format](a.md#f) is a tab line. Last."
        self.assertEqual(refwalk.claim_for(line, "a.md#f"), "The format is a tab line.")

    def test_command_judge_plugs_in_through_a_subprocess(self):
        code = ("import json,sys; d=json.load(sys.stdin); "
                "print(json.dumps({'supported': 'yes' in d['source'], 'reason': 'stub'}))")
        judge = refwalk.CommandJudge([sys.executable, "-I", "-c", code])
        self.assertTrue(judge.judge("c", "yes").supported)
        self.assertFalse(judge.judge("c", "no").supported)

    def test_command_judge_failure_raises(self):
        with self.assertRaises(RuntimeError):
            refwalk.CommandJudge([sys.executable, "-I", "-c", "raise SystemExit(3)"]).judge("c", "s")


class FixtureTest(unittest.TestCase):
    def run_fixture(self, root, config):
        findings, _ = refwalk.walk(HERE / root, (HERE / root).parent, refwalk.load_config(HERE / config),
                                   refwalk.LexicalJudge())
        return sorted({f.rule for f in findings if f.is_error})

    def test_example_has_no_errors(self):
        self.assertEqual(self.run_fixture("example/root.md", "example/refwalk.json"), [])

    def test_bad_fixture_has_every_error_kind(self):
        self.assertEqual(self.run_fixture("fixtures/bad/root.md", "fixtures/bad/refwalk.json"),
                         ["missing-anchor", "missing-file", "unsupported-claim"])


if __name__ == "__main__":
    unittest.main()
