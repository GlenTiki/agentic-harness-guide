"""Walk the references from a root markdown document, with hard limits, and check each one.

Limits (all in the config file):
  max_depth        how many hops from the root the walker follows (the root is depth 0)
  max_path_length  the longest allowed length, in characters, of a document path relative to the root folder
  max_files        the most documents the walker will open
Safety: a visited set stops loops. The walker never fetches anything from the network.

Model-assisted check: pass a judge. A judge answers "does this target text support the claim made in the
sentence that holds the link?". The judge is an interface. The tests use a deterministic stand-in
(LexicalJudge) that is NOT a language model. CommandJudge sends the question to a command you supply.
"""
import argparse
import json
import re
import subprocess
import sys
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import unquote

sys.path.insert(0, str(Path(__file__).resolve().parent))  # python -I does not add the script folder
import linkcheck  # noqa: E402

DEFAULTS = {"max_depth": 3, "max_path_length": 120, "max_files": 200}
STOPWORDS = frozenset("the and for that with this from have has are was were not but its into when then than "
                      "each only will must can may all any one two use used uses".split())


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    message: str
    is_error: bool

    def __str__(self):
        kind = "error" if self.is_error else "note"
        return f"{self.path}:{self.line}: [{self.rule}] {kind}: {self.message}"


@dataclass(frozen=True)
class Verdict:
    supported: bool
    reason: str


def load_config(path):
    config = dict(DEFAULTS)
    if path:
        loaded = json.loads(Path(path).read_text(encoding="utf-8"))
        unknown = set(loaded) - set(DEFAULTS)
        if unknown:
            raise ValueError(f"Unknown config key(s): {sorted(unknown)}")
        config.update(loaded)
    for key, value in config.items():
        if not isinstance(value, int) or value < 0:
            raise ValueError(f"Config key {key} must be a whole number of 0 or more.")
    return config


def content_words(text):
    return {w for w in re.findall(r"[a-z]{4,}", text.lower()) if w not in STOPWORDS}


class LexicalJudge:
    """A deterministic stand-in. It passes a claim when enough of its content words appear in the source."""

    def __init__(self, threshold=0.5):
        self.threshold = threshold

    def judge(self, claim, source):
        wanted = content_words(claim)
        if not wanted:
            return Verdict(True, "The claim has no content words to check.")
        found = wanted & content_words(source)
        ratio = len(found) / len(wanted)
        return Verdict(ratio >= self.threshold, f"{len(found)} of {len(wanted)} content words found.")


class CommandJudge:
    """Run a command. It reads {"claim", "source"} as JSON on stdin and prints {"supported", "reason"}.

    Whatever the command does (call a model, call nothing) is its own business. This class adds no network code.
    """

    def __init__(self, argv, timeout=60):
        self.argv = argv
        self.timeout = timeout

    def judge(self, claim, source):
        done = subprocess.run(self.argv, input=json.dumps({"claim": claim, "source": source}), text=True,
                              capture_output=True, timeout=self.timeout)
        if done.returncode != 0:
            raise RuntimeError(f"The judge command failed with exit code {done.returncode}.")
        answer = json.loads(done.stdout)
        return Verdict(bool(answer["supported"]), str(answer.get("reason", "")))


def section_text(text, anchor):
    """Return the text under the heading that makes this anchor, or the whole text when anchor is empty."""
    if not anchor:
        return text
    seen, lines, start, level = {}, text.splitlines(), None, 0
    in_code = {number: flag for number, _, flag in linkcheck.content_lines(text)}
    for index, line in enumerate(lines):
        if in_code.get(index + 1):
            continue
        match = linkcheck.ATX_HEADING.match(line)
        if not match:
            continue
        slug = linkcheck.github_slug(match.group(2))
        count = seen.get(slug, 0)
        seen[slug] = count + 1
        slug = slug if count == 0 else f"{slug}-{count}"
        if start is None and slug == anchor:
            start, level = index + 1, len(match.group(1))
        elif start is not None and len(match.group(1)) <= level:
            return "\n".join(lines[start:index])
    return "\n".join(lines[start:]) if start is not None else text


def claim_for(line_text, raw_target):
    """Return the sentence of the line that holds the link, with link markup reduced to its text."""
    for sentence in re.split(r"(?<=[.!?])\s+", line_text):
        if f"]({raw_target}" in sentence:
            return re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", sentence).strip()
    return re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", line_text).strip()


def walk(root_file, root_dir, config, judge=None):
    root_file, root_dir = Path(root_file).resolve(), Path(root_dir).resolve()
    findings, parent, depth = [], {root_file: None}, {root_file: 0}
    queue, opened = deque([root_file]), 0

    def show(path):
        try:
            return str(path.relative_to(root_dir))
        except ValueError:
            return str(path)

    def add(source, line, rule, message, is_error):
        findings.append(Finding(show(source), line, rule, message, is_error))

    def ancestors(path):
        while path is not None:
            yield path
            path = parent[path]

    while queue:
        source = queue.popleft()
        if opened >= config["max_files"]:
            add(source, 1, "file-limit", f"Stopped after {opened} documents (max_files).", True)
            break
        opened += 1
        text = source.read_text(encoding="utf-8")
        lines = text.splitlines()
        for number, is_image, raw in linkcheck.extract_links(text):
            target = unquote(raw[1:-1] if raw.startswith("<") else raw)
            path_part, _, anchor = target.partition("#")
            if is_image or not path_part or linkcheck.SCHEME.match(target) or not path_part.endswith(".md"):
                continue
            resolved = (source.parent / path_part).resolve()
            if len(show(resolved)) > config["max_path_length"]:
                add(source, number, "path-too-long", f"The path '{path_part}' is too long.", True)
                continue
            if not resolved.is_file():
                add(source, number, "missing-file", f"'{path_part}' does not exist.", True)
                continue
            target_text = resolved.read_text(encoding="utf-8")
            if anchor and anchor not in linkcheck.anchors_of(target_text):
                add(source, number, "missing-anchor", f"'{path_part}' has no heading for '#{anchor}'.", True)
                continue
            if depth[source] >= config["max_depth"] and resolved not in depth:
                add(source, number, "depth-limit", f"'{path_part}' is beyond max_depth and was not followed.", False)
                continue
            if judge:
                claim = claim_for(lines[number - 1], raw)
                verdict = judge.judge(claim, section_text(target_text, anchor))
                if not verdict.supported:
                    add(source, number, "unsupported-claim", f"'{path_part}' does not support: {claim} ({verdict.reason})", True)
            if resolved in depth:
                rule = "cycle" if resolved in set(ancestors(source)) else "already-visited"
                if rule == "cycle":
                    add(source, number, "cycle", f"'{path_part}' is an ancestor on the current chain; not followed again.", False)
                continue
            depth[resolved], parent[resolved] = depth[source] + 1, source
            queue.append(resolved)
    return findings, opened


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("root_file")
    parser.add_argument("--config")
    parser.add_argument("--root-dir", default=None, help="folder used to show paths; default is the folder of the root file")
    parser.add_argument("--judge", choices=["none", "lexical"], default="none")
    parser.add_argument("--judge-command", help="a command (split on spaces) that answers the judge question")
    args = parser.parse_args(argv)
    config = load_config(args.config)
    judge = None
    if args.judge_command:
        judge = CommandJudge(args.judge_command.split())
    elif args.judge == "lexical":
        judge = LexicalJudge()
    root_dir = args.root_dir or Path(args.root_file).resolve().parent
    findings, opened = walk(args.root_file, root_dir, config, judge)
    for finding in findings:
        print(finding)
    errors = sum(f.is_error for f in findings)
    print(f"refwalk: opened {opened} document(s); {errors} error(s); {len(findings) - errors} note(s)")
    return 1 if errors else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"refwalk: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
