# Chapter 04: Reference walker

Weak spot removed: deep references rot. The link resolver checks that a link lands somewhere. This chapter asks a harder question: does the place it lands still support the sentence that links to it?

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `refwalk.py`. The `walk` function is the whole algorithm: a queue, a visited set, a depth per document.
2. Read `example/refwalk.json`. It sets `max_depth` to 2.
3. Run the walker with the lexical judge. It opens 5 documents and prints two notes.
4. Make a config with `max_depth` 1 in `scratch/` and run the walker again. The walk opens 3 documents and prints two depth notes. Make a config with `max_depth` 5 and run it again. The depth notes go away. The crude judge then reports one false alarm on `d.md`, because the link text shares few words with the target. That shows its limit.
5. Plug in your own judge with the option `--judge-command` and a command that starts your program. The program reads `{"claim": ..., "source": ...}` on stdin and prints `{"supported": true, "reason": "..."}`.

```sh
python3 -I refwalk.py example/root.md --config example/refwalk.json --judge lexical  # exit 0; expect: refwalk: opened 5 document(s); 0 error(s); 2 note(s)
mkdir -p scratch
python3 -I -c "import json, pathlib; pathlib.Path('scratch/depth1.json').write_text(json.dumps({'max_depth': 1, 'max_path_length': 80, 'max_files': 50}))"
python3 -I refwalk.py example/root.md --config scratch/depth1.json --judge lexical  # exit 0; expect: refwalk: opened 3 document(s); 0 error(s); 2 note(s)
python3 -I -c "import json, pathlib; pathlib.Path('scratch/depth5.json').write_text(json.dumps({'max_depth': 5, 'max_path_length': 80, 'max_files': 50}))"
python3 -I refwalk.py example/root.md --config scratch/depth5.json --judge lexical  # exit 1; expect: unsupported-claim
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## Expected output

```text
b.md:3: [cycle] note: 'a.md' is an ancestor on the current chain; not followed again.
d.md:3: [depth-limit] note: 'e.md' is beyond max_depth and was not followed.
refwalk: opened 5 document(s); 0 error(s); 2 note(s)
```

## One readable error

```sh
python3 -I refwalk.py example/no-such-file.md  # exit 2; expect: refwalk: No such file or directory
```

## Honest limits

The lexical judge is a word-overlap counter. It is a stand-in so that tests are repeatable. A language model judge is the intended use, and nothing here tests one. The walker follows only local markdown links. The chapter calls no network service.

## Prove the check can fail

Run the validator with `--bad`. It prints five errors (a missing file, a missing anchor and three claims the lexical judge rejects), then `validate: FAIL (5 error(s))`, and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (5 error(s))
```
