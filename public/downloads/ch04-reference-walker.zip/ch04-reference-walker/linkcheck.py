"""Check that every relative link, file link, image path and heading anchor in markdown files resolves.

External links (http, https, mailto and other schemes) are counted but never fetched. This tool uses no network.
The anchor rule follows the GitHub heading-slug rules as the author reads them. It was not compared with github.com.
"""
import argparse
import re
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import unquote

INLINE_LINK = re.compile(r"(!?)\[(?:[^\]\\]|\\.)*\]\(\s*(<[^>]*>|[^)\s]*)(?:\s+\"[^\"]*\")?\s*\)")
REFERENCE_DEFINITION = re.compile(r"^\s{0,3}\[[^\]]+\]:\s*(<[^>]*>|\S+)")
ATX_HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$")
SETEXT_UNDERLINE = re.compile(r"^\s{0,3}(=+|-+)\s*$")
FENCE = re.compile(r"^\s{0,3}(```+|~~~+)")
HTML_ANCHOR = re.compile(r"""<[a-zA-Z][^>]*\s(?:id|name)=["']([^"']+)["']""")
SCHEME = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*:")


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    message: str

    def __str__(self):
        return f"{self.path}:{self.line}: [{self.rule}] {self.message}"


def strip_inline_markup(text):
    text = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"[*~]+", "", text)
    return re.sub(r"(?<![A-Za-z0-9])_+|_+(?![A-Za-z0-9])", "", text)


def github_slug(heading_text):
    text = strip_inline_markup(heading_text).strip().lower()
    kept = []
    for char in text:
        if char in " -_" or unicodedata.category(char)[0] in "LN" or unicodedata.category(char) == "Mn":
            kept.append("-" if char == " " else char)
    return "".join(kept)


def content_lines(text):
    """Yield (line number, line, in_code) for every line, marking fenced code."""
    fence = None
    for number, line in enumerate(text.splitlines(), start=1):
        match = FENCE.match(line)
        if match:
            marker = match.group(1)
            if fence is None:
                fence = marker[0]
                yield number, line, True
                continue
            if marker[0] == fence:
                fence = None
                yield number, line, True
                continue
        yield number, line, fence is not None


def anchors_of(text):
    seen = {}
    anchors = set()
    previous = None
    for _, line, in_code in content_lines(text):
        if in_code:
            previous = None
            continue
        heading = None
        match = ATX_HEADING.match(line)
        if match:
            heading = match.group(2)
        elif SETEXT_UNDERLINE.match(line) and previous and previous.strip():
            heading = previous
        if heading is not None:
            slug = github_slug(heading)
            count = seen.get(slug, 0)
            seen[slug] = count + 1
            anchors.add(slug if count == 0 else f"{slug}-{count}")
        anchors.update(HTML_ANCHOR.findall(line))
        previous = None if heading is not None else line
    return anchors


def extract_links(text):
    """Yield (line number, is_image, target) outside fenced code and inline code."""
    for number, line, in_code in content_lines(text):
        if in_code:
            continue
        line = re.sub(r"`[^`]*`", "", line)
        for match in INLINE_LINK.finditer(line):
            yield number, match.group(1) == "!", match.group(2)
        definition = REFERENCE_DEFINITION.match(line)
        if definition:
            yield number, False, definition.group(1)


def check_file(file, root):
    file = Path(file)
    text = file.read_text(encoding="utf-8")
    findings = []
    own_anchors = anchors_of(text)
    cache = {}
    external = 0
    for number, is_image, raw in extract_links(text):
        target = unquote(raw[1:-1] if raw.startswith("<") else raw)
        if not target:
            findings.append(Finding(str(file), number, "empty-link", "The link has no target."))
            continue
        if SCHEME.match(target) or target.startswith("//"):
            external += 1
            continue
        path_part, _, anchor = target.partition("#")
        if not path_part:
            if anchor and anchor not in own_anchors:
                findings.append(Finding(str(file), number, "missing-anchor", f"No heading makes the anchor '#{anchor}'."))
            continue
        resolved = (Path(root) / path_part.lstrip("/")) if path_part.startswith("/") else (file.parent / path_part)
        if not resolved.exists():
            rule = "missing-image" if is_image else "missing-file"
            findings.append(Finding(str(file), number, rule, f"'{path_part}' does not exist."))
            continue
        if anchor and resolved.is_file() and resolved.suffix.lower() == ".md":
            if resolved not in cache:
                cache[resolved] = anchors_of(resolved.read_text(encoding="utf-8"))
            if anchor not in cache[resolved]:
                findings.append(Finding(str(file), number, "missing-anchor", f"'{path_part}' has no heading for '#{anchor}'."))
    return findings, external


def markdown_files(paths):
    for raw in paths:
        path = Path(raw)
        yield from sorted(path.rglob("*.md")) if path.is_dir() else [path]


def check_paths(paths, root="."):
    findings, external = [], 0
    for file in markdown_files(paths):
        found, count = check_file(file, root)
        findings.extend(found)
        external += count
    return findings, external


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("paths", nargs="+")
    parser.add_argument("--root", default=".", help="folder that a link starting with / points to")
    args = parser.parse_args(argv)
    findings, external = check_paths(args.paths, args.root)
    for finding in findings:
        print(finding)
    print(f"linkcheck: {len(findings)} finding(s); {external} external link(s) not fetched")
    return 1 if findings else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"linkcheck: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
