# Bad root

The [format](present.md#format) is a tab separated line.
The [gone page](gone.md) was deleted.
The notes are encrypted with a quantum key, as [the format section](present.md#format) says.
Go on: [next](present.md#format) and [deep](deep1.md).
