# Page B

Storage details. The note format and the search are described in [page A](a.md), which makes a loop.
