# Page C

Old notes move to a second file when the first file holds many notes. Go deeper: [page D](d.md).
