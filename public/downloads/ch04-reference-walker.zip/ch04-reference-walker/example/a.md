# Page A

## Format

Each note is one line. The line holds a time stamp, a tab and the note text.

## Search

The search command lists the notes that hold a word. The search ignores letter case.

See [page B](b.md) for the storage details.
