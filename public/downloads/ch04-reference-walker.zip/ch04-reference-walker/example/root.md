# Root document

The [note format](a.md#format) is a tab separated line with a time stamp and the note text.
The search command lists the notes that hold a word, as [the search section](a.md#search) says.

## More

The [archive rules](c.md) say old notes move to a second file.
