"""Walk the example references with the lexical judge. With --bad, walk the broken fixture.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import refwalk  # noqa: E402


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    folder = HERE / ("fixtures/bad" if "--bad" in argv else "example")
    config = refwalk.load_config(folder / "refwalk.json")
    findings, opened = refwalk.walk(folder / "root.md", folder, config, refwalk.LexicalJudge())
    errors = [f for f in findings if f.is_error]
    for finding in findings:
        print(finding)
    print(f"opened {opened} document(s)")
    print("validate: PASS" if not errors else f"validate: FAIL ({len(errors)} error(s))")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
