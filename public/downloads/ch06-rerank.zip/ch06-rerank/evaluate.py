"""Measure retrieval quality on the hand-labelled evaluation set: BM25 alone, then with each re-ranker.

Metrics (k = 3): precision@k is the share of the top k that is labelled relevant. hit@k is the share of queries
with at least one relevant memory in the top k. MRR is the mean of 1 / rank of the first relevant memory
(0 when no relevant memory is ranked).
"""
import argparse
import json
import statistics
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import memory  # noqa: E402
import rerank  # noqa: E402

K = 3
CANDIDATES = 20


def load_evalset(folder):
    folder = Path(folder)
    memories = memory.load_memories(folder / "memories")
    queries = json.loads((folder / "queries.json").read_text(encoding="utf-8"))["queries"]
    return memories, queries


def label_problems(memories, queries, min_memories=40, min_queries=30):
    names = {m.name for m in memories}
    problems = []
    if len(memories) < min_memories:
        problems.append(f"Only {len(memories)} memories; at least {min_memories} are needed.")
    if len(queries) < min_queries:
        problems.append(f"Only {len(queries)} queries; at least {min_queries} are needed.")
    for q in queries:
        problems += [f"Query '{q['query']}' names unknown memory '{n}'." for n in q["relevant"] if n not in names]
        if not q["relevant"]:
            problems.append(f"Query '{q['query']}' has no relevant memory.")
    return problems


def bm25_ranker(prompt, memories):
    return memory.bm25_ranker(prompt, memories)


def metrics(ranker, memories, queries, k=K):
    precisions, hits, reciprocal = [], 0, []
    for q in queries:
        ranked = [m.name for m, _ in ranker(q["query"], memories)]
        relevant = set(q["relevant"])
        top = ranked[:k]
        precisions.append(sum(n in relevant for n in top) / k)
        hits += any(n in relevant for n in top)
        first = next((r for r, n in enumerate(ranked, start=1) if n in relevant), None)
        reciprocal.append(1 / first if first else 0.0)
    count = len(queries)
    return {"precision_at_k": round(sum(precisions) / count, 4), "hit_at_k": round(hits / count, 4),
            "mrr": round(sum(reciprocal) / count, 4), "queries": count, "k": k}


def systems(include_cross_encoder):
    found = {"bm25": bm25_ranker, "lexical rerank": rerank.rerank_ranker(rerank.LexicalScorer(), CANDIDATES)}
    if include_cross_encoder:
        found["cross-encoder rerank"] = rerank.rerank_ranker(rerank.CrossEncoderScorer(), CANDIDATES)
    return found


def measure_latency(memories, queries, repeats=5):
    """Time the cross-encoder on this machine: load time, then the median seconds to re-rank one prompt."""
    started = time.perf_counter()
    scorer = rerank.CrossEncoderScorer()
    load_seconds = time.perf_counter() - started
    ranker = rerank.rerank_ranker(scorer, CANDIDATES)
    ranker(queries[0]["query"], memories)  # warm up
    timings = []
    for _ in range(repeats):
        for q in queries:
            started = time.perf_counter()
            ranker(q["query"], memories)
            timings.append(time.perf_counter() - started)
    return {"load_seconds": round(load_seconds, 2), "median_seconds_per_prompt": round(statistics.median(timings), 4),
            "max_seconds_per_prompt": round(max(timings), 4), "candidates": CANDIDATES, "samples": len(timings)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--evalset", default=str(HERE / "evalset"))
    parser.add_argument("--cross-encoder", action="store_true", help="also measure the real cross-encoder")
    parser.add_argument("--latency", action="store_true", help="time the cross-encoder (needs --cross-encoder)")
    args = parser.parse_args(argv)
    memories, queries = load_evalset(args.evalset)
    print("| system | precision@3 | hit@3 | MRR |\n| --- | --- | --- | --- |")
    for name, ranker in systems(args.cross_encoder).items():
        m = metrics(ranker, memories, queries)
        print(f"| {name} | {m['precision_at_k']:.3f} | {m['hit_at_k']:.3f} | {m['mrr']:.3f} |")
    print(f"({len(memories)} memories, {len(queries)} queries)")
    if args.cross_encoder and args.latency:
        print(json.dumps(measure_latency(memories, queries), indent=1))
    return 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"evaluate: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
