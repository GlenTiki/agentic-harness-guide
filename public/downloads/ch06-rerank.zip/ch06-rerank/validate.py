"""Check the evaluation set labels, the determinism of the fallback re-ranker and the recorded results.

Usage: python3 -I validate.py [--bad]
"""
import json
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import evaluate  # noqa: E402
import rerank  # noqa: E402

TOLERANCE = 1e-4


def check(evalset_folder, results_path=None):
    memories, queries = evaluate.load_evalset(evalset_folder)
    problems = evaluate.label_problems(memories, queries)
    if problems:
        return problems
    lexical = rerank.rerank_ranker(rerank.LexicalScorer(), evaluate.CANDIDATES)
    runs = {tuple((m.name, s) for m, s in lexical(q["query"], memories)) for q in queries[:1] for _ in range(10)}
    if len(runs) != 1:
        problems.append("The lexical re-ranker gave different output for the same input.")
    if results_path:
        recorded = json.loads(Path(results_path).read_text(encoding="utf-8"))
        for name, ranker in (("bm25", evaluate.bm25_ranker), ("lexical rerank", lexical)):
            now = evaluate.metrics(ranker, memories, queries)
            for key in ("precision_at_k", "hit_at_k", "mrr"):
                if abs(now[key] - recorded[name][key]) > TOLERANCE:
                    problems.append(f"{name} {key}: recorded {recorded[name][key]}, measured {now[key]}.")
    return problems


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    if "--bad" in argv:
        problems = check(HERE / "fixtures" / "bad" / "evalset")
    else:
        problems = check(HERE / "evalset", HERE / "results.json")
    for problem in problems:
        print(f"FAIL {problem}")
    print("validate: PASS" if not problems else f"validate: FAIL ({len(problems)} problem(s))")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
