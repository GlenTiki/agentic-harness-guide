# Chapter 06: Rerank

Weak spot removed: keyword search misses the point. The memory chapter showed "timestamp" and "time stamp" missing each other. This chapter measures how often that kind of miss happens, and what a second step recovers.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `rerank.py`. The pipeline is the function `rerank_ranker`.
2. Run the validator. It checks the labels, the determinism of the lexical scorer and the recorded results. Without `sentence-transformers` the unit tests report `OK (skipped=1)`.
3. Run the evaluation without extra packages.
4. Optional. Try the real cross-encoder in a throwaway environment, not in your global Python. The environment sits in `scratch/`. The commands need `uv` and a network, and this kit does not run them.

```sh
python3 -I validate.py  # exit 0; expect: validate: PASS
python3 -I evaluate.py  # exit 0; expect: (44 memories, 34 queries)
```

```sh optional
uv venv scratch/ce-venv --python 3.12
uv pip install --python scratch/ce-venv/bin/python sentence-transformers
scratch/ce-venv/bin/python -I evaluate.py --cross-encoder --latency
```

## One readable error

```sh
python3 -I evaluate.py --evalset no-such-folder  # exit 2; expect: evaluate: No such file or directory
```

## Measured results

All numbers below come from the 44 memories and 34 queries in `evalset/`. Precision@3 is low for every system because most queries have one correct memory, so the best possible value is 0.333 for those.

| system | precision@3 | hit@3 | MRR |
| --- | --- | --- | --- |
| bm25 | 0.265 | 0.794 | 0.643 |
| lexical rerank | 0.235 | 0.706 | 0.670 |
| cross-encoder rerank | 0.275 | 0.794 | 0.803 |

The cross-encoder row was measured once, in a throwaway environment, with sentence-transformers 6.2.0 and the model `cross-encoder/ms-marco-MiniLM-L6-v2`. The first two rows are guarded by `results.json`, so the validator fails if they change. The cross-encoder row is not guarded, because the package is optional.

What the numbers say. The cross-encoder put the first correct memory higher (MRR 0.643 to 0.803) and left hit@3 unchanged. The lexical fallback improved MRR a little and lowered hit@3 and precision, so it is not an upgrade on this set. With 34 queries, a difference of one query moves hit@3 by 0.029. Treat small differences as noise.

## Measured on this machine

An Apple M4 laptop, CPU only, torch 2.14.1 with 4 threads, one session, after the model files were already downloaded. Loading the model took 0.54 seconds. Re-ranking 20 candidates for one prompt took a median of 0.0153 seconds and a maximum of 0.0361 seconds over 170 prompts. This is one machine on one day. It says nothing about other machines. The guide's wording is "small enough to try on a laptop CPU; measure it yourself".

## Determinism

The lexical scorer gave identical output over 25 repeated runs in the unit tests. The cross-encoder gave identical scores over 10 repeated runs of one prompt, and over three runs in the optional unit test, on the machine above. This is a same-machine check. Other hardware or thread counts can change the last decimals, so the pipeline rounds scores to five decimals before it sorts.

## Prove the check can fail

Run the validator with `--bad`. It reports four problems and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (4 problem(s))
```
