import unittest
from pathlib import Path

import evaluate
import memory
import rerank

HERE = Path(__file__).resolve().parent.parent


def mem(name, body="x", description="d"):
    return memory.Memory(name, description, "fact", (), "2026-09-01T09:00:00Z", body, name)


class FakeModel:
    def __init__(self, table):
        self.table, self.seen = table, []

    def predict(self, pairs):
        self.seen.append(list(pairs))
        return [self.table.get(doc.split("\n")[0].split("]")[0][1:], 0.0) for _, doc in pairs]


class LexicalScorerTest(unittest.TestCase):
    def test_stems_match(self):
        a, b = rerank.LexicalScorer().scores("retrying calls", ["retry the call", "unrelated text"])
        self.assertGreater(a, b)

    def test_shared_prefix_counts_half(self):
        full, partial = rerank.LexicalScorer().scores("annotations", ["annotations", "annotate"])
        self.assertAlmostEqual(partial, full / 2)

    def test_word_pair_adds_to_the_score(self):
        together, apart = rerank.LexicalScorer().scores("failing test", ["failing test first", "test then failing"])
        self.assertGreater(together, apart)

    def test_empty_query_scores_zero(self):
        self.assertEqual(rerank.LexicalScorer().scores("the and", ["anything"]), [0.0])

    def test_repeat_runs_are_identical(self):
        docs = ["alpha beta", "beta gamma", "gamma delta"]
        runs = {tuple(rerank.LexicalScorer().scores("beta gamma", docs)) for _ in range(25)}
        self.assertEqual(len(runs), 1)


class CrossEncoderScorerTest(unittest.TestCase):
    def test_pairs_go_to_the_model_in_order(self):
        model = FakeModel({})
        rerank.CrossEncoderScorer(model=model).scores("q", ["d1", "d2"])
        self.assertEqual(model.seen, [[("q", "d1"), ("q", "d2")]])

    def test_scores_are_plain_floats(self):
        class Model:
            def predict(self, pairs):
                return [1, 2]
        self.assertEqual(rerank.CrossEncoderScorer(model=Model()).scores("q", ["a", "b"]), [1.0, 2.0])

    @unittest.skipUnless(rerank.cross_encoder_available(), "sentence-transformers is not installed")
    def test_real_model_is_repeatable(self):
        memories, queries = evaluate.load_evalset(HERE / "evalset")
        ranker = rerank.rerank_ranker(rerank.CrossEncoderScorer(), 20)
        runs = {tuple((m.name, s) for m, s in ranker(queries[0]["query"], memories)) for _ in range(3)}
        self.assertEqual(len(runs), 1)


class RankerTest(unittest.TestCase):
    def setUp(self):
        self.memories = [mem("alpha", "apples"), mem("beta", "bananas"), mem("gamma", "cherries")]

    def test_scorer_decides_the_order(self):
        scorer = rerank.CrossEncoderScorer(model=FakeModel({"gamma": 9.0, "alpha": 1.0, "beta": 0.5}))
        ranked = rerank.rerank_ranker(scorer, 3)("apples", self.memories)
        self.assertEqual([m.name for m, _ in ranked], ["gamma", "alpha", "beta"])

    def test_padding_lets_the_scorer_see_a_document_with_no_shared_word(self):
        model = FakeModel({"gamma": 9.0})
        ranked = rerank.rerank_ranker(rerank.CrossEncoderScorer(model=model), 3)("apples", self.memories)
        self.assertEqual(ranked[0][0].name, "gamma")
        self.assertEqual(len(model.seen[0]), 3)

    def test_candidate_count_caps_what_the_scorer_sees(self):
        model = FakeModel({})
        rerank.rerank_ranker(rerank.CrossEncoderScorer(model=model), 2)("apples", self.memories)
        self.assertEqual(len(model.seen[0]), 2)

    def test_ties_fall_back_to_bm25_order_then_name(self):
        ranked = rerank.rerank_ranker(rerank.CrossEncoderScorer(model=FakeModel({})), 3)("bananas", self.memories)
        self.assertEqual([m.name for m, _ in ranked], ["beta", "alpha", "gamma"])

    def test_min_score_drops_weak_matches(self):
        scorer = rerank.CrossEncoderScorer(model=FakeModel({"alpha": 2.0, "beta": -1.0}))
        ranked = rerank.rerank_ranker(scorer, 3, min_score=0.0)("apples", self.memories)
        self.assertEqual([m.name for m, _ in ranked], ["alpha"])

    def test_plugs_into_memory_select(self):
        scorer = rerank.CrossEncoderScorer(model=FakeModel({"beta": 5.0}))
        chosen, _ = memory.select("apples", self.memories, 1000, 1, ranker=rerank.rerank_ranker(scorer, 3))
        self.assertEqual(chosen[0][0].name, "beta")


class MetricsTest(unittest.TestCase):
    def test_hand_computed_metrics(self):
        memories = [mem("a"), mem("b"), mem("c"), mem("d")]
        orders = {"q1": ["a", "b", "c", "d"], "q2": ["d", "c", "b", "a"], "q3": ["c", "d"]}
        queries = [{"query": "q1", "relevant": ["a"]}, {"query": "q2", "relevant": ["a"]},
                   {"query": "q3", "relevant": ["a"]}]
        by_name = {m.name: m for m in memories}

        def ranker(prompt, _):
            return [(by_name[n], 1.0) for n in orders[prompt]]

        result = evaluate.metrics(ranker, memories, queries, k=3)
        # q1: p=1/3, hit, rr=1. q2: p=0, miss (a is 4th), rr=1/4. q3: p=0, miss, rr=0.
        self.assertEqual(result["precision_at_k"], round(1 / 9, 4))
        self.assertEqual(result["hit_at_k"], round(1 / 3, 4))
        self.assertEqual(result["mrr"], round((1 + 0.25 + 0) / 3, 4))


class EvalSetTest(unittest.TestCase):
    def test_size_and_labels_are_valid(self):
        memories, queries = evaluate.load_evalset(HERE / "evalset")
        self.assertGreaterEqual(len(memories), 40)
        self.assertGreaterEqual(len(queries), 30)
        self.assertEqual(evaluate.label_problems(memories, queries), [])

    def test_bad_evalset_is_reported(self):
        memories, queries = evaluate.load_evalset(HERE / "fixtures" / "bad" / "evalset")
        problems = evaluate.label_problems(memories, queries)
        self.assertEqual(len(problems), 4)


if __name__ == "__main__":
    unittest.main()
