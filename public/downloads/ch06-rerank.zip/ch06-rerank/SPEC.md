# Chapter 06: Rerank

## Purpose

This chapter fixes a gap in keyword search. BM25 finds memories that share words with the prompt. It misses a memory that uses other words for the same idea. A second step reads the prompt and each candidate together and orders them again.

## The pipeline

1. BM25 picks up to 20 candidate memories.
2. If BM25 finds fewer than 20, the pipeline adds the next memories in file order. This padding is arbitrary. It lets the second step see a memory with no shared word.
3. A scorer gives each candidate a score for the prompt.
4. The pipeline sorts by score. A tie falls back to the BM25 order, then to the memory name.

## The two scorers

The cross-encoder scorer uses the sentence-transformers package. It is optional. The default model is `cross-encoder/ms-marco-MiniLM-L6-v2`. A cross-encoder reads the prompt and the memory as one input. It is slower than a keyword search, so it only orders a short list.

The lexical scorer needs no package. It matches word stems and shared five-letter prefixes. It adds a bonus for a shared pair of words. It is a deterministic fallback. It is not a language model.

## Rules

1. The same input must give the same output on the same machine, every time.
2. The chapter must pass its tests when the optional package is absent.
3. The chapter must state which numbers it measured, and where.

## The evaluation set

The set holds 44 memories and 34 queries. A person labelled which memories answer each query. The queries use other words than the memories on purpose. The set measures three numbers at k = 3: precision, hit rate and mean reciprocal rank. The author wrote the labels once and did not change them after seeing results.

## Proof that the check can fail

The folder `fixtures/bad/evalset` holds a query that names a memory that does not exist, a query with no answer, and too few items. The validator must report four problems.
