# Subagent brief: Add search to the notes tool

## Task

Add a `search` command that lists notes holding a word.

## Files in scope

- notes.py
- tests/test_notes.py

## Acceptance checks

- `python3 -I -m unittest` passes
- A test shows search ignores case

## Report format

List the files you changed, then the last line of ./check.sh.

<!-- BEGIN SHARED RULES -->
## Shared rules

1. Work only inside the files named in "Files in scope".
2. Write a failing test before you write code. Watch it fail.
3. Run `./check.sh` before you report. Quote its last line.
4. Describe code in simple English: short sentences, active voice.
5. Do not push, do not delete data and do not edit `check.sh`.
6. If the task is unclear, stop and say what is unclear.
<!-- END SHARED RULES -->
