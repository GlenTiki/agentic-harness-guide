# Orchestrator brief: Search the notes

The product manager writes this in plain English. The orchestrator agent reads it, splits the work and starts the subagents.

## Outcome

A user can type a word and see every note that holds it.

## Expected behaviour

The search ignores letter case. The search prints the time stamp and the text of each match. An empty word gives an error message. A word with no match prints nothing and exits with code 0.

## Acceptance checks

1. `./check.sh` ends with ALL CHECKS PASSED.
2. A test covers case, no match and an empty word.

## Out of scope

Do not change the file format. Do not add a package.

## Plan for subagents

1. Builder: adds the `search` command and its tests.
2. Reviewer: reads the change and lists missing edge cases. The reviewer edits nothing.

## Next step

The orchestrator starts the builder. It then reports the plan back to the product manager and waits for corrections.
