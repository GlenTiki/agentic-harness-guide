import json
import subprocess
import sys
import unittest
from pathlib import Path

import briefs

HERE = Path(__file__).resolve().parent.parent


def render(**overrides):
    args = dict(title="T", task="Do it.", scope=["a.py"], checks=["tests pass"], report="Say what changed.")
    args.update(overrides)
    return briefs.render_subagent_brief(**args)


class RenderAndCheckTest(unittest.TestCase):
    def test_rendered_brief_passes_the_check(self):
        self.assertEqual(briefs.check_subagent_brief(render()), [])

    def test_missing_block_is_caught(self):
        text = render().split(briefs.BEGIN)[0]
        self.assertIn("The shared rules block is missing.", briefs.check_subagent_brief(text))

    def test_markers_in_the_wrong_order_count_as_missing(self):
        text = f"## Task\nx\n{briefs.END}\n{briefs.BEGIN}\n"
        self.assertIn("The shared rules block is missing.", briefs.check_subagent_brief(text))

    def test_edited_rule_is_caught(self):
        text = render().replace("Run `./check.sh`", "Run the checks")
        self.assertIn("The shared rules block differs from shared-rules.md.", briefs.check_subagent_brief(text))

    def test_old_brief_fails_when_the_shared_rules_change(self):
        old = render()
        new_rules = briefs.canonical_rules() + "\n7. A new rule."
        self.assertTrue(briefs.check_subagent_brief(old, new_rules))
        self.assertEqual(briefs.check_subagent_brief(render(rules=new_rules), new_rules), [])

    def test_empty_section_is_caught(self):
        self.assertTrue(any("Acceptance checks" in p for p in briefs.check_subagent_brief(render(checks=[]))))

    def test_long_brief_is_caught(self):
        self.assertTrue(any("longer than" in p for p in briefs.check_subagent_brief(render(task="x\n" * 60))))

    def test_orchestrator_template_sections(self):
        template = (HERE / "templates" / "orchestrator-brief.md").read_text(encoding="utf-8")
        self.assertEqual(briefs.check_orchestrator_brief(template), [])
        self.assertTrue(briefs.check_orchestrator_brief(template.replace("## Next step", "## Later")))


class FolderTest(unittest.TestCase):
    def test_example_is_clean(self):
        self.assertEqual(briefs.check_folder(HERE / "example" / "briefs"), {})

    def test_every_bad_brief_is_reported_once(self):
        results = briefs.check_folder(HERE / "fixtures" / "bad" / "briefs")
        self.assertEqual(sorted(results), ["no-checks.md", "no-rules.md", "no-scope.md", "orchestrator-no-next-step.md",
                                           "rule-dropped.md"])


class SubagentStopHookTest(unittest.TestCase):
    def run_hook(self, event):
        return subprocess.run([sys.executable, "-I", str(HERE / "hooks" / "subagent_must_quote_check.py")],
                              input=json.dumps(event), text=True, capture_output=True)

    def test_blocks_without_a_quoted_check(self):
        done = self.run_hook({"hook_event_name": "SubagentStop", "last_assistant_message": "All done."})
        self.assertEqual(done.returncode, 2)
        self.assertIn("check.sh", done.stderr)

    def test_allows_with_a_quoted_check(self):
        self.assertEqual(self.run_hook({"last_assistant_message": "ALL CHECKS PASSED"}).returncode, 0)

    def test_never_loops(self):
        self.assertEqual(self.run_hook({"stop_hook_active": True, "last_assistant_message": ""}).returncode, 0)

    def test_malformed_input_is_a_non_blocking_error(self):
        done = subprocess.run([sys.executable, "-I", str(HERE / "hooks" / "subagent_must_quote_check.py")],
                              input="{bad", text=True, capture_output=True)
        self.assertEqual(done.returncode, 1)


class ConfigShapeTest(unittest.TestCase):
    """These tests check shape only. Nothing here ran Claude Code."""

    def test_settings_snippet_shape(self):
        settings = json.loads((HERE / "settings-for-subagents.example.json").read_text(encoding="utf-8"))
        self.assertEqual(set(settings["hooks"]), {"SubagentStop"})
        for groups in settings["hooks"].values():
            for group in groups:
                for hook in group["hooks"]:
                    self.assertEqual(hook["type"], "command")

    def test_settings_path_resolves_and_blocks_an_unfinished_report(self):
        self.assertEqual(briefs.check_settings(HERE / "settings-for-subagents.example.json"), [])

    def test_settings_path_from_the_repository_is_caught(self):
        problems = briefs.check_settings(HERE / "fixtures" / "bad" / "settings.json")
        self.assertEqual(len(problems), 1)
        self.assertIn("does not resolve", problems[0])

    def test_agent_definition_has_frontmatter_fields(self):
        text = (HERE / "agents" / "reviewer.example.md").read_text(encoding="utf-8")
        head = text.split("---")[1]
        for key in ("name:", "description:", "tools:"):
            self.assertIn(key, head)


if __name__ == "__main__":
    unittest.main()
