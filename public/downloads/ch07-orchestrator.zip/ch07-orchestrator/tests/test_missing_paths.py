import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent


class MissingPathTest(unittest.TestCase):
    """A path that does not exist gives one readable line on stderr and exit code 2, never a traceback."""

    def assert_one_line_error(self, program, *args, stdin=""):
        done = subprocess.run([sys.executable, "-I", program, *args], cwd=HERE, input=stdin, capture_output=True,
                              text=True)
        self.assertEqual(done.returncode, 2, done.stdout + done.stderr)
        self.assertNotIn("Traceback", done.stderr)
        self.assertEqual(len(done.stderr.strip().splitlines()), 1, done.stderr)
        self.assertIn("No such file or directory", done.stderr)
        return done.stderr

    def test_check_a_missing_folder(self):
        self.assert_one_line_error("briefs.py", "no-such-folder")


if __name__ == "__main__":
    unittest.main()
