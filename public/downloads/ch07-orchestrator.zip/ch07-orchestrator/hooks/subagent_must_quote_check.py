"""SubagentStop hook. Block a subagent from finishing until its final message quotes a passing check."""
import json
import sys

try:
    event = json.load(sys.stdin)
except ValueError:
    sys.exit(1)

if event.get("stop_hook_active"):
    sys.exit(0)  # already continuing because of this hook; never loop

if "ALL CHECKS PASSED" not in event.get("last_assistant_message", ""):
    print("Do not finish yet. Run ./check.sh and quote its last line in your report.", file=sys.stderr)
    sys.exit(2)
