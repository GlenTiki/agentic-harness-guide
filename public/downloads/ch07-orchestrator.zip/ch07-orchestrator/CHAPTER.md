# Chapter 07: Orchestrator

Weak spot removed: one agent does everything. A single long conversation grows until the agent loses the thread. A team lead that hands bounded briefs to subagents keeps its own context short, and each subagent starts clean with the same rules.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `templates/orchestrator-brief.md` and the worked example `example/briefs/orchestrator-notes-search.md`. This is what the product manager writes.
2. Read `shared-rules.md`.
3. Render a subagent brief.
4. Check the examples.
5. Edit one rule in a copy of an example brief and check again. The checker fails.
6. Read `settings-for-subagents.example.json` and `hooks/subagent_must_quote_check.py`. The first shows where the hook goes. The second makes a subagent quote a passing check before it can finish. To use them, copy the `hooks/` folder to `.claude/harness-subagent/hooks/` in your project and merge the settings. The validator installs the kit that way in a scratch project and follows the command in the settings.

```sh
python3 -I -c "import sys; sys.path.insert(0, '.'); import briefs; print(briefs.render_subagent_brief('T', 'Do it.', ['a.py'], ['tests pass'], 'Say what changed.'))"  # exit 0; expect: Subagent brief: T
python3 -I briefs.py example/briefs  # exit 0; expect: briefs: 0 brief(s) with problems
mkdir -p scratch
python3 -I -c "import shutil; shutil.copytree('example/briefs', 'scratch/briefs', dirs_exist_ok=True)"
python3 -I -c "from pathlib import Path; p = Path('scratch/briefs/search-feature.md'); p.write_text(p.read_text().replace('Do not push', 'Push freely'))"
python3 -I briefs.py scratch/briefs  # exit 1; expect: briefs: 1 brief(s) with problems
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## One readable error

```sh
python3 -I briefs.py no-such-folder  # exit 2; expect: briefs: No such file or directory
```

## Expected output

Step 4 prints `briefs: 0 brief(s) with problems`. The validator prints `validate: PASS`.

## What native Claude Code inherits

Use only the documented behaviour. Hooks from settings, managed policy and plugins also run for the tool calls that subagents make. Custom subagents load the project instructions unless `omitClaudeMd` is set, and the built-in Explore and Plan agents skip them. An agent definition can set `tools`, `disallowedTools` and `hooks` for one subagent. By default a subagent can start subagents, up to three layers deep. If you start an agent from a plain command-line program, none of this applies unless you pass the rules in.

## Honest limits

The tests check the brief format, the extra hook and the shape of the config files. They do not run Claude Code. The shared rules block makes sure the rules are present in the brief. It cannot make a subagent obey them. Enforcement comes from the hooks in chapter 02, which is a separate kit.

## Prove the check can fail

Run the validator with `--bad`. It reports five briefs (no shared block, an edited rule, empty acceptance checks, no files in scope, and an orchestrator brief with no next step) and one settings sample whose hook path does not exist in a kit. It prints `validate: FAIL (6 problem(s))` and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (6 problem(s))
```
