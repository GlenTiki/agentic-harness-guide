# Subagent brief: Add search to the notes tool

## Task

Add a `search` command that lists notes holding a word.

## Files in scope

- notes.py
- tests/test_notes.py

## Acceptance checks

- `python3 -I -m unittest` passes
- A test shows search ignores case

## Report format

List the files you changed, then the last line of ./check.sh.

