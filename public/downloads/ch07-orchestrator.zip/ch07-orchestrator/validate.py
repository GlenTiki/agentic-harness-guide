"""Check that every example brief carries the shared rules block. With --bad, check the broken briefs.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import briefs  # noqa: E402


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    folder = HERE / ("fixtures/bad/briefs" if "--bad" in argv else "example/briefs")
    results = briefs.check_folder(folder)
    settings = HERE / ("fixtures/bad/settings.json" if "--bad" in argv else "settings-for-subagents.example.json")
    wiring = briefs.check_settings(settings)
    for name, problems in results.items():
        for problem in problems:
            print(f"FAIL {name}: {problem}")
    for problem in wiring:
        print(f"FAIL {problem}")
    count = len(results) + len(wiring)
    print("validate: PASS" if not count else f"validate: FAIL ({count} problem(s))")
    return 1 if count else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
