"""Render subagent briefs from a template and check that every brief carries the shared rules block.

A brief must hold five parts: Task, Files in scope, Acceptance checks, Report format and the shared rules block.
The block between the BEGIN and END markers must match shared-rules.md exactly, so a rule cannot drift or vanish.
"""
import argparse
import json
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BEGIN, END = "<!-- BEGIN SHARED RULES -->", "<!-- END SHARED RULES -->"
SUBAGENT_SECTIONS = ("Task", "Files in scope", "Acceptance checks", "Report format")
ORCHESTRATOR_SECTIONS = ("Outcome", "Expected behaviour", "Acceptance checks", "Out of scope", "Plan for subagents", "Next step")
MAX_BRIEF_LINES = 60


def canonical_rules():
    return (HERE / "shared-rules.md").read_text(encoding="utf-8").strip()


def bullet_lines(items):
    return "\n".join(f"- {item}" for item in items)


def render_subagent_brief(title, task, scope, checks, report, rules=None):
    template = (HERE / "templates" / "subagent-brief.md").read_text(encoding="utf-8")
    return template.format(title=title, task=task.strip(), scope=bullet_lines(scope), checks=bullet_lines(checks),
                           report=report.strip(), shared_rules=(rules or canonical_rules()).strip())


def sections(markdown):
    """Return {heading: text} for each level 2 heading outside the shared-rules markers."""
    found, current = {}, None
    for line in markdown.splitlines():
        match = re.match(r"^##\s+(.*?)\s*$", line)
        if match:
            current = match.group(1)
            found[current] = []
        elif current is not None:
            found[current].append(line)
    return {heading: "\n".join(body).strip() for heading, body in found.items()}


def shared_block(text):
    if BEGIN not in text or END not in text or text.index(BEGIN) > text.index(END):
        return None
    return text[text.index(BEGIN) + len(BEGIN): text.index(END)].strip()


def check_subagent_brief(text, rules=None):
    problems = []
    parts = sections(text.replace(BEGIN, "").replace(END, ""))
    for name in SUBAGENT_SECTIONS:
        if not parts.get(name):
            problems.append(f"The section '{name}' is missing or empty.")
    block = shared_block(text)
    if block is None:
        problems.append("The shared rules block is missing.")
    elif block != (rules or canonical_rules()).strip():
        problems.append("The shared rules block differs from shared-rules.md.")
    if len(text.splitlines()) > MAX_BRIEF_LINES:
        problems.append(f"The brief is longer than {MAX_BRIEF_LINES} lines. Split the task.")
    return problems


def check_orchestrator_brief(text):
    parts = sections(text)
    return [f"The section '{name}' is missing or empty." for name in ORCHESTRATOR_SECTIONS if not parts.get(name)]


def check_folder(folder, rules=None):
    """Return {file name: [problems]} for every brief in the folder that has a problem."""
    results = {}
    for path in sorted(Path(folder).glob("*.md")):
        text = path.read_text(encoding="utf-8")
        checker = check_orchestrator_brief if path.name.startswith("orchestrator") else lambda t: check_subagent_brief(t, rules)
        problems = checker(text)
        if problems:
            results[path.name] = problems
    return results


INSTALL_DIR = ".claude/harness-subagent"
UNFINISHED_EVENT = {"hook_event_name": "SubagentStop", "last_assistant_message": "I am done."}


def check_settings(settings_path):
    """Install hooks/ at INSTALL_DIR in a scratch project and follow every command in the settings sample.

    A command whose script path does not resolve is a problem. The SubagentStop command must block (exit 2) a
    final message that quotes no passing check.
    """
    settings = json.loads(Path(settings_path).read_text(encoding="utf-8"))
    problems = []
    with tempfile.TemporaryDirectory() as tmp:
        project = Path(tmp)
        shutil.copytree(HERE / "hooks", project / INSTALL_DIR / "hooks", ignore=shutil.ignore_patterns("__pycache__"))
        for event, groups in settings["hooks"].items():
            for group in groups:
                for hook in group["hooks"]:
                    words = shlex.split(hook["command"].replace("${CLAUDE_PROJECT_DIR}", str(project)))
                    if not Path(words[-1]).is_file():
                        problems.append(f"settings {event}: the command path {hook['command']!r} does not resolve to a file "
                                        f"when hooks/ sits in {INSTALL_DIR}.")
                    elif event == "SubagentStop":
                        done = subprocess.run([sys.executable, *words[1:]], input=json.dumps(UNFINISHED_EVENT), text=True,
                                              capture_output=True)
                        if done.returncode != 2:
                            problems.append(f"settings SubagentStop: the command did not block an unfinished report (exit {done.returncode}).")
    return problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("folder")
    args = parser.parse_args(argv)
    if not Path(args.folder).exists():
        raise FileNotFoundError(2, "No such file or directory", str(args.folder))
    results = check_folder(args.folder)
    for name, problems in results.items():
        for problem in problems:
            print(f"{name}: {problem}")
    print(f"briefs: {len(results)} brief(s) with problems")
    return 1 if results else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"briefs: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
