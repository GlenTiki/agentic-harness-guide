# Subagent brief: {title}

## Task

{task}

## Files in scope

{scope}

## Acceptance checks

{checks}

## Report format

{report}

<!-- BEGIN SHARED RULES -->
{shared_rules}
<!-- END SHARED RULES -->
