# Orchestrator brief: {title}

The product manager writes this in plain English. The orchestrator agent reads it, splits the work and starts the subagents.

## Outcome

Say what the user can do when the work is done.

## Expected behaviour

List what the system does in each case, including the failure cases.

## Acceptance checks

List the commands or tests that must pass.

## Out of scope

List what the team must not touch.

## Plan for subagents

List each subagent, its role and its files.

## Next step

Say what the orchestrator will do next, and what it needs from the product manager.
