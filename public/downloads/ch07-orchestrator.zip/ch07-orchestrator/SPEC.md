# Chapter 07: Orchestrator

## Purpose

This chapter splits the roles. The human is the product manager. The main agent is the team lead. The team lead gives work to subagents. The human describes outcomes in plain English. The team lead explains its plan and waits for corrections.

## Two kinds of brief

The orchestrator brief comes from the product manager. It has six parts: Outcome, Expected behaviour, Acceptance checks, Out of scope, Plan for subagents and Next step.

The subagent brief comes from the team lead. It has four parts: Task, Files in scope, Acceptance checks and Report format. It also holds the shared rules block.

## The shared rules block

1. One file, `shared-rules.md`, holds the rules.
2. Each subagent brief holds a copy of the rules between two marker lines.
3. The checker compares each copy with the file, character by character.
4. If a rule changes, every old brief fails the check until someone renders it again.

## The brief checker

The checker fails a subagent brief when it finds one of these problems.

1. A required part is missing or empty.
2. The shared rules block is missing.
3. The shared rules block differs from `shared-rules.md`.
4. The brief is longer than 60 lines. A long brief means the task is too big.

## What native Claude Code does for you

These statements come from the Claude Code documentation.

1. Hooks from settings, managed policy and plugins also run for tool calls that subagents make. The hook input identifies the subagent.
2. Custom subagents load the project instructions, unless the agent definition sets `omitClaudeMd`. The built-in Explore and Plan agents skip them.
3. An agent definition can set `tools`, `disallowedTools` and `hooks` for one subagent.
4. By default a subagent can start subagents, up to three layers deep. An environment variable can turn this off.
5. Two events, SubagentStart and SubagentStop, mark the start and the end of a subagent.

A separate command-line program that starts an agent does not get these for free. You must pass it the rules yourself.

## The extra hook

The SubagentStop hook in this chapter blocks a subagent from finishing until its final message quotes `ALL CHECKS PASSED`. The hook ignores the event when `stop_hook_active` is true, so it cannot loop.

## What was tested

The tests cover rendering, the checker, the extra hook and the shape of the two example config files. Nobody ran the config files or the agent definition in Claude Code. The statements about native behaviour come from the documentation, not from a test.

## Proof that the check can fail

The folder `fixtures/bad/briefs` holds five broken briefs. The checker must report all five.
