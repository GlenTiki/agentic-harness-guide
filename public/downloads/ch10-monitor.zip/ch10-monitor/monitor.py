"""An append-only event log, a build-time status board and a freshness check.

Log: one JSON object per line. Keys: time (UTC, seconds, Z), source, kind, status (ok or fail), detail.
Board: built from the log when you run the tool. It is a snapshot, not a live view. It shows the source and the
observation time of every row. It has four states: ok, fail, stale (the last event is too old) and unknown
(no event at all). Unknown is a state, not an error: absence of evidence is shown, never hidden as green.
A missing log file means every signal is unknown. A log file that exists but is unreadable raises an error,
because "cannot read" and "nothing recorded" are different facts.
"""
import argparse
import html
import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

UTC_SECONDS = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
STATUSES = ("ok", "fail")
EVENT_KEYS = ("time", "source", "kind", "status", "detail")


class LogFormatError(ValueError):
    pass


@dataclass(frozen=True)
class Row:
    name: str
    state: str
    source: str
    observed: str
    age_seconds: object
    detail: str
    required: bool


def to_stamp(moment):
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_stamp(text):
    return datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def append_event(path, source, kind, status, detail="", now=None):
    if status not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}.")
    record = {"time": to_stamp(now or datetime.now(timezone.utc)), "source": source, "kind": kind,
              "status": status, "detail": detail}
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def read_events(path):
    path = Path(path)
    if not path.exists():
        return []
    events = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        try:
            record = json.loads(line)
        except ValueError:
            raise LogFormatError(f"{path}:{number}: not valid JSON.") from None
        if not isinstance(record, dict) or set(record) != set(EVENT_KEYS):
            raise LogFormatError(f"{path}:{number}: expected exactly the keys {', '.join(EVENT_KEYS)}.")
        if not UTC_SECONDS.match(str(record["time"])):
            raise LogFormatError(f"{path}:{number}: time must be UTC with seconds and a Z.")
        if record["status"] not in STATUSES:
            raise LogFormatError(f"{path}:{number}: status must be ok or fail.")
        events.append(record)
    return events


def load_config(path):
    signals = json.loads(Path(path).read_text(encoding="utf-8"))["signals"]
    for signal in signals:
        for key in ("name", "source", "kind", "max_age_seconds"):
            if key not in signal:
                raise ValueError(f"Signal {signal.get('name', '?')} lacks the key {key}.")
    return signals


def build_rows(events, signals, now):
    rows = []
    for signal in signals:
        matching = [e for e in events if e["source"] == signal["source"] and e["kind"] == signal["kind"]]
        required = signal.get("required", True)
        if not matching:
            rows.append(Row(signal["name"], "unknown", signal["source"], "never", None, "No event recorded.", required))
            continue
        latest = max(matching, key=lambda e: e["time"])
        age = int((now - parse_stamp(latest["time"])).total_seconds())
        if age < 0:
            state, detail = "unknown", "The event time is in the future."
        elif latest["status"] == "fail":
            state, detail = "fail", latest["detail"]
        elif age > signal["max_age_seconds"]:
            state, detail = "stale", f"Last ok event is {age} s old; the limit is {signal['max_age_seconds']} s."
        else:
            state, detail = "ok", latest["detail"]
        rows.append(Row(signal["name"], state, signal["source"], latest["time"], age, detail, required))
    return rows


def red_reasons(rows, events, now, max_log_age_seconds=None):
    """Return why the freshness check is red. An empty list means green."""
    reasons = [f"{r.name}: {r.state}. {r.detail}" for r in rows if r.required and r.state != "ok"]
    if max_log_age_seconds is not None:
        newest = max((e["time"] for e in events), default=None)
        if newest is None:
            reasons.append("The log has no events.")
        elif (now - parse_stamp(newest)).total_seconds() > max_log_age_seconds:
            reasons.append(f"The newest event in the log is older than {max_log_age_seconds} s.")
    return reasons


def render_markdown(rows, now):
    lines = ["# Status board", "", f"Built at {to_stamp(now)}. This is a snapshot, not a live view.", "",
             "| Signal | State | Source | Observed | Age (s) | Detail |", "| --- | --- | --- | --- | --- | --- |"]
    for r in rows:
        age = "" if r.age_seconds is None else r.age_seconds
        lines.append(f"| {r.name} | {r.state.upper()} | {r.source} | {r.observed} | {age} | {r.detail} |")
    return "\n".join(lines) + "\n"


def render_html(rows, now):
    cells = []
    for r in rows:
        age = "" if r.age_seconds is None else r.age_seconds
        cells.append(
            f'<tr class="{r.state}"><td>{html.escape(r.name)}</td><td><strong>{r.state.upper()}</strong></td>'
            f"<td>{html.escape(r.source)}</td><td>{html.escape(r.observed)}</td><td>{age}</td>"
            f"<td>{html.escape(r.detail)}</td></tr>")
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Status board</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root {{ color-scheme: light dark; }}
body {{ font: 16px/1.5 system-ui, sans-serif; margin: 1rem; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #8884; padding: .4rem .6rem; text-align: left; }}
tr.ok strong {{ color: #0a7a2f; }} tr.fail strong, tr.stale strong {{ color: #b3261e; }} tr.unknown strong {{ color: #8a6d00; }}
</style></head><body>
<h1>Status board</h1>
<p>Built at {to_stamp(now)}. This is a snapshot, not a live view. The state is written in words, not only in colour.</p>
<table><thead><tr><th>Signal</th><th>State</th><th>Source</th><th>Observed</th><th>Age (s)</th><th>Detail</th></tr></thead>
<tbody>
{chr(10).join(cells)}
</tbody></table></body></html>
"""


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    record = sub.add_parser("record")
    record.add_argument("--log", required=True)
    record.add_argument("source")
    record.add_argument("kind")
    record.add_argument("status", choices=STATUSES)
    record.add_argument("detail", nargs="?", default="")
    for name in ("board", "freshness"):
        command = sub.add_parser(name)
        command.add_argument("--log", required=True)
        command.add_argument("--config", required=True)
        command.add_argument("--now", help="UTC time such as 2026-10-24T09:30:00Z; default is the real clock")
        command.add_argument("--max-log-age", type=int)
        if name == "board":
            command.add_argument("--out", help="write .html or .md; default prints markdown")
    args = parser.parse_args(argv)
    if args.command == "record":
        append_event(args.log, args.source, args.kind, args.status, args.detail)
        return 0
    now = parse_stamp(args.now) if args.now else datetime.now(timezone.utc)
    events, signals = read_events(args.log), load_config(args.config)
    rows = build_rows(events, signals, now)
    if args.command == "board":
        text = render_html(rows, now) if (args.out or "").endswith(".html") else render_markdown(rows, now)
        Path(args.out).write_text(text, encoding="utf-8") if args.out else print(text)
        return 0
    reasons = red_reasons(rows, events, now, args.max_log_age)
    print("\n".join(f"RED: {r}" for r in reasons) or "freshness: GREEN")
    return 1 if reasons else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"monitor: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
