"""Run the freshness check on the example log at a fixed time. With --bad, run it on the stale log.

The time is fixed so that the result does not depend on the clock. Use monitor.py freshness for the real clock.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import monitor  # noqa: E402

FIXED_NOW = datetime(2026, 10, 24, 9, 30, 0, tzinfo=timezone.utc)
MAX_LOG_AGE_SECONDS = 3600


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    folder = HERE / ("fixtures/bad" if "--bad" in argv else "example")
    events = monitor.read_events(folder / "events.jsonl")
    rows = monitor.build_rows(events, monitor.load_config(folder / "board.json"), FIXED_NOW)
    reasons = monitor.red_reasons(rows, events, FIXED_NOW, MAX_LOG_AGE_SECONDS)
    for reason in reasons:
        print(f"RED: {reason}")
    print("validate: PASS" if not reasons else f"validate: FAIL ({len(reasons)} reason(s))")
    return 1 if reasons else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
