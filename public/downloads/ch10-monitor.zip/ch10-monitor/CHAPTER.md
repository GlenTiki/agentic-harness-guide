# Chapter 10: Monitor

Weak spot removed: nobody sees the system think. A hook that never fires looks the same as a hook that has nothing to block, until you record that it ran. This chapter records events and shows their age.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `example/events.jsonl` and `example/board.json`.
2. Build the board for a fixed time. The Backup row shows UNKNOWN.
3. Build an HTML page into `scratch/` and open the file.
4. Run the freshness check. It prints `freshness: GREEN`.
5. Run it without `--now`. The example events are old by now, so it prints RED lines and exits with code 1. This is the check doing its job.
6. Record an event.
7. Run the validator.

```sh
python3 -I monitor.py board --log example/events.jsonl --config example/board.json --now 2026-10-24T09:30:00Z  # exit 0; expect: UNKNOWN
mkdir -p scratch
python3 -I monitor.py board --log example/events.jsonl --config example/board.json --now 2026-10-24T09:30:00Z --out scratch/board.html
python3 -I monitor.py freshness --log example/events.jsonl --config example/board.json --now 2026-10-24T09:30:00Z --max-log-age 3600  # exit 0; expect: freshness: GREEN
python3 -I monitor.py freshness --log example/events.jsonl --config example/board.json --max-log-age 3600  # exit 1; expect: RED:
python3 -I monitor.py record --log scratch/e.jsonl check.sh check ok "ALL CHECKS PASSED"
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## One readable error

```sh
python3 -I monitor.py freshness --log example/events.jsonl --config no-such.json  # exit 2; expect: monitor: No such file or directory
```

## Wire it to your hooks

Add a call to `monitor.py record` at the end of a hook from chapter 02 or at the end of `check.sh`. Each run then leaves evidence. Without the call, the board shows UNKNOWN, which is the honest answer.

## Expected output

Step 4 prints `freshness: GREEN`. The validator prints `validate: PASS`. The validator fixes the clock at 2026-10-24T09:30:00Z so that the result does not change with the date.

## Honest limits

The board is a snapshot built when you run the tool. It is not a live dashboard. The log proves that something wrote a line. It does not prove that the line is true. A part that crashes before it logs leaves no line, and the board then shows it as stale or unknown, never green.

## Prove the check can fail

Run the validator with `--bad`. It reports three red reasons: a stale check, a failed hook and an unknown memory signal. It prints `validate: FAIL (3 reason(s))` and exits with code 1. The `fixtures/bad/events.jsonl` file is the stale fixture.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (3 reason(s))
```
