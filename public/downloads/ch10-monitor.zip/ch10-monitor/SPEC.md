# Chapter 10: Monitor

## Purpose

This chapter lets you see the system think. Each part writes a line to a log when it acts. A tool builds a status board from the log. A check goes red when the evidence is old.

## The event log

The log is a text file. It holds one JSON object on each line. A tool only appends to it.

1. `time` is a UTC time with seconds and a Z at the end.
2. `source` names the part that wrote the event.
3. `kind` names the type of event.
4. `status` is `ok` or `fail`.
5. `detail` is a short text.

The reader rejects a line with a missing key, an extra key, a bad time or a bad status. The message names the file and the line number.

## The states

A signal is a pair of a source and a kind, plus a time limit. The board shows one row for each signal. A row has one of four states.

1. `ok`: the last event has status ok and is not older than the limit.
2. `fail`: the last event has status fail.
3. `stale`: the last event has status ok but is older than the limit.
4. `unknown`: no event exists, or the event time is in the future.

Unknown is a state of its own. The board never shows it as green. You can mark a signal as not required. Then unknown does not turn the check red, but the board still shows it.

A missing log file means every signal is unknown. A log file that exists but cannot be read is an error. The tool does not treat it as empty.

## The board

The tool builds the board when you run it. It is a snapshot. It shows the build time. Each row shows the signal, the state in words, the source, the time of the last event and its age in seconds. The HTML page has no script and no external resource. It escapes all text from the log.

## The freshness check

The check is red when any required signal is not ok. It is also red when the newest event in the whole log is older than a limit that you set. This stops a green board built from a log that nobody writes to any more.

## Proof that the check can fail

The folder `fixtures/bad` holds a log with an old check event, a failed hook event and no memory event. The check must report three reasons.
