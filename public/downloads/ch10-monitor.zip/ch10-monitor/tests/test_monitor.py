import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import monitor as m

HERE = Path(__file__).resolve().parent.parent
NOW = datetime(2026, 10, 24, 9, 30, 0, tzinfo=timezone.utc)
SIGNAL = {"name": "S", "source": "src", "kind": "k", "max_age_seconds": 100}


def event(seconds_ago, status="ok", detail="d", source="src", kind="k"):
    return {"time": m.to_stamp(NOW - timedelta(seconds=seconds_ago)), "source": source, "kind": kind,
            "status": status, "detail": detail}


class StateTest(unittest.TestCase):
    def state(self, events, signal=SIGNAL):
        return m.build_rows(events, [signal], NOW)[0].state

    def test_fresh_ok(self):
        self.assertEqual(self.state([event(10)]), "ok")

    def test_exactly_at_the_limit_is_still_ok(self):
        self.assertEqual(self.state([event(100)]), "ok")

    def test_one_second_over_the_limit_is_stale(self):
        self.assertEqual(self.state([event(101)]), "stale")

    def test_latest_failure_wins_over_an_older_success(self):
        self.assertEqual(self.state([event(50), event(10, "fail")]), "fail")

    def test_latest_success_wins_over_an_older_failure(self):
        self.assertEqual(self.state([event(50, "fail"), event(10)]), "ok")

    def test_no_event_is_unknown_not_ok(self):
        row = m.build_rows([], [SIGNAL], NOW)[0]
        self.assertEqual((row.state, row.observed, row.age_seconds), ("unknown", "never", None))

    def test_other_sources_do_not_count(self):
        self.assertEqual(self.state([event(1, source="other")]), "unknown")

    def test_future_event_is_unknown(self):
        self.assertEqual(self.state([event(-60)]), "unknown")

    def test_row_carries_source_and_observation_time(self):
        row = m.build_rows([event(30)], [SIGNAL], NOW)[0]
        self.assertEqual((row.source, row.observed, row.age_seconds), ("src", "2026-10-24T09:29:30Z", 30))


class FreshnessTest(unittest.TestCase):
    def reasons(self, events, signals=(SIGNAL,), **kw):
        return m.red_reasons(m.build_rows(events, list(signals), NOW), events, NOW, **kw)

    def test_green_when_fresh_and_ok(self):
        self.assertEqual(self.reasons([event(5)]), [])

    def test_red_when_stale(self):
        self.assertEqual(len(self.reasons([event(500)])), 1)

    def test_red_when_unknown_and_required(self):
        self.assertEqual(len(self.reasons([])), 1)

    def test_unknown_is_allowed_when_not_required(self):
        optional = {**SIGNAL, "required": False}
        self.assertEqual(self.reasons([], (optional,)), [])

    def test_red_when_failed(self):
        self.assertEqual(len(self.reasons([event(5, "fail")])), 1)

    def test_red_when_the_whole_log_is_old(self):
        self.assertTrue(any("older than" in r for r in self.reasons([event(5000)], (), max_log_age_seconds=60)))

    def test_red_when_log_is_empty_and_limit_set(self):
        self.assertEqual(self.reasons([], (), max_log_age_seconds=60), ["The log has no events."])


class LogTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.log = Path(self.tmp.name) / "e.jsonl"

    def test_append_then_read(self):
        m.append_event(self.log, "src", "k", "ok", "hello", now=NOW)
        m.append_event(self.log, "src", "k", "fail", "bad", now=NOW)
        events = m.read_events(self.log)
        self.assertEqual([e["status"] for e in events], ["ok", "fail"])
        self.assertEqual(events[0]["time"], "2026-10-24T09:30:00Z")

    def test_missing_log_reads_as_empty(self):
        self.assertEqual(m.read_events(self.log), [])

    def test_corrupt_log_raises_with_the_line_number(self):
        self.log.write_text(json.dumps(event(1)) + "\nnot json\n", encoding="utf-8")
        with self.assertRaisesRegex(m.LogFormatError, ":2:"):
            m.read_events(self.log)

    def test_wrong_time_format_raises(self):
        bad = {**event(1), "time": "2026-10-24 09:30"}
        self.log.write_text(json.dumps(bad) + "\n", encoding="utf-8")
        with self.assertRaises(m.LogFormatError):
            m.read_events(self.log)

    def test_extra_key_raises(self):
        self.log.write_text(json.dumps({**event(1), "extra": 1}) + "\n", encoding="utf-8")
        with self.assertRaises(m.LogFormatError):
            m.read_events(self.log)

    def test_bad_status_refused_on_write(self):
        with self.assertRaises(ValueError):
            m.append_event(self.log, "s", "k", "maybe")


class RenderTest(unittest.TestCase):
    def rows(self):
        return m.build_rows([event(5, detail="<script>alert(1)</script>")], [SIGNAL, {**SIGNAL, "name": "Other", "source": "x"}], NOW)

    def test_html_escapes_content_and_shows_unknown_in_words(self):
        page = m.render_html(self.rows(), NOW)
        self.assertNotIn("<script>alert", page)
        self.assertIn("&lt;script&gt;", page)
        self.assertIn("UNKNOWN", page)
        self.assertIn("Built at 2026-10-24T09:30:00Z", page)

    def test_html_has_no_external_resources(self):
        page = m.render_html(self.rows(), NOW)
        for fragment in ("http://", "https://", "<script", "<link"):
            self.assertNotIn(fragment, page.replace("&lt;script&gt;", ""))

    def test_markdown_shows_source_and_time(self):
        text = m.render_markdown(self.rows(), NOW)
        self.assertIn("| S | OK | src | 2026-10-24T09:29:55Z | 5 |", text)


class FixtureTest(unittest.TestCase):
    def reasons(self, folder):
        events = m.read_events(HERE / folder / "events.jsonl")
        rows = m.build_rows(events, m.load_config(HERE / folder / "board.json"), NOW)
        return m.red_reasons(rows, events, NOW, 3600)

    def test_example_is_green_and_shows_backup_as_unknown(self):
        self.assertEqual(self.reasons("example"), [])
        events = m.read_events(HERE / "example" / "events.jsonl")
        states = {r.name: r.state for r in m.build_rows(events, m.load_config(HERE / "example" / "board.json"), NOW)}
        self.assertEqual(states["Backup"], "unknown")

    def test_stale_fixture_is_red_for_three_reasons(self):
        self.assertEqual(len(self.reasons("fixtures/bad")), 3)


if __name__ == "__main__":
    unittest.main()
