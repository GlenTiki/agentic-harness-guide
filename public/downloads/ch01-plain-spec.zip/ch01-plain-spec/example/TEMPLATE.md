# Name of the feature

## Purpose

Write one or two sentences. Say what the feature does and why it exists.

## Inputs

1. List each input on its own line.

## Steps

1. Write one action in each step.
2. Name the actor in each step.

## Result

Say what the user sees when the feature works.

## Failure behaviour

Say what the tool does when an input is wrong. Name the exit code and the message.

## Proof

Name the test that shows the feature works. Name the fixture that shows the check can fail.
