# Add a note

## Purpose

This spec says how the tool adds a note.

## Steps

1. The user gives the tool a line of text.
2. The tool checks that the text is not empty.
3. The tool writes the time stamp and the text to the file.

## Result

The file holds one new line. The tool prints nothing.
