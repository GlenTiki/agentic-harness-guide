# Add a note

## Purpose

The `add` command saves one note to the notes file. A user runs it to keep a thought for later.

## Inputs

1. The path of the notes file.
2. The text of the note.

## Steps

1. The tool trims the spaces around the text.
2. The tool refuses the text if it is empty.
3. The tool refuses the text if it holds a new line or a tab.
4. The tool writes one line to the file: the UTC time stamp, a tab, then the text.

## Result

The file holds one new line at the end. The command prints nothing.

## Failure behaviour

An empty note raises an error with the message "A note cannot be empty." The tool does not touch the file.

## Proof

The test `test_empty_note_is_refused` shows the error. The test `test_add_then_list` shows the new line.
