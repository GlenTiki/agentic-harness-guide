import unittest

import plainlint as p


def rules(text, **kw):
    return sorted({f.rule for f in p.lint_text(text, **kw)})


class SentenceLengthTest(unittest.TestCase):
    def test_short_sentence_passes(self):
        self.assertEqual(rules("The tool adds a note."), [])

    def test_long_sentence_fails(self):
        self.assertIn("sentence-length", rules(" ".join(["word"] * 30) + "."))

    def test_numbered_step_uses_the_tighter_limit(self):
        step = "1. " + " ".join(["move"] * 22) + "."
        self.assertIn("sentence-length", rules(step))
        self.assertNotIn("sentence-length", rules(" ".join(["move"] * 22) + "."))

    def test_code_fence_is_ignored(self):
        self.assertEqual(rules("```\n" + " ".join(["word"] * 40) + "\n```\n"), [])


class PassiveTest(unittest.TestCase):
    def test_passive_is_flagged(self):
        self.assertIn("passive-heuristic", rules("The file was written by the tool."))

    def test_active_is_not_flagged(self):
        self.assertEqual(rules("The tool writes the file."), [])

    def test_known_false_positive_is_documented(self):
        self.assertIn("passive-heuristic", rules("The tool is limited to one file."))


class VagueWordTest(unittest.TestCase):
    def test_banned_word_is_flagged(self):
        self.assertIn("vague-word", rules("The tool handles various inputs."))

    def test_banned_word_inside_code_is_ignored(self):
        self.assertEqual(rules("Run `things` now."), [])

    def test_word_boundary_is_respected(self):
        self.assertEqual(rules("The tool lists justice notes."), [])


class ReadabilityTest(unittest.TestCase):
    def test_known_grade(self):
        self.assertAlmostEqual(p.flesch_kincaid_grade(["The cat sat on the mat."]), -1.45, places=2)

    def test_hard_text_fails_the_grade_rule(self):
        hard = "Organisational interoperability necessitates comprehensive standardisation."
        self.assertIn("readability", rules(hard))

    def test_syllables(self):
        self.assertEqual([p.count_syllables(w) for w in ("cat", "table", "make", "reading")], [1, 2, 1, 2])


class DashTest(unittest.TestCase):
    def test_em_dash_is_flagged(self):
        self.assertIn("dash", rules("The tool \u2014 a small one \u2014 adds notes."))


class FileTest(unittest.TestCase):
    def test_bad_fixture_is_red_and_example_is_green(self):
        from pathlib import Path
        here = Path(__file__).resolve().parent.parent
        self.assertTrue(p.lint_paths([here / "fixtures" / "bad"]))
        self.assertEqual(p.lint_paths([here / "example"]), [])


if __name__ == "__main__":
    unittest.main()
