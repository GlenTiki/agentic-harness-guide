# Chapter 01: Plain spec

Weak spot removed: vague requests. If a spec is hard to read, an agent (and a person) guesses. A guess is where defects start.

Run every command from the kit folder, the one that holds this file.

## Steps

1. Read `example/TEMPLATE.md` and the worked example `example/notes-add.md`.
2. Run the linter on one file.
3. Run the validator. In the kit it lints everything in `example/` and `SPEC.md`.
4. Run the unit tests.

```sh
python3 -I plainlint.py example/notes-add.md  # exit 0; expect: plainlint: 0 finding(s)
python3 -I validate.py  # exit 0; expect: validate: PASS
python3 -I -m unittest discover -s tests -t .  # exit 0; expect: OK
```

## Expected output

`plainlint: 0 finding(s)` and `validate: PASS`.

## One readable error

```sh
python3 -I plainlint.py example/no-such-file.md  # exit 2; expect: plainlint: No such file or directory
```

## Honest limits

The passive-voice rule is a heuristic. The test `test_known_false_positive_is_documented` records a sentence it flags wrongly. The linter cannot check the licensed STE dictionary. The Vale rules in `vale/` are optional, and the section below says what was run.

## Optional: Vale

Install Vale yourself. It is a separate tool, and this kit does not install it. The Vale rules mirror three of the rules above (vague words, sentence length, passive voice). They do not compute the readability grade.

```sh optional
vale --config vale/.vale.ini example/notes-add.md
```

## Prove the check can fail

Run the validator with `--bad`. It reads `fixtures/bad/vague.md`, prints nine findings, prints `validate: FAIL` and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (9 finding(s))
```
