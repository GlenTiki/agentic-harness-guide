# Chapter 01: Plain spec

## Purpose

This chapter makes vague requests hard to write. You write each spec in simple English. A linter then checks the mechanical rules.

## The rules

1. A sentence in a description has at most 25 words.
2. A sentence in a numbered step has at most 20 words.
3. A sentence names the actor and uses the active voice.
4. A spec avoids the banned vague words.
5. A spec does not use long dashes.
6. A file has a Flesch-Kincaid grade of 9 or lower.

## What the linter can do

The linter counts words. It scores readability with a formula. It looks for banned words from a fixed list. It looks for a form of "to be" followed by a past participle.

## What the linter cannot do

The passive check is a heuristic. It can flag a good sentence and miss a bad one. The linter does not hold the ASD-STE100 approved dictionary. ASD owns the licence for that dictionary. No tool here can check whether the dictionary lists a word. A clean report means the text follows the mechanical rules. It does not mean the text is STE.

## Optional Vale rules

The folder `vale` holds rules in the Vale format. Vale is a separate tool. You install it yourself. The core of this chapter does not need Vale.

## Proof that the check can fail

The file `fixtures/bad/vague.md` breaks every rule. The validator must go red on it.
