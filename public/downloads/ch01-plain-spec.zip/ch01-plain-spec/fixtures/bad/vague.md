# Add a note

The note adding feature is designed to robustly handle various kinds of input and other things, and it was built so that it can be easily extended by whoever happens to be maintaining the code in the future, etc.

1. The text is checked and then the tool is made to write the line to the file as needed.
