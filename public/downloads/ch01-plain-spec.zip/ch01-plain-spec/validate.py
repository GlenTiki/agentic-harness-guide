"""Lint the specs. In the repository this covers specs/ and every chapter SPEC.md. In a kit it covers example/ and SPEC.md.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import plainlint  # noqa: E402


def targets(bad):
    if bad:
        return [HERE / "fixtures" / "bad"]
    repo = HERE.parent.parent
    if HERE.parent.name == "chapters" and (repo / "check.sh").exists():
        return [HERE / "example", repo / "specs", *sorted(repo.glob("chapters/*/SPEC.md"))]
    return [HERE / "example", HERE / "SPEC.md"]


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    findings = plainlint.lint_paths(targets("--bad" in argv))
    for finding in findings:
        print(finding)
    print("validate: PASS" if not findings else f"validate: FAIL ({len(findings)} finding(s))")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
