"""A rule-based plain-English linter for markdown files.

Rules: sentence length, passive voice (a heuristic), banned vague words, dashes and readability grade.
This tool does not check the ASD-STE100 approved dictionary. That dictionary is licensed and cannot be
machine-verified here. Treat a clean report as "follows the mechanical rules", never as "is STE".
"""
import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path

DEFAULT_MAX_WORDS = 25
DEFAULT_PROCEDURE_WORDS = 20
DEFAULT_MAX_GRADE = 9.0

BANNED_WORDS = (
    "etc", "stuff", "thing", "things", "various", "simply", "just", "easy", "easily", "obviously",
    "basically", "appropriate", "robust", "seamless", "and so on", "as needed", "user-friendly",
)

IRREGULAR_PARTICIPLES = (
    "done", "made", "built", "shown", "known", "seen", "given", "taken", "written", "found", "kept",
    "held", "sent", "set", "put", "left", "run", "chosen", "broken", "stored", "begun",
)

BE_FORMS = r"(?:is|are|was|were|be|been|being|am)"
PASSIVE = re.compile(
    rf"\b{BE_FORMS}\s+(?:\w+ly\s+)?(?:\w{{3,}}ed|{'|'.join(IRREGULAR_PARTICIPLES)})\b", re.IGNORECASE
)
LIST_ITEM = re.compile(r"^\s*(?:(\d+)[.)]|[-*])\s+(.*)$")
SENTENCE_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    message: str

    def __str__(self):
        return f"{self.path}:{self.line}: [{self.rule}] {self.message}"


def count_syllables(word):
    word = re.sub(r"[^a-z]", "", word.lower())
    if not word:
        return 0
    groups = re.findall(r"[aeiouy]+", word)
    count = len(groups)
    if word.endswith("e") and not word.endswith(("le", "ee")) and count > 1:
        count -= 1
    return max(count, 1)


def words_in(text):
    return re.findall(r"[A-Za-z0-9][A-Za-z0-9'-]*", text)


def flesch_kincaid_grade(sentences):
    """Grade = 0.39 * words per sentence + 11.8 * syllables per word - 15.59."""
    words = [w for s in sentences for w in words_in(s)]
    if not sentences or not words:
        return 0.0
    syllables = sum(count_syllables(w) for w in words)
    return 0.39 * len(words) / len(sentences) + 11.8 * syllables / len(words) - 15.59


def clean_inline(text):
    text = re.sub(r"`[^`]*`", "X", text)
    text = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"[*_]{1,3}", "", text)


def units(markdown):
    """Yield (line number, is_procedure, text) for each paragraph or list item outside code."""
    in_fence = False
    current = None
    for number, raw in enumerate(markdown.splitlines(), start=1):
        if raw.strip().startswith("```"):
            in_fence = not in_fence
            if current:
                yield current
                current = None
            continue
        stripped = raw.strip()
        item = LIST_ITEM.match(raw)
        skip = in_fence or stripped.startswith(("#", "|", ">", "<!--")) or re.fullmatch(r"[-=*_ ]*", stripped) and stripped
        if skip or not stripped or item:
            if current:
                yield current
                current = None
            if item and not skip:
                current = (number, item.group(1) is not None, item.group(2))
            continue
        if current:
            current = (current[0], current[1], current[2] + " " + stripped)
        else:
            current = (number, False, stripped)
    if current:
        yield current


def split_sentences(text):
    return [s.strip() for s in SENTENCE_END.split(clean_inline(text)) if s.strip()]


def lint_text(markdown, path="<text>", max_words=DEFAULT_MAX_WORDS, procedure_words=DEFAULT_PROCEDURE_WORDS,
              max_grade=DEFAULT_MAX_GRADE):
    findings = []
    all_sentences = []
    for line, is_procedure, text in units(markdown):
        limit = procedure_words if is_procedure else max_words
        for sentence in split_sentences(text):
            all_sentences.append(sentence)
            count = len(words_in(sentence))
            if count > limit:
                findings.append(Finding(path, line, "sentence-length", f"{count} words; the limit is {limit}."))
            if PASSIVE.search(sentence):
                findings.append(Finding(path, line, "passive-heuristic", "Possible passive voice. Name the actor."))
            for banned in BANNED_WORDS:
                if re.search(rf"\b{re.escape(banned)}\b", sentence, re.IGNORECASE):
                    findings.append(Finding(path, line, "vague-word", f"Replace the vague word '{banned}'."))
        if re.search("[\u2013\u2014]", text):
            findings.append(Finding(path, line, "dash", "Use a plain hyphen or a new sentence."))
    grade = flesch_kincaid_grade(all_sentences)
    if grade > max_grade:
        findings.append(Finding(path, 1, "readability", f"Flesch-Kincaid grade {grade:.1f}; the limit is {max_grade}."))
    return findings


def markdown_files(paths):
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            yield from sorted(path.rglob("*.md"))
        else:
            yield path


def lint_paths(paths, **limits):
    findings = []
    for file in markdown_files(paths):
        findings.extend(lint_text(file.read_text(encoding="utf-8"), str(file), **limits))
    return findings


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("paths", nargs="+")
    parser.add_argument("--max-words", type=int, default=DEFAULT_MAX_WORDS)
    parser.add_argument("--procedure-words", type=int, default=DEFAULT_PROCEDURE_WORDS)
    parser.add_argument("--max-grade", type=float, default=DEFAULT_MAX_GRADE)
    args = parser.parse_args(argv)
    findings = lint_paths(args.paths, max_words=args.max_words, procedure_words=args.procedure_words,
                          max_grade=args.max_grade)
    for finding in findings:
        print(finding)
    print(f"plainlint: {len(findings)} finding(s)")
    return 1 if findings else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"plainlint: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
