# Chapter 03: Link resolver

Weak spot removed: docs drift from reality. A link that points at a file or a heading is a claim. This chapter checks the claim. The [SPEC](SPEC.md) for this chapter says exactly what is checked.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `linkcheck.py`.
2. Run it on the good example.
3. Run the validator. In the kit it checks `example/` and the markdown files at the top of the kit (`README.md`, `CHAPTER.md` and `SPEC.md`), so a broken link in this kit is caught.
4. Rename a heading and run the checker again. Copy the example into `scratch/`, rename the heading `Second heading` in the copy, and check the copy. The link `sub/other.md#second-heading` now has no target, so the check goes red.

```sh
python3 -I linkcheck.py example  # exit 0; expect: linkcheck: 0 finding(s); 1 external link(s) not fetched
python3 -I validate.py  # exit 0; expect: validate: PASS
mkdir -p scratch
python3 -I -c "import shutil; shutil.copytree('example', 'scratch/example', dirs_exist_ok=True)"
python3 -I -c "from pathlib import Path; p = Path('scratch/example/sub/other.md'); p.write_text(p.read_text().replace('Second heading', 'Renamed heading'))"
python3 -I linkcheck.py scratch/example  # exit 1; expect: missing-anchor
```

## Expected output

`linkcheck: 0 finding(s); 1 external link(s) not fetched` for the example, and `validate: PASS`. The last command prints a `missing-anchor` finding for `example/good.md` and exits with code 1.

## One readable error

```sh
python3 -I linkcheck.py no-such-folder  # exit 2; expect: linkcheck: No such file or directory
```

## Honest limits

Markdownlint rule MD051 checks anchors in the same document only. It does not check links to other files. This checker covers both. The slug rules follow the author's reading of the GitHub rules and were not compared with github.com. Links to other sites are not fetched.

## Prove the check can fail

Run the validator with `--bad`. It reports a missing file, two missing anchors and a missing image, prints `validate: FAIL (4 finding(s))` and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (4 finding(s))
```
