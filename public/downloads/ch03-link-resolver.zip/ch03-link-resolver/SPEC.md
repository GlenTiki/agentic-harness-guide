# Chapter 03: Link resolver

## Purpose

This chapter keeps documents true. A document that links to a file or heading that is gone is out of date. The checker finds those links.

## What the checker reads

The checker reads markdown files. It ignores fenced code blocks and inline code.

## What the checker must verify

1. A relative link points to a file or folder that exists.
2. A link with an anchor points to a heading that exists in the target file.
3. A link that holds only an anchor points to a heading in the same file.
4. An image path points to a file that exists.
5. A reference-style link definition points to a target that exists.

## How the checker builds an anchor

The checker follows the GitHub heading rules, as the author reads them. It makes the heading lower case. It removes punctuation. It changes each space to a hyphen. A second heading with the same text gets the suffix `-1`. The author did not compare these rules with github.com.

## What the checker does not do

The checker does not fetch external links. It uses no network. The checker counts each external link and does nothing more.

## Output

The checker prints one line for each problem. Each line holds the file, the line number, a rule name and a message. The exit code is 1 when the checker finds a problem.

## Proof that the check can fail

The file `fixtures/bad/broken.md` holds four broken links. The checker must find all four.
