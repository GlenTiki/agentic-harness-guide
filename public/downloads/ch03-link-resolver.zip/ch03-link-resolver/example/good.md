# Good page

See [the other page](sub/other.md) and [its second heading](sub/other.md#second-heading).
Jump to [this page's notes](#notes-and-more) or look at the picture: ![a dot](dot.png).
An [external link](https://example.org/page) is counted but never fetched.

```md
[this link is inside a fence and is ignored](missing.md)
```

A code span `[ignored](also-missing.md)` is ignored too.

## Notes and more

Text. A duplicate heading gets a number.

## Notes and more

Link to the second one: [second](#notes-and-more-1).
