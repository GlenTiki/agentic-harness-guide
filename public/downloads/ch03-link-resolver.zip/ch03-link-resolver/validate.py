"""Check links. In the repository this covers README.md, specs/ and every chapter markdown file. In a kit it covers
example/ and the markdown files at the top of the kit.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import linkcheck  # noqa: E402


def targets(bad):
    if bad:
        return [HERE / "fixtures" / "bad"], HERE
    repo = HERE.parent.parent
    if HERE.parent.name != "chapters" or not (repo / "check.sh").exists():
        return [HERE / "example", *sorted(HERE.glob("*.md"))], HERE
    files = [HERE / "example"]
    files += [p for p in [repo / "README.md"] if p.exists()]
    files += sorted((repo / "specs").glob("*.md"))
    files += sorted(repo.glob("chapters/*/*.md"))
    return files, repo


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    paths, root = targets("--bad" in argv)
    findings, external = linkcheck.check_paths(paths, root)
    for finding in findings:
        print(finding)
    print("validate: PASS" if not findings else f"validate: FAIL ({len(findings)} finding(s))")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
