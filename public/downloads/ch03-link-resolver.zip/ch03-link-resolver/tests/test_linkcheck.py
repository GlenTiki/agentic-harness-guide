import tempfile
import unittest
from pathlib import Path

import linkcheck as lc

HERE = Path(__file__).resolve().parent.parent


class SlugTest(unittest.TestCase):
    def test_slug_rules(self):
        cases = {
            "Hello, World!": "hello-world",
            "Add a note": "add-a-note",
            "`code` and *emphasis*": "code-and-emphasis",
            "Step 1: Do it": "step-1-do-it",
            "A -- B": "a----b",
            "Snake_case stays": "snake_case-stays",
            "Link [text](x.md) here": "link-text-here",
        }
        for heading, slug in cases.items():
            self.assertEqual(lc.github_slug(heading), slug, heading)

    def test_duplicate_headings_get_numbers(self):
        self.assertEqual(lc.anchors_of("# A\n\n## A\n\n## A\n"), {"a", "a-1", "a-2"})

    def test_setext_and_html_anchors(self):
        self.assertEqual(lc.anchors_of('Title\n=====\n\n<a name="here"></a>\n'), {"title", "here"})

    def test_heading_inside_a_fence_is_not_an_anchor(self):
        self.assertEqual(lc.anchors_of("```\n# Not a heading\n```\n"), set())


class CheckTest(unittest.TestCase):
    def check(self, files, name="a.md"):
        with tempfile.TemporaryDirectory() as tmp:
            for rel, body in files.items():
                path = Path(tmp) / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(body, encoding="utf-8")
            findings, external = lc.check_file(Path(tmp) / name, tmp)
            return [f.rule for f in findings], external

    def test_good_relative_link(self):
        self.assertEqual(self.check({"a.md": "[b](b.md)", "b.md": "x"}), ([], 0))

    def test_missing_file(self):
        self.assertEqual(self.check({"a.md": "[b](b.md)"})[0], ["missing-file"])

    def test_directory_link_is_fine(self):
        self.assertEqual(self.check({"a.md": "[d](d/)", "d/x.md": "x"})[0], [])

    def test_anchor_in_other_file(self):
        files = {"a.md": "[b](b.md#top)", "b.md": "# Top\n"}
        self.assertEqual(self.check(files)[0], [])
        files["b.md"] = "# Other\n"
        self.assertEqual(self.check(files)[0], ["missing-anchor"])

    def test_missing_image(self):
        self.assertEqual(self.check({"a.md": "![x](x.png)"})[0], ["missing-image"])

    def test_link_in_fence_and_code_span_is_ignored(self):
        body = "```\n[x](nope.md)\n```\n`[y](nope.md)`\n"
        self.assertEqual(self.check({"a.md": body})[0], [])

    def test_external_links_are_counted_not_fetched(self):
        self.assertEqual(self.check({"a.md": "[x](https://example.org) [m](mailto:someone)"}), ([], 2))

    def test_title_and_angle_brackets_and_encoding(self):
        files = {"a.md": '[x](<my file.md> "t") [y](my%20file.md)', "my file.md": "x"}
        self.assertEqual(self.check(files)[0], [])

    def test_reference_definition(self):
        self.assertEqual(self.check({"a.md": "[x][r]\n\n[r]: gone.md\n"})[0], ["missing-file"])

    def test_root_relative_link(self):
        files = {"docs/a.md": "[x](/top.md)", "top.md": "x"}
        self.assertEqual(self.check(files, name="docs/a.md")[0], [])

    def test_line_numbers(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "a.md").write_text("one\ntwo [x](gone.md)\n", encoding="utf-8")
            findings, _ = lc.check_file(Path(tmp) / "a.md", tmp)
            self.assertEqual(findings[0].line, 2)


class FixtureTest(unittest.TestCase):
    def test_example_is_green_and_bad_is_red(self):
        self.assertEqual(lc.check_paths([HERE / "example"])[0], [])
        rules = sorted(f.rule for f in lc.check_paths([HERE / "fixtures" / "bad"])[0])
        self.assertEqual(rules, ["missing-anchor", "missing-anchor", "missing-file", "missing-image"])


if __name__ == "__main__":
    unittest.main()
