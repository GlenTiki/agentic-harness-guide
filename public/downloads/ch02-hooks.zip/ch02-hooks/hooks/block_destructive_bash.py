"""PreToolUse hook for Bash. Block commands that destroy work. Fail closed on bad input."""
import json
import re
import sys

DANGEROUS = (
    (r"\brm\s+-[a-zA-Z]*(?:rf|fr)\b", "rm with -rf"),
    (r"\bgit\s+push\b.*(?:--force\b|\s-f\b)", "git push --force"),
    (r"\bgit\s+reset\s+--hard\b", "git reset --hard"),
    (r"\bgit\s+clean\s+-[a-zA-Z]*f", "git clean -f"),
)

try:
    command = json.load(sys.stdin)["tool_input"]["command"]
except (ValueError, KeyError, TypeError):
    print("Blocked: this hook could not read the Bash command.", file=sys.stderr)
    sys.exit(2)

for pattern, name in DANGEROUS:
    if re.search(pattern, command):
        print(f"Blocked: {name} destroys work. Ask the user first.", file=sys.stderr)
        sys.exit(2)
