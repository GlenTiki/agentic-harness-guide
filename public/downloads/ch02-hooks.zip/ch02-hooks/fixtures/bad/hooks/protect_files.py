"""PreToolUse hook for Write and Edit. Protect secrets, git internals and the check script."""
import json
import sys
from pathlib import PurePosixPath

PROTECTED_NAMES = {".env", "check.sh"}
PROTECTED_SUFFIXES = (".pem", ".key")

try:
    file_path = json.load(sys.stdin)["tool_input"]["file_path"]
    path = PurePosixPath(file_path)
except (ValueError, KeyError, TypeError):
    print("Blocked: this hook could not read the file path.", file=sys.stderr)
    sys.exit(2)

if path.name in PROTECTED_NAMES or path.name.endswith(PROTECTED_SUFFIXES):
    print(f"Blocked: {path.name} is protected. Ask the user to change it.", file=sys.stderr)
    sys.exit(2)
if ".git" in path.parts or ".." in path.parts:
    print("Blocked: the path is inside .git or climbs out of the project.", file=sys.stderr)
    sys.exit(2)
