"""Stop hook. Refuse to stop while CHECKLIST.md in the project folder has an open item."""
import json
import sys
from pathlib import Path

try:
    event = json.load(sys.stdin)
except ValueError:
    sys.exit(1)

if event.get("stop_hook_active"):
    sys.exit(0)  # already continuing because of this hook; never loop

checklist = Path(event.get("cwd", ".")) / "CHECKLIST.md"
if checklist.exists():
    open_items = [line for line in checklist.read_text(encoding="utf-8").splitlines() if line.startswith("- [ ]")]
    if open_items:
        print(f"Do not stop yet. {len(open_items)} checklist item(s) are open: {open_items[0]}", file=sys.stderr)
        sys.exit(2)
