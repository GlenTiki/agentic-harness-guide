"""PostToolUse hook. Append one JSON line per tool call to the file named by WEAKSPOT_AUDIT_LOG."""
import json
import os
import sys
from datetime import datetime, timezone

event = json.load(sys.stdin)  # bad input raises, exit 1, a non-blocking error
log_path = os.environ.get("WEAKSPOT_AUDIT_LOG")
if log_path:
    record = {
        "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tool": event.get("tool_name"),
        "agent_type": event.get("agent_type"),
    }
    with open(log_path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
