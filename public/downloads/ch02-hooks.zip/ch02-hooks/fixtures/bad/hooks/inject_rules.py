"""UserPromptSubmit hook. Print the standing rules. On exit 0 the stdout becomes context for the agent."""
print("Standing rules: write specs in simple English. Run ./check.sh before you stop. Never edit check.sh.")
