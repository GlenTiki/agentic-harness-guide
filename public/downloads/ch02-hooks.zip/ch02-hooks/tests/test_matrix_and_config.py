import json
import unittest
from pathlib import Path

import dispatch
import matrix

HERE = Path(__file__).resolve().parent.parent


class MatrixTest(unittest.TestCase):
    def test_real_hooks_pass_every_case(self):
        self.assertEqual(matrix.run_matrix(HERE / "hooks.json"), [])

    def test_broken_deny_hook_is_caught(self):
        failures = matrix.run_matrix(HERE / "fixtures" / "bad" / "hooks.json")
        self.assertTrue(any("rm -rf" in f for f in failures))

    def test_matrix_covers_allow_deny_and_malformed(self):
        cases = json.loads((HERE / "matrix.json").read_text(encoding="utf-8"))["cases"]
        self.assertIn(0, {c["exit"] for c in cases})
        self.assertIn(2, {c["exit"] for c in cases})
        self.assertTrue(any("raw" in c for c in cases))

    def test_every_hook_script_has_a_case(self):
        entries = json.loads((HERE / "hooks.json").read_text(encoding="utf-8"))["hooks"]
        text = (HERE / "matrix.json").read_text(encoding="utf-8")
        for entry in entries:
            self.assertIn(entry["event"], text)


class LogHookTest(unittest.TestCase):
    def test_audit_log_gets_a_utc_seconds_record(self):
        import os
        import subprocess
        import sys
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "audit.jsonl"
            event = {"hook_event_name": "PostToolUse", "tool_name": "Bash", "agent_type": "helper"}
            done = subprocess.run([sys.executable, "-I", str(HERE / "hooks" / "log_tool_use.py")], text=True,
                                  input=json.dumps(event), env={**os.environ, "WEAKSPOT_AUDIT_LOG": str(log)})
            self.assertEqual(done.returncode, 0)
            record = json.loads(log.read_text(encoding="utf-8"))
            self.assertEqual((record["tool"], record["agent_type"]), ("Bash", "helper"))
            self.assertRegex(record["time"], r"Z$")


class SettingsPathTest(unittest.TestCase):
    def test_sample_settings_resolve_and_block_a_deny_event(self):
        self.assertEqual(matrix.check_settings(HERE / "claude-settings.example.json"), [])

    def test_sample_with_a_path_from_the_repository_is_caught(self):
        problems = matrix.check_settings(HERE / "fixtures" / "bad" / "claude-settings.json")
        self.assertTrue(any("does not resolve" in p for p in problems), problems)
        self.assertTrue(any("no PreToolUse command covers" in p for p in problems), problems)


class ClaudeSettingsSnippetTest(unittest.TestCase):
    """This checks the shape of the snippet only. It does not run Claude Code."""

    def setUp(self):
        self.settings = json.loads((HERE / "claude-settings.example.json").read_text(encoding="utf-8"))

    def test_shape_matches_the_documented_format(self):
        for event, groups in self.settings["hooks"].items():
            for group in groups:
                for hook in group["hooks"]:
                    self.assertEqual(hook["type"], "command")
                    self.assertIn("dispatch.py", hook["command"])

    def test_every_event_in_hooks_json_is_wired(self):
        entries = json.loads((HERE / "hooks.json").read_text(encoding="utf-8"))["hooks"]
        self.assertEqual({e["event"] for e in entries}, set(self.settings["hooks"]))


if __name__ == "__main__":
    unittest.main()
