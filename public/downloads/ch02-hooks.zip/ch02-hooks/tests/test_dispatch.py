import json
import tempfile
import unittest
from pathlib import Path

import dispatch


class DispatchContractTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.log = self.dir / "log.jsonl"

    def tearDown(self):
        self.tmp.cleanup()

    def config(self, *scripts):
        entries = []
        for index, body in enumerate(scripts):
            name = f"h{index}.py"
            (self.dir / name).write_text(body, encoding="utf-8")
            entries.append({"event": "PreToolUse", "matcher": "Bash", "script": name})
        path = self.dir / "hooks.json"
        path.write_text(json.dumps({"hooks": entries}), encoding="utf-8")
        return path

    def run_event(self, config, event=None, **kw):
        event = event or {"hook_event_name": "PreToolUse", "tool_name": "Bash", "tool_input": {}}
        return dispatch.dispatch(json.dumps(event), config, self.log, **kw)

    def test_exit_two_blocks_and_passes_stderr_on(self):
        code, _, err = self.run_event(self.config("import sys; print('no', file=sys.stderr); sys.exit(2)"))
        self.assertEqual((code, err), (2, "no\n"))

    def test_exit_one_does_not_block_and_is_logged(self):
        code, _, _ = self.run_event(self.config("import sys; print('oops', file=sys.stderr); sys.exit(1)"))
        self.assertEqual(code, 0)
        record = json.loads(self.log.read_text(encoding="utf-8"))
        self.assertEqual((record["problem"], record["exit"], record["stderr"]), ("non-blocking error", 1, "oops"))
        self.assertRegex(record["time"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")

    def test_crash_does_not_block(self):
        self.assertEqual(self.run_event(self.config("raise RuntimeError('x')"))[0], 0)

    def test_timeout_does_not_block_and_is_logged(self):
        code, _, _ = self.run_event(self.config("import time; time.sleep(5)"), timeout=1)
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(self.log.read_text(encoding="utf-8"))["problem"], "timeout")

    def test_stdout_of_allowing_hooks_is_joined(self):
        code, out, _ = self.run_event(self.config("print('a')", "print('b')"))
        self.assertEqual((code, out), (0, "a\nb\n"))

    def test_first_block_stops_later_hooks(self):
        code, out, _ = self.run_event(self.config("import sys; sys.exit(2)", "print('never')"))
        self.assertEqual((code, out), (2, ""))

    def test_hook_with_other_matcher_does_not_run(self):
        event = {"hook_event_name": "PreToolUse", "tool_name": "Read", "tool_input": {}}
        self.assertEqual(self.run_event(self.config("import sys; sys.exit(2)"), event)[0], 0)

    def test_matcher_must_match_the_whole_tool_name(self):
        event = {"hook_event_name": "PreToolUse", "tool_name": "BashOutput", "tool_input": {}}
        self.assertEqual(self.run_event(self.config("import sys; sys.exit(2)"), event)[0], 0)

    def test_hook_receives_the_event_on_stdin(self):
        body = "import json, sys; sys.exit(2 if json.load(sys.stdin)['tool_name'] == 'Bash' else 0)"
        self.assertEqual(self.run_event(self.config(body))[0], 2)

    def test_malformed_event_blocks(self):
        code, _, err = dispatch.dispatch("{oops", self.config("pass"), self.log)
        self.assertEqual(code, 2)
        self.assertIn("not valid JSON", err)

    def test_empty_stdin_blocks(self):
        self.assertEqual(dispatch.dispatch("", self.config("pass"))[0], 2)


if __name__ == "__main__":
    unittest.main()
