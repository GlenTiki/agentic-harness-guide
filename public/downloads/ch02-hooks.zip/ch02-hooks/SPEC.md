# Chapter 02: Hooks

## Purpose

This chapter makes rules run every time. A written rule can be forgotten. A hook cannot be forgotten, because the program runs it.

## Terms

A hook is a script. The agent tool starts the script when a defined event happens. The event is a JSON text sent on standard input. The script answers with its exit code.

## The contract

1. Exit code 0 means allow.
2. Exit code 2 means block. This works on events that can block, such as PreToolUse, UserPromptSubmit and Stop.
3. Any other non-zero exit code is a non-blocking error. The action goes ahead.
4. A policy hook must use exit code 2 to enforce a rule. Exit code 1 does not enforce it.

## The dispatcher

The dispatcher reads one event from standard input. It finds each hook whose event and matcher fit. It runs each hook and sends the event to it.

1. If a hook exits with code 2, the dispatcher stops and exits with code 2.
2. If a hook exits with another non-zero code, the dispatcher logs it and goes on.
3. If a hook runs too long, the dispatcher logs it and goes on.
4. If the event is not valid JSON, the dispatcher exits with code 2.

The last rule is a choice made in this kit. It makes the dispatcher fail closed.

## The five example hooks

1. A Bash hook blocks `rm -rf`, force push, hard reset and `git clean -f`.
2. A file hook blocks writes to secrets, to `check.sh` and to `.git`.
3. A logging hook records each tool call with a UTC time stamp.
4. A prompt hook adds the standing rules to the context.
5. A stop hook blocks stopping while the checklist has an open item.

## Known limits

The Bash hook matches text patterns. It misses `rm -r -f` and other spellings. It is a safety net, not a sandbox.

## What was tested

The test matrix covers the dispatcher and the hooks. A test checks the shape of the Claude Code settings snippet. Nobody ran the snippet in Claude Code.

## Proof that the check can fail

The folder `fixtures/bad` holds a copy of the hooks where the Bash hook exits with code 1. The matrix must go red on that copy.
