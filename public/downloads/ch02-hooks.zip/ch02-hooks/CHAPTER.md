# Chapter 02: Hooks

Weak spot removed: the agent forgets the rules. A rule in a document is advice. A hook is enforcement.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `dispatch.py` and the five scripts in `hooks/`.
2. Read `hooks.json`. It maps each event and tool name to a script.
3. Run the matrix. The validator also installs the kit into a scratch project and follows the commands in `claude-settings.example.json`.
4. Pipe an event into the dispatcher by hand. You see a message on stderr and `exit=2`.
5. Point the dispatcher at a config that does not exist. It still blocks, because a policy hook fails closed. Exit code 1 would let every action through.

```sh
python3 -I validate.py  # exit 0; expect: validate: PASS
echo '{"hook_event_name":"PreToolUse","tool_name":"Bash","tool_input":{"command":"rm -rf x"}}' | python3 -I dispatch.py; echo "exit=$?"  # exit 0; expect: exit=2
echo '{}' | python3 -I dispatch.py --config scratch/no-such.json; echo "exit=$?"  # exit 0; expect: exit=2
```

## Use it in Claude Code

Copy `dispatch.py`, `hooks.json` and the `hooks/` folder from this kit into `.claude/harness-hooks/` in your project. Then merge `claude-settings.example.json` into `.claude/settings.json`. The commands in it name `${CLAUDE_PROJECT_DIR}/.claude/harness-hooks/dispatch.py`. If you put the files somewhere else, change that path in the settings. A path that does not exist makes the hook fail on every call, and the validator in this kit checks the sample path for that reason.

## Expected output

`validate: PASS`. The by-hand command in step 4 prints `Blocked: rm with -rf destroys work. Ask the user first.` and `exit=2`.

The validator prints `validate: PASS` when all 19 cases in `matrix.json` give the expected exit code and the settings sample resolves and blocks a deny event. It prints one `FAIL` line for each problem.

## What is verified and what is not

Verified here: the dispatcher contract, all five hooks, 19 matrix cases (allow, deny, malformed input) and the path in the settings sample. Not verified here: the behaviour inside a live Claude Code session. The settings snippet follows the documented shape (an event name, a list of groups with an optional matcher, a list of hooks with `type` and `command`). The tests check that shape and that the path resolves. The claims about exit codes come from the Claude Code hooks documentation, and the tests run against this dispatcher, not against Claude Code.

## Prove the check can fail

Run the validator with `--bad`. The bad copy has a Bash hook that exits with code 1, and its settings sample uses a path that does not exist in a kit. The validator reports four failed cases and two settings problems, and exits with code 1. Exit code 1 looks like a block but does not block.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (6 problem(s))
```
