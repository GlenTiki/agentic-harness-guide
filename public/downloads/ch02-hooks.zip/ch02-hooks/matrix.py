"""Run the allow / deny / malformed matrix through the dispatcher. Shared by the tests and validate.py."""
import json
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import dispatch

HERE = Path(__file__).resolve().parent


def run_matrix(config_path, matrix_path=HERE / "matrix.json"):
    """Return a list of failure strings. An empty list means every case behaved as expected."""
    cases = json.loads(Path(matrix_path).read_text(encoding="utf-8"))["cases"]
    failures = []
    with tempfile.TemporaryDirectory() as tmp:
        empty = Path(tmp) / "empty"
        open_dir = Path(tmp) / "open"
        empty.mkdir()
        open_dir.mkdir()
        (open_dir / "CHECKLIST.md").write_text("- [x] done\n- [ ] still to do\n", encoding="utf-8")
        for case in cases:
            raw = case["raw"] if "raw" in case else json.dumps(case["event"])
            raw = raw.replace("@EMPTY_DIR@", str(empty)).replace("@OPEN_DIR@", str(open_dir))
            code, _, _ = dispatch.dispatch(raw, config_path)
            if code != case["exit"]:
                failures.append(f"{case['name']}: expected exit {case['exit']}, got {code}")
    return failures


INSTALL_DIR = ".claude/harness-hooks"
INSTALL_FILES = ("dispatch.py", "hooks.json", "hooks")
DENY_EVENT = {"hook_event_name": "PreToolUse", "tool_name": "Bash", "tool_input": {"command": "rm -rf build"}}


def check_settings(settings_path, source=HERE):
    """Install the kit at INSTALL_DIR in a scratch project, then follow every command in the settings sample.

    Return a list of problems. A command whose script path does not resolve is a problem, because Claude Code would
    run a path that is not there. The command that covers Bash must also block the deny event with exit 2.
    """
    settings = json.loads(Path(settings_path).read_text(encoding="utf-8"))
    problems = []
    with tempfile.TemporaryDirectory() as tmp:
        project = Path(tmp)
        target = project / INSTALL_DIR
        target.mkdir(parents=True)
        for name in INSTALL_FILES:
            item = Path(source) / name
            if item.is_dir():
                shutil.copytree(item, target / name, ignore=shutil.ignore_patterns("__pycache__"))
            else:
                shutil.copy(item, target / name)
        covers_bash = False
        for event, groups in settings["hooks"].items():
            for group in groups:
                for hook in group["hooks"]:
                    words = shlex.split(hook["command"].replace("${CLAUDE_PROJECT_DIR}", str(project)))
                    script = Path(words[-1])
                    if not script.is_file():
                        problems.append(f"settings {event}: the command path {hook['command']!r} does not resolve to a file "
                                        f"when the kit sits in {INSTALL_DIR}.")
                        continue
                    if event == "PreToolUse" and re.fullmatch(group.get("matcher", "*"), "Bash"):
                        covers_bash = True
                        done = subprocess.run([sys.executable, *words[1:]], input=json.dumps(DENY_EVENT), text=True,
                                              capture_output=True)
                        if done.returncode != 2:
                            problems.append(f"settings PreToolUse: the command did not block a deny event (exit {done.returncode}).")
        if not covers_bash:
            problems.append("settings: no PreToolUse command covers the Bash tool.")
    return problems
