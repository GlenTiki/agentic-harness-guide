"""Run the hook matrix against the real hooks. With --bad, run it against a copy whose deny hook is broken.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import matrix  # noqa: E402


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    config = HERE / ("fixtures/bad/hooks.json" if "--bad" in argv else "hooks.json")
    settings = HERE / ("fixtures/bad/claude-settings.json" if "--bad" in argv else "claude-settings.example.json")
    failures = matrix.run_matrix(config) + matrix.check_settings(settings)
    for failure in failures:
        print(f"FAIL {failure}")
    print("validate: PASS" if not failures else f"validate: FAIL ({len(failures)} problem(s))")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
