"""Hook dispatcher. Read one JSON event on stdin, run the matching hook scripts, report one result.

Contract (the same one Claude Code documents for command hooks):
  exit 0   allow. Plain stdout from the hooks is passed on.
  exit 2   block. The stderr text of the blocking hook is passed on.
  other    non-blocking error. The dispatcher logs it and allows the action.

Policy choices that belong to this kit, not to Claude Code:
  - A malformed event makes the dispatcher block (exit 2). A policy hook should fail closed.
  - A hook config that is missing or unreadable also blocks, because exit 1 would let every action through.
  - A hook that runs longer than the timeout counts as a non-blocking error.
"""
import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_TIMEOUT_SECONDS = 10
BLOCK = 2


def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def log_record(log_path, record):
    if not log_path:
        return
    with Path(log_path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"time": utc_now(), **record}, sort_keys=True) + "\n")


def matches(entry, event):
    if entry["event"] != event.get("hook_event_name"):
        return False
    matcher = entry.get("matcher", "*")
    return matcher == "*" or re.fullmatch(matcher, event.get("tool_name", "")) is not None


def run_hooks(event, entries, hooks_dir, log_path=None, timeout=DEFAULT_TIMEOUT_SECONDS):
    """Return (exit code, stdout text, stderr text)."""
    stdout_parts = []
    payload = json.dumps(event)
    for entry in entries:
        if not matches(entry, event):
            continue
        script = Path(hooks_dir) / entry["script"]
        try:
            done = subprocess.run([sys.executable, "-I", str(script)], input=payload, capture_output=True,
                                  text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            log_record(log_path, {"script": entry["script"], "problem": "timeout"})
            continue
        if done.returncode == BLOCK:
            return BLOCK, "".join(stdout_parts), done.stderr
        if done.returncode != 0:
            log_record(log_path, {"script": entry["script"], "problem": "non-blocking error",
                                  "exit": done.returncode, "stderr": done.stderr.strip()[:500]})
            continue
        stdout_parts.append(done.stdout)
    return 0, "".join(stdout_parts), ""


def dispatch(raw_event, config_path, log_path=None, timeout=DEFAULT_TIMEOUT_SECONDS):
    try:
        event = json.loads(raw_event)
        if not isinstance(event, dict):
            raise ValueError("The event must be a JSON object.")
    except ValueError as error:
        log_record(log_path, {"problem": "malformed event", "detail": str(error)[:200]})
        return BLOCK, "", f"Blocked: the hook event is not valid JSON ({error}).\n"
    config_path = Path(config_path)
    try:
        entries = json.loads(config_path.read_text(encoding="utf-8"))["hooks"]
    except (OSError, ValueError, KeyError, TypeError) as error:
        log_record(log_path, {"problem": "unreadable config", "detail": str(error)[:200]})
        return BLOCK, "", f"Blocked: the hook config {config_path} cannot be read ({error}).\n"
    return run_hooks(event, entries, config_path.parent, log_path, timeout)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--config", default=str(Path(__file__).resolve().parent / "hooks.json"))
    parser.add_argument("--log", default=None)
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS)
    args = parser.parse_args(argv)
    code, out, err = dispatch(sys.stdin.read(), args.config, args.log, args.timeout)
    sys.stdout.write(out)
    sys.stderr.write(err)
    return code


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"Blocked: dispatch cannot use {error.filename}: {error.strerror or error}.", file=sys.stderr)
        return BLOCK


if __name__ == "__main__":
    sys.exit(run())
