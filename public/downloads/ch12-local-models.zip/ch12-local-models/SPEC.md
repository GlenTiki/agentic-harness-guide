# Chapter 12: Local models

## Purpose

This chapter cuts the token cost and keeps data on your machine. A small local model turns text into vectors. A background job keeps those vectors up to date. Everything here is optional. All tests pass without a model.

## Part 1: local embeddings

1. The embedder sends text to a local Ollama server. It calls `POST /api/embed`. The Ollama documentation says the call returns normalised vectors.
2. The embedder refuses an address that is not on this machine, unless you pass a flag.
3. The embedder ignores proxy settings, so a local call stays local.
4. The embedder checks the reply. It rejects a wrong count, vectors of different sizes, empty vectors and values that are not finite numbers.
5. A hashing embedder gives a stand-in for tests. It matches shared words only. It is not semantic.

## Part 2: fusing two rankings

Reciprocal rank fusion adds `1 / (k + rank)` for each list that holds a name. This chapter uses k = 60. The fused order is repeatable, because ties break by name.

## Part 3: the background indexing job

The job embeds the text files of a folder and keeps the vectors in one index file.

1. The job embeds only files that are new or changed. It compares the SHA-256 hash of each file.
2. The job removes the entries of deleted files.
3. The job saves the index after every batch. A crash loses at most one batch.
4. The job takes a lock file. A second job stops with an error. A lock older than one hour counts as stale and the next job takes it over.
5. The job writes a status file with the state, the counts and a UTC time.
6. If the model name changes, the job embeds every file again. Vectors from two models do not compare.
7. If a time budget runs out, the job stops between batches and reports the state `partial`.
8. The job can run at low priority. Start it with `nice -n 10`, or pass `--nice 10`.

## Part 4: models larger than memory

This part lists options. It gives no speed numbers, because the author made no measurement.

1. llama.cpp memory-maps models by default. It can lock a model in RAM. It can place a chosen number of layers in GPU memory.
2. An Apple paper, "LLM in a flash", describes how to run models up to about twice the size of DRAM. The method loads weights from flash storage. It is a paper, not a shipped tool.
3. AirLLM is a Python library. It loads one layer at a time, so a large model fits a small GPU. Its page gives no speed benchmarks. On a Mac it needs Apple silicon with MLX and a Llama-style model.
4. MLX is an array framework for Apple silicon with unified memory. This guide makes no claim that MLX runs models larger than RAM.
5. Ollama can split a model between GPU and CPU. The command `ollama ps` shows the split. The Ollama FAQ does not describe the case where a model is larger than the total memory.
6. Ollama had no native rerank at the time of writing. The feature request was still open in mid-2026. Use sentence-transformers as in chapter 06, or llama.cpp.

## What the tests prove

The tests use fake servers and the hashing embedder. They prove the request shape, the checks on the reply, the job's resume, lock and time budget, and the ranking maths. One live test needs a running Ollama and runs only when you set `RUN_LIVE_OLLAMA=1`.

## Proof that the check can fail

The folder `fixtures/bad` holds an index that does not match its documents. The index is stale in three ways. One file changed after the job embedded it. One entry belongs to a deleted file. One file has no entry. The validator must report three problems.
