"""A background indexing job that is safe to stop, restart and run twice.

The job embeds the text files of a folder and keeps the vectors in one JSON index file.
  - It embeds only files that are new or changed (SHA-256 of the file bytes).
  - It drops entries for deleted files.
  - It saves the index after every batch, so a stop or a crash loses at most one batch.
  - It takes a lock file so that two jobs do not write the index together. A lock older than `stale_seconds` is taken over.
  - It writes a small status file that other tools can read.
  - If the model name changes, it embeds everything again, because vectors from two models cannot be compared.
Run it at low priority: nice -n 10 python3 -I indexer.py ...   (--nice 10 does the same inside the program).
"""
import argparse
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # python -I does not add the script folder
import embed  # noqa: E402

DEFAULT_BATCH = 16
STALE_LOCK_SECONDS = 3600


class LockedError(RuntimeError):
    pass


def stamp(now=None):
    return (now or datetime.now(timezone.utc)).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_index(path):
    path = Path(path)
    if not path.exists():
        return {"model": None, "entries": {}}
    return json.loads(path.read_text(encoding="utf-8"))


def save_index(path, index):
    temporary = Path(f"{path}.tmp")
    temporary.write_text(json.dumps(index, sort_keys=True), encoding="utf-8")
    os.replace(temporary, path)


def write_status(status_path, state, done, total, message="", now=None):
    if status_path:
        save_index(status_path, {"state": state, "done": done, "total": total, "message": message, "updated": stamp(now)})


class Lock:
    def __init__(self, path, stale_seconds=STALE_LOCK_SECONDS, now=time.time):
        self.path, self.stale_seconds, self.now = Path(path), stale_seconds, now

    def __enter__(self):
        for _ in range(2):
            try:
                descriptor = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if self.now() - self.path.stat().st_mtime < self.stale_seconds:
                    raise LockedError(f"Another job holds {self.path}.") from None
                self.path.unlink()
                continue
            os.write(descriptor, f"{os.getpid()} {stamp()}\n".encode("utf-8"))
            os.close(descriptor)
            return self
        raise LockedError(f"Could not take {self.path}.")

    def __exit__(self, *exc):
        self.path.unlink(missing_ok=True)


def run_once(folder, index_path, embedder, model, batch_size=DEFAULT_BATCH, max_seconds=None, status_path=None,
             clock=time.monotonic, now=None):
    """Return {'embedded', 'removed', 'remaining', 'state'}. Raises the embedder's error after saving progress."""
    folder, started = Path(folder), clock()
    files = {str(p.relative_to(folder)): p for p in sorted(folder.rglob("*.md"))}
    with Lock(f"{index_path}.lock"):
        index = load_index(index_path)
        if index.get("model") != model:
            index = {"model": model, "entries": {}}
        entries = index["entries"]
        removed = [name for name in entries if name not in files]
        for name in removed:
            del entries[name]
        hashes = {name: digest(path) for name, path in files.items()}
        todo = [name for name in files if entries.get(name, {}).get("sha256") != hashes[name]]
        total, embedded = len(todo), 0
        write_status(status_path, "running", 0, total, now=now)
        try:
            for start in range(0, len(todo), batch_size):
                if max_seconds is not None and clock() - started > max_seconds:
                    save_index(index_path, index)
                    write_status(status_path, "partial", embedded, total, "Time budget used.", now)
                    return {"embedded": embedded, "removed": len(removed), "remaining": total - embedded, "state": "partial"}
                batch = todo[start:start + batch_size]
                vectors = embedder.embed_documents([files[n].read_text(encoding="utf-8") for n in batch])
                for name, vector in zip(batch, vectors):
                    entries[name] = {"sha256": hashes[name], "vector": vector}
                embedded += len(batch)
                save_index(index_path, index)
        except Exception as error:
            save_index(index_path, index)
            write_status(status_path, "failed", embedded, total, str(error)[:300], now)
            raise
        save_index(index_path, index)
        write_status(status_path, "idle", embedded, total, now=now)
        return {"embedded": embedded, "removed": len(removed), "remaining": 0, "state": "idle"}


def verify_index(folder, index_path, model=None):
    """Return problems: the index must match the folder, byte for byte, by hash."""
    folder, index = Path(folder), load_index(index_path)
    problems = []
    if model and index.get("model") != model:
        problems.append(f"The index model is {index.get('model')}, not {model}.")
    files = {str(p.relative_to(folder)): p for p in sorted(folder.rglob("*.md"))}
    entries = index["entries"]
    problems += [f"{n}: no entry in the index." for n in files if n not in entries]
    problems += [f"{n}: the index has an entry for a file that no longer exists." for n in entries if n not in files]
    sizes = set()
    for name, path in files.items():
        if name in entries:
            if entries[name]["sha256"] != digest(path):
                problems.append(f"{name}: the file changed after it was embedded.")
            sizes.add(len(entries[name]["vector"]))
    if len(sizes) > 1:
        problems.append("The index holds vectors of different sizes.")
    return problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("folder")
    parser.add_argument("--index", required=True)
    parser.add_argument("--status")
    parser.add_argument("--embedder", choices=["hash", "ollama"], default="hash")
    parser.add_argument("--model", default=embed.DEFAULT_MODEL)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH)
    parser.add_argument("--max-seconds", type=float)
    parser.add_argument("--nice", type=int, help="lower this process's priority by this amount")
    args = parser.parse_args(argv)
    if not Path(args.folder).exists():
        raise FileNotFoundError(2, "No such file or directory", str(args.folder))
    if args.nice:
        os.nice(args.nice)
    embedder = embed.OllamaEmbedder(args.model) if args.embedder == "ollama" else embed.HashEmbedder()
    model = args.model if args.embedder == "ollama" else f"hash-{embedder.dims}"
    result = run_once(args.folder, args.index, embedder, model, args.batch_size, args.max_seconds, args.status)
    print(json.dumps(result))
    return 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"indexer: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
