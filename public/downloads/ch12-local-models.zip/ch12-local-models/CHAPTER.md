# Chapter 12: Local models

Weak spot removed: everything costs tokens. Embedding text locally costs no tokens and sends nothing off the machine. A small model finds the right memory, and a large model is saved for the work that needs it.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Run the evaluation with the hashing stand-in. It needs no model.
2. Index the example documents. Run it a second time. The second run embeds 0 files.
3. Run the validator.
4. Optional. Install Ollama, then pull the model and run the evaluation with the real model. Add `--nomic-prefixes` for the prefix variants in the table below. This kit does not run these commands, because they need Ollama and a model download.
5. Optional. Run the live test.
6. Optional. Index with the real model at low priority.

```sh
python3 -I dense_eval.py  # exit 0; expect: (44 memories, 34 queries
mkdir -p scratch
python3 -I indexer.py example/docs --index scratch/index.json --status scratch/status.json  # exit 0; expect: "embedded": 3
python3 -I indexer.py example/docs --index scratch/index.json --status scratch/status.json  # exit 0; expect: "embedded": 0
python3 -I validate.py  # exit 0; expect: validate: PASS
```

```sh optional
ollama pull nomic-embed-text
nice -n 10 python3 -I dense_eval.py --ollama
RUN_LIVE_OLLAMA=1 python3 -I -m unittest discover -s tests -t . -k Live
python3 -I indexer.py example/docs --index scratch/index2.json --embedder ollama --nice 10
```

## One readable error

```sh
python3 -I indexer.py no-such-folder --index scratch/i.json  # exit 2; expect: indexer: No such file or directory
```

## Measured results

The evaluation set is the one from chapter 06 (a copy sits in `evalset/`): 44 memories and 34 queries that a person labelled. The model is `nomic-embed-text` (137M parameters, 768 dimensions, as `ollama show` reported), run through Ollama on one laptop. The runs repeated with the same numbers.

| system | precision@3 | hit@3 | MRR |
| --- | --- | --- | --- |
| bm25 | 0.265 | 0.794 | 0.643 |
| dense, nomic-embed-text | 0.333 | 0.941 | 0.905 |
| hybrid, reciprocal rank fusion | 0.275 | 0.824 | 0.795 |
| dense, with the model's search prefixes | 0.333 | 0.971 | 0.911 |
| hybrid, with the model's search prefixes | 0.275 | 0.824 | 0.808 |

For comparison, chapter 06 measured a cross-encoder on the same set: hit@3 0.794 and MRR 0.803.

What the numbers say. On this set, dense retrieval found a correct memory in the top three for 32 of 34 queries, against 27 for BM25. The fusion with BM25 scored lower than dense alone. The author did not investigate why. The prefix variant is one query better on hit@3, which is within noise on 34 queries. The set is small, written by one person and built to use other words than the memories. It does not show that dense retrieval is better in general. Measure on your own memories.

The whole run (embedding 44 memories and 34 queries) took between 0.7 and 1.3 seconds across the runs on one machine. That includes a warm-up. It is one machine on one day.

## Honest limits

The hashing embedder is for tests. It scored below BM25 on this set, as expected, because it only matches shared words. Part 4 of the spec lists options for models larger than memory. None was run for this chapter, and the spec gives no speed numbers on purpose.

## Prove the check can fail

Run the validator with `--bad`. It reports three problems and exits with code 1: a file that changed after it was embedded, an entry for a deleted file, and a file with no entry.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (3 problem(s))
```
