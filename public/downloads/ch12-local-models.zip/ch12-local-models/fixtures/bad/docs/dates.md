# Dates

People type dates as day, month, year. Store the value as an ISO date in UTC.

An edit made after the index was built.
