"""Check that the example vector index matches its documents. With --bad, check a stale copy.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import indexer  # noqa: E402


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    base = HERE / ("fixtures/bad" if "--bad" in argv else "example")
    problems = indexer.verify_index(base / "docs", base / "index.json", "hash-256")
    for problem in problems:
        print(f"FAIL {problem}")
    print("validate: PASS" if not problems else f"validate: FAIL ({len(problems)} problem(s))")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
