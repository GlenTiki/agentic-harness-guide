"""Local embeddings and rank fusion. Nothing here leaves the machine.

OllamaEmbedder   calls POST /api/embed on a local Ollama server. It refuses a non-loopback address unless you
                 pass allow_remote=True, and it ignores proxy settings so that a local call stays local.
HashEmbedder     a deterministic bag-of-words hashing embedder. It needs nothing and it is NOT semantic. Use it for
                 tests and for wiring. It matches shared words only.
rrf              reciprocal rank fusion of several rankings.
"""
import hashlib
import json
import math
import sys
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))  # python -I does not add the script folder
from bm25 import tokenize  # noqa: E402

LOOPBACK_HOSTS = ("127.0.0.1", "localhost", "::1")
DEFAULT_MODEL = "nomic-embed-text"
RRF_K = 60


class EmbeddingError(RuntimeError):
    pass


def local_opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({})).open


class OllamaEmbedder:
    def __init__(self, model=DEFAULT_MODEL, base_url="http://127.0.0.1:11434", timeout=60, opener=None,
                 allow_remote=False, document_prefix="", query_prefix=""):
        if urlparse(base_url).hostname not in LOOPBACK_HOSTS and not allow_remote:
            raise ValueError("Refusing a non-local address. Pass allow_remote=True to send text to another host.")
        self.model, self.base_url, self.timeout = model, base_url.rstrip("/"), timeout
        self.opener = opener or local_opener()
        self.document_prefix, self.query_prefix = document_prefix, query_prefix

    def embed(self, texts):
        texts = list(texts)
        body = json.dumps({"model": self.model, "input": texts}).encode("utf-8")
        request = urllib.request.Request(f"{self.base_url}/api/embed", data=body,
                                         headers={"Content-Type": "application/json"})
        try:
            with self.opener(request, timeout=self.timeout) as response:
                vectors = json.load(response)["embeddings"]
        except (urllib.error.URLError, OSError) as error:
            raise EmbeddingError(f"Ollama is not reachable at {self.base_url}: {error}") from error
        except (ValueError, KeyError) as error:
            raise EmbeddingError(f"Ollama sent a reply this code cannot read: {error!r}") from error
        check_vectors(vectors, len(texts))
        return vectors

    def embed_documents(self, texts):
        return self.embed([self.document_prefix + t for t in texts])

    def embed_query(self, text):
        return self.embed([self.query_prefix + text])[0]


class HashEmbedder:
    def __init__(self, dims=256):
        self.dims = dims

    def vector(self, text):
        values = [0.0] * self.dims
        for token in tokenize(text):
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            values[int.from_bytes(digest[:4], "big") % self.dims] += 1.0 if digest[4] % 2 else -1.0
        norm = math.sqrt(sum(v * v for v in values))
        return [v / norm for v in values] if norm else values

    def embed(self, texts):
        return [self.vector(t) for t in texts]

    embed_documents = embed

    def embed_query(self, text):
        return self.vector(text)


def check_vectors(vectors, expected_count):
    if not isinstance(vectors, list) or len(vectors) != expected_count:
        raise EmbeddingError(f"Expected {expected_count} vectors.")
    dims = {len(v) for v in vectors}
    if len(dims) > 1 or 0 in dims:
        raise EmbeddingError("The vectors have different or empty sizes.")
    for vector in vectors:
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in vector):
            raise EmbeddingError("A vector holds a value that is not a finite number.")


def cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    norm = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
    return dot / norm if norm else 0.0


def dense_rank(query_vector, names, vectors):
    """Return names best first. Ties break by name so the order is repeatable."""
    scored = sorted(((-round(cosine(query_vector, v), 6), n) for n, v in zip(names, vectors)))
    return [name for _, name in scored]


def rrf(rankings, k=RRF_K):
    """Reciprocal rank fusion. Each ranking is a list of names, best first. Returns names best first."""
    scores = {}
    for ranking in rankings:
        for position, name in enumerate(ranking, start=1):
            scores[name] = scores.get(name, 0.0) + 1.0 / (k + position)
    return [name for name, _ in sorted(scores.items(), key=lambda item: (-round(item[1], 12), item[0]))]
