import json
import os
import tempfile
import time
import unittest
from pathlib import Path

import embed
import indexer

HERE = Path(__file__).resolve().parent.parent


class CountingEmbedder(embed.HashEmbedder):
    def __init__(self, fail_on_call=None):
        super().__init__()
        self.calls, self.fail_on_call = [], fail_on_call

    def embed_documents(self, texts):
        self.calls.append(len(texts))
        if self.fail_on_call == len(self.calls):
            raise embed.EmbeddingError("the server went away")
        return super().embed_documents(texts)


class IndexerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.docs = Path(self.tmp.name) / "docs"
        self.docs.mkdir()
        for name in "abcde":
            (self.docs / f"{name}.md").write_text(f"# {name}\n\nbody of {name}\n", encoding="utf-8")
        self.index = Path(self.tmp.name) / "index.json"
        self.status = Path(self.tmp.name) / "status.json"

    def run_job(self, embedder, **kw):
        return indexer.run_once(self.docs, self.index, embedder, "m1", status_path=self.status, **kw)

    def test_first_run_embeds_everything_and_second_run_embeds_nothing(self):
        e = CountingEmbedder()
        self.assertEqual(self.run_job(e)["embedded"], 5)
        self.assertEqual(self.run_job(e)["embedded"], 0)
        self.assertEqual(indexer.verify_index(self.docs, self.index, "m1"), [])

    def test_only_the_changed_file_is_embedded_again(self):
        e = CountingEmbedder()
        self.run_job(e)
        (self.docs / "c.md").write_text("changed", encoding="utf-8")
        self.assertEqual(self.run_job(e)["embedded"], 1)

    def test_deleted_file_is_dropped(self):
        e = CountingEmbedder()
        self.run_job(e)
        (self.docs / "a.md").unlink()
        self.assertEqual(self.run_job(e)["removed"], 1)
        self.assertNotIn("a.md", json.loads(self.index.read_text(encoding="utf-8"))["entries"])

    def test_model_change_embeds_everything_again(self):
        e = CountingEmbedder()
        self.run_job(e)
        result = indexer.run_once(self.docs, self.index, e, "m2")
        self.assertEqual(result["embedded"], 5)

    def test_failure_keeps_progress_and_the_next_run_resumes(self):
        failing = CountingEmbedder(fail_on_call=2)
        with self.assertRaises(embed.EmbeddingError):
            self.run_job(failing, batch_size=2)
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertEqual((status["state"], status["done"], status["total"]), ("failed", 2, 5))
        self.assertIn("went away", status["message"])
        resume = CountingEmbedder()
        self.assertEqual(self.run_job(resume, batch_size=2)["embedded"], 3)
        self.assertEqual(indexer.verify_index(self.docs, self.index, "m1"), [])

    def test_failed_run_releases_the_lock(self):
        with self.assertRaises(embed.EmbeddingError):
            self.run_job(CountingEmbedder(fail_on_call=1))
        self.assertFalse(Path(f"{self.index}.lock").exists())

    def test_time_budget_stops_between_batches(self):
        ticks = iter([0, 0, 100, 100, 100])
        result = self.run_job(CountingEmbedder(), batch_size=2, max_seconds=10, clock=lambda: next(ticks))
        self.assertEqual((result["state"], result["embedded"], result["remaining"]), ("partial", 2, 3))
        self.assertEqual(json.loads(self.status.read_text(encoding="utf-8"))["state"], "partial")

    def test_status_time_is_utc_seconds_z(self):
        self.run_job(CountingEmbedder())
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertRegex(status["updated"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
        self.assertEqual(status["state"], "idle")

    def test_second_job_is_locked_out(self):
        with indexer.Lock(f"{self.index}.lock"):
            with self.assertRaises(indexer.LockedError):
                self.run_job(CountingEmbedder())

    def test_stale_lock_is_taken_over(self):
        lock = Path(f"{self.index}.lock")
        lock.write_text("old", encoding="utf-8")
        old = time.time() - indexer.STALE_LOCK_SECONDS - 5
        os.utime(lock, (old, old))
        self.assertEqual(self.run_job(CountingEmbedder())["embedded"], 5)

    def test_save_is_atomic_no_temporary_file_remains(self):
        self.run_job(CountingEmbedder())
        self.assertEqual([p.name for p in self.index.parent.glob("*.tmp")], [])


class VerifyTest(unittest.TestCase):
    def test_example_is_clean(self):
        self.assertEqual(indexer.verify_index(HERE / "example" / "docs", HERE / "example" / "index.json", "hash-256"), [])

    def test_bad_copy_has_three_problems(self):
        problems = indexer.verify_index(HERE / "fixtures" / "bad" / "docs", HERE / "fixtures" / "bad" / "index.json", "hash-256")
        self.assertEqual(len(problems), 3)

    def test_wrong_model_is_reported(self):
        problems = indexer.verify_index(HERE / "example" / "docs", HERE / "example" / "index.json", "other")
        self.assertIn("The index model is hash-256, not other.", problems)


if __name__ == "__main__":
    unittest.main()
