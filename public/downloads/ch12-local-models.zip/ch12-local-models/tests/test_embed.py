import http.server
import io
import json
import os
import threading
import unittest
import urllib.error
import urllib.request

import embed
import dense_eval


class FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def opener_returning(payload, seen=None):
    def opener(request, timeout=None):
        if seen is not None:
            seen.append((request.full_url, json.loads(request.data), timeout))
        return FakeResponse(json.dumps(payload).encode("utf-8"))
    return opener


class OllamaEmbedderTest(unittest.TestCase):
    def test_request_shape_and_result(self):
        seen = []
        client = embed.OllamaEmbedder(opener=opener_returning({"embeddings": [[1.0, 0.0], [0.0, 1.0]]}, seen))
        self.assertEqual(client.embed(["a", "b"]), [[1.0, 0.0], [0.0, 1.0]])
        url, body, timeout = seen[0]
        self.assertEqual((url, body["model"], body["input"], timeout), ("http://127.0.0.1:11434/api/embed", "nomic-embed-text", ["a", "b"], 60))

    def test_prefixes_apply_to_documents_and_queries_separately(self):
        seen = []
        client = embed.OllamaEmbedder(opener=opener_returning({"embeddings": [[1.0]]}, seen), document_prefix="D: ", query_prefix="Q: ")
        client.embed_documents(["x"])
        client.embed_query("y")
        self.assertEqual([s[1]["input"] for s in seen], [["D: x"], ["Q: y"]])

    def test_non_local_address_is_refused(self):
        with self.assertRaises(ValueError):
            embed.OllamaEmbedder(base_url="http://example.org:11434")
        embed.OllamaEmbedder(base_url="http://example.org:11434", allow_remote=True)

    def test_loopback_names_are_accepted(self):
        for url in ("http://localhost:11434", "http://127.0.0.1:1", "http://[::1]:11434"):
            embed.OllamaEmbedder(base_url=url)

    def test_real_http_call_to_a_loopback_server_ignores_proxy_environment(self):
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                self.rfile.read(int(self.headers["Content-Length"]))
                body = json.dumps({"embeddings": [[0.5, 0.5]]}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        saved = {k: os.environ.get(k) for k in ("http_proxy", "HTTP_PROXY")}
        os.environ["http_proxy"] = os.environ["HTTP_PROXY"] = "http://127.0.0.1:9"
        self.addCleanup(lambda: [os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v) for k, v in saved.items()])
        client = embed.OllamaEmbedder(base_url=f"http://127.0.0.1:{server.server_address[1]}")
        self.assertEqual(client.embed(["x"]), [[0.5, 0.5]])

    def test_unreachable_server_raises_a_clear_error(self):
        def opener(request, timeout=None):
            raise urllib.error.URLError("refused")
        with self.assertRaisesRegex(embed.EmbeddingError, "not reachable"):
            embed.OllamaEmbedder(opener=opener).embed(["a"])

    def test_bad_replies_raise(self):
        for payload in ({"embeddings": [[1.0]]}, {"embeddings": [[1.0], [1.0, 2.0]]}, {"embeddings": [[], []]},
                        {"embeddings": [[float("nan")], [1.0]]}, {"oops": 1}):
            with self.assertRaises(embed.EmbeddingError, msg=str(payload)):
                embed.OllamaEmbedder(opener=opener_returning(payload)).embed(["a", "b"])

    def test_invalid_json_raises(self):
        def opener(request, timeout=None):
            return FakeResponse(b"not json")
        with self.assertRaises(embed.EmbeddingError):
            embed.OllamaEmbedder(opener=opener).embed(["a"])


class HashEmbedderTest(unittest.TestCase):
    def test_deterministic_and_unit_length(self):
        e = embed.HashEmbedder()
        v = e.vector("keep small commits")
        self.assertEqual(v, e.vector("keep small commits"))
        self.assertAlmostEqual(sum(x * x for x in v), 1.0)

    def test_shared_words_are_closer_than_unrelated_words(self):
        e = embed.HashEmbedder()
        near = embed.cosine(e.vector("small commits help review"), e.vector("review small commits"))
        far = embed.cosine(e.vector("small commits help review"), e.vector("volcano eruption"))
        self.assertGreater(near, far)

    def test_empty_text_is_a_zero_vector(self):
        self.assertEqual(set(embed.HashEmbedder().vector("the and")), {0.0})


class RankingTest(unittest.TestCase):
    def test_cosine(self):
        self.assertAlmostEqual(embed.cosine([1, 0], [1, 0]), 1.0)
        self.assertAlmostEqual(embed.cosine([1, 0], [0, 1]), 0.0)
        self.assertEqual(embed.cosine([0, 0], [1, 0]), 0.0)

    def test_dense_rank_orders_by_similarity_then_name(self):
        names, vectors = ["b", "a", "c"], [[0, 1], [0, 1], [1, 0]]
        self.assertEqual(embed.dense_rank([1, 0], names, vectors), ["c", "a", "b"])

    def test_rrf_by_hand(self):
        # a: 1/61 + 1/62, c: 1/63 + 1/61, b: 1/62 + 1/63
        self.assertEqual(embed.rrf([["a", "b", "c"], ["c", "a", "b"]]), ["a", "c", "b"])

    def test_rrf_keeps_a_name_that_only_one_list_has(self):
        self.assertEqual(embed.rrf([["a"], ["b", "a"]])[0], "a")
        self.assertEqual(set(embed.rrf([["a"], ["b"]])), {"a", "b"})


class MetricsTest(unittest.TestCase):
    def test_hand_computed(self):
        queries = [{"relevant": ["a"]}, {"relevant": ["a"]}, {"relevant": ["a"]}]
        rankings = [["a", "b", "c"], ["c", "b", "x", "a"], []]
        m = dense_eval.metrics(rankings, queries, k=3)
        self.assertEqual((m["precision_at_k"], m["hit_at_k"], m["mrr"]), (round(1 / 9, 4), round(1 / 3, 4), round(1.25 / 3, 4)))

    def test_all_three_systems_run_without_a_model(self):
        memories, queries = dense_eval.load()
        result = dense_eval.compare(memories, queries, embed.HashEmbedder())
        self.assertEqual(set(result), {"bm25", "dense", "hybrid (RRF, k=60)"})
        self.assertEqual(result["bm25"]["hit_at_k"], 0.7941)


@unittest.skipUnless(__import__("os").environ.get("RUN_LIVE_OLLAMA"), "set RUN_LIVE_OLLAMA=1 to test a running Ollama")
class LiveOllamaTest(unittest.TestCase):
    def test_real_embeddings(self):
        client = embed.OllamaEmbedder()
        vectors = client.embed(["a dog", "a puppy", "a tax form"])
        self.assertEqual(len({len(v) for v in vectors}), 1)
        self.assertGreater(embed.cosine(vectors[0], vectors[1]), embed.cosine(vectors[0], vectors[2]))


if __name__ == "__main__":
    unittest.main()
