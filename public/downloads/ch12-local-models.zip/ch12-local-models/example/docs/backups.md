# Backups

Keep three copies on two kinds of media with one copy away from home. Test a restore every quarter.
