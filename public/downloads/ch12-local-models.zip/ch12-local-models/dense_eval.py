"""Compare BM25, dense retrieval and their rank fusion on the labelled evaluation set (same metrics as chapter 06).

Usage: python3 -I dense_eval.py                      (hash embedder: no model needed, NOT semantic)
       python3 -I dense_eval.py --ollama [--model nomic-embed-text] [--nomic-prefixes]
"""
import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import embed  # noqa: E402
import memory  # noqa: E402
from bm25 import BM25Index  # noqa: E402

K = 3


def load(folder=HERE / "evalset"):
    memories = memory.load_memories(Path(folder) / "memories")
    queries = json.loads((Path(folder) / "queries.json").read_text(encoding="utf-8"))["queries"]
    return memories, queries


def metrics(rankings, queries, k=K):
    """rankings: one list of names (best first) for each query."""
    precisions, hits, reciprocal = [], 0, []
    for ranked, query in zip(rankings, queries):
        relevant = set(query["relevant"])
        precisions.append(sum(n in relevant for n in ranked[:k]) / k)
        hits += any(n in relevant for n in ranked[:k])
        first = next((r for r, n in enumerate(ranked, start=1) if n in relevant), None)
        reciprocal.append(1 / first if first else 0.0)
    count = len(queries)
    return {"precision_at_k": round(sum(precisions) / count, 4), "hit_at_k": round(hits / count, 4),
            "mrr": round(sum(reciprocal) / count, 4)}


def compare(memories, queries, embedder):
    names = [m.name for m in memories]
    index = BM25Index([m.search_text for m in memories])
    vectors = embedder.embed_documents([m.context_text for m in memories])
    bm25_rankings, dense_rankings = [], []
    for query in queries:
        positive = [names[i] for i, _ in index.rank(query["query"])]
        bm25_rankings.append(positive)
        dense_rankings.append(embed.dense_rank(embedder.embed_query(query["query"]), names, vectors))
    fused = [embed.rrf([b, d]) for b, d in zip(bm25_rankings, dense_rankings)]
    return {"bm25": metrics(bm25_rankings, queries), "dense": metrics(dense_rankings, queries),
            "hybrid (RRF, k=60)": metrics(fused, queries)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--ollama", action="store_true")
    parser.add_argument("--model", default=embed.DEFAULT_MODEL)
    parser.add_argument("--nomic-prefixes", action="store_true")
    args = parser.parse_args(argv)
    memories, queries = load()
    if args.ollama:
        prefixes = {"document_prefix": "search_document: ", "query_prefix": "search_query: "} if args.nomic_prefixes else {}
        embedder = embed.OllamaEmbedder(args.model, **prefixes)
    else:
        embedder = embed.HashEmbedder()
    started = time.perf_counter()
    results = compare(memories, queries, embedder)
    seconds = time.perf_counter() - started
    print("| system | precision@3 | hit@3 | MRR |\n| --- | --- | --- | --- |")
    for name, m in results.items():
        print(f"| {name} | {m['precision_at_k']:.3f} | {m['hit_at_k']:.3f} | {m['mrr']:.3f} |")
    print(f"({len(memories)} memories, {len(queries)} queries; {seconds:.1f} s in total, one session)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
