2026-10-01T09:00:00Z | 0f79a4480382 | Keep the file format as plain text; a database was accepted as too heavy.
2026-10-02T09:00:00Z | ce6075260956 | Name the failure first: a half-written line is the likely fault.
