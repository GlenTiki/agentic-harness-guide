import shutil
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import personas as p

HERE = Path(__file__).resolve().parent.parent


def at(second):
    return datetime(2026, 1, 1, 0, 0, second, tzinfo=timezone.utc)


class ChainTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "m.md"

    def test_append_builds_a_valid_chain(self):
        p.append_memory(self.path, "first", now=at(1))
        p.append_memory(self.path, "second", now=at(2))
        self.assertEqual(p.verify_memory(self.path), [])
        self.assertEqual([n for _, _, n in p.read_memory_lines(self.path)], ["first", "second"])

    def test_editing_an_earlier_line_is_detected(self):
        p.append_memory(self.path, "first", now=at(1))
        p.append_memory(self.path, "second", now=at(2))
        self.path.write_text(self.path.read_text(encoding="utf-8").replace("first", "changed"), encoding="utf-8")
        self.assertTrue(p.verify_memory(self.path))

    def test_deleting_an_earlier_line_is_detected(self):
        for i, note in enumerate(("a", "b", "c"), start=1):
            p.append_memory(self.path, note, now=at(i))
        lines = self.path.read_text(encoding="utf-8").splitlines()
        self.path.write_text("\n".join(lines[1:]) + "\n", encoding="utf-8")
        self.assertTrue(p.verify_memory(self.path))

    def test_swapping_two_lines_is_detected(self):
        for i, note in enumerate(("a", "b", "c"), start=1):
            p.append_memory(self.path, note, now=at(i))
        lines = self.path.read_text(encoding="utf-8").splitlines()
        self.path.write_text("\n".join([lines[0], lines[2], lines[1]]) + "\n", encoding="utf-8")
        self.assertTrue(p.verify_memory(self.path))

    def test_time_going_backwards_is_detected(self):
        p.append_memory(self.path, "a", now=at(5))
        p.append_memory(self.path, "b", now=at(1))
        self.assertTrue(any("backwards" in x for x in p.verify_memory(self.path)))

    def test_refuses_to_append_to_a_broken_memory(self):
        p.append_memory(self.path, "a", now=at(1))
        self.path.write_text(self.path.read_text(encoding="utf-8").replace("a", "z"), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Refusing"):
            p.append_memory(self.path, "b", now=at(2))

    def test_bad_notes_are_refused(self):
        for note in ("", "two\nlines", "has | pipe"):
            with self.assertRaises(ValueError, msg=note):
                p.append_memory(self.path, note)

    def test_time_is_utc_seconds_z(self):
        p.append_memory(self.path, "a")
        self.assertRegex(self.path.read_text(encoding="utf-8"), r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ \| ")


class FolderTest(unittest.TestCase):
    def test_example_is_clean(self):
        self.assertEqual(p.check_folder(HERE / "example" / "personas"), [])

    def test_bad_copy_reports_each_defect(self):
        problems = p.check_folder(HERE / "fixtures" / "bad" / "personas")
        self.assertEqual(len(problems), 6, problems)
        text = "\n".join(problems)
        for fragment in ("chain hash", "Checklist", "does not exist", "duplicate", "phase", "no persona uses"):
            self.assertIn(fragment, text)

    def test_memory_path_cannot_escape_the_memory_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copytree(HERE / "example" / "personas", Path(tmp) / "x")
            persona = Path(tmp) / "x" / "builder.md"
            persona.write_text(persona.read_text(encoding="utf-8").replace("memory/builder.md", "../builder.md"), encoding="utf-8")
            self.assertTrue(any("memory folder" in x for x in p.check_folder(Path(tmp) / "x")))


class ContextTest(unittest.TestCase):
    def test_context_holds_checklist_and_recent_memory(self):
        text = p.persona_context(HERE / "example" / "personas", "builder", last=1)
        self.assertIn("## Checklist", text)
        self.assertIn("Two small commits", text)
        self.assertNotIn("A search that ignored case", text)

    def test_unknown_persona(self):
        with self.assertRaises(KeyError):
            p.persona_context(HERE / "example" / "personas", "nobody")

    def test_recording_an_interaction_changes_the_next_context(self):
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copytree(HERE / "example" / "personas", Path(tmp) / "x")
            p.append_memory(Path(tmp) / "x" / "memory" / "tester.md", "A unicode note broke the parser.", now=at(9))
            self.assertIn("unicode note", p.persona_context(Path(tmp) / "x", "tester"))


if __name__ == "__main__":
    unittest.main()
