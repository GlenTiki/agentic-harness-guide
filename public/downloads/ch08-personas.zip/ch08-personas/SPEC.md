# Chapter 08: Personas

## Status

This chapter is a design with a small working scaffold. The scaffold stores persona files and their memory, and it checks both. It does not run a persona. It does not show that personas improve the work.

## Purpose

One viewpoint misses defects. A team of roles looks at the same work from different sides. The team lead gives each role a checklist and a memory of its own.

## The persona file

A persona file is a markdown file with a front matter block. The block has four keys.

1. `name` is a unique name.
2. `role` is one sentence.
3. `phase` is one of design, build, test, review or release.
4. `memory` is the path of the memory file. The file must sit in the `memory` folder.

The body has a Checklist section with at least three items. It has a Voice section.

## The memory file

Each persona has one memory file. Each line holds a UTC time, a chain hash and a note. The pipe character separates them.

1. A new interaction adds one line at the end.
2. The chain hash covers the previous hash, the time and the note. The first line uses the word `genesis` as the previous hash.
3. The checker recomputes the chain. A change to an earlier line breaks the chain from that line on.
4. The time on each line must not go backwards.
5. The tool refuses to add a line to a memory that already fails its check.

## What the chain proves and what it does not

The chain detects an edit, a deletion or a swap of lines. It does not stop a person who rewrites the whole file and recomputes every hash. Git history covers that case. A hook from chapter 02 can also block direct edits to the memory folder.

## The folder check

The checker fails when it finds one of these problems.

1. A persona file lacks a key, or has an unknown phase.
2. The Checklist has fewer than three items.
3. Two personas share a name.
4. A memory file is missing or fails its chain check.
5. A memory file sits outside the memory folder.
6. A memory file belongs to no persona.

## How memory reaches the persona

The function `persona_context` returns the persona body and its last five memory notes. The team lead puts that text in the subagent brief from chapter 07.

## Proof that the check can fail

The folder `fixtures/bad/personas` holds six defects. The checker must report all six.
