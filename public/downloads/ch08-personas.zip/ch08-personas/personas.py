"""Persona files with their own append-only memory. A design with a small working scaffold.

What this code does: it stores persona definitions, appends interaction notes to a persona's memory file,
and checks both. Each memory line carries a chain hash, so an edit or a deletion of an earlier line is detected.
What this code does not do: it does not run a persona, and it does not show that personas improve the work.

Memory line:   <UTC time> | <chain hash> | <note>
Chain hash:    first 12 hex digits of SHA-256 over  previous chain hash + "|" + time + "|" + note
               (the first line uses the word "genesis" as the previous hash)
"""
import argparse
import hashlib
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

REQUIRED_KEYS = ("name", "role", "phase", "memory")
PHASES = ("design", "build", "test", "review", "release")
UTC_SECONDS = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
MIN_CHECKLIST_ITEMS = 3
GENESIS = "genesis"


def chain_hash(previous, time, note):
    return hashlib.sha256(f"{previous}|{time}|{note}".encode("utf-8")).hexdigest()[:12]


def parse_front_matter(text):
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---" or "---" not in lines[1:]:
        raise ValueError("The file needs a front matter block between two --- lines.")
    end = lines.index("---", 1)
    fields = {}
    for line in lines[1:end]:
        key, separator, value = line.partition(":")
        if not separator:
            raise ValueError(f"Expected 'key: value', got '{line}'.")
        fields[key.strip()] = value.strip()
    return fields, "\n".join(lines[end + 1:])


def checklist_items(body):
    in_checklist, items = False, []
    for line in body.splitlines():
        if line.startswith("## "):
            in_checklist = line[3:].strip().lower() == "checklist"
        elif in_checklist and re.match(r"^\s*(?:[-*]|\d+\.)\s+\S", line):
            items.append(line.strip())
    return items


def read_memory_lines(path):
    entries = []
    for number, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), start=1):
        parts = line.split(" | ", 2)
        if len(parts) != 3:
            raise ValueError(f"{path}:{number}: expected 'time | chain | note'.")
        entries.append(tuple(parts))
    return entries


def verify_memory(path):
    problems, previous, last_time = [], GENESIS, ""
    try:
        entries = read_memory_lines(path)
    except ValueError as error:
        return [str(error)]
    for number, (time, chain, note) in enumerate(entries, start=1):
        if not UTC_SECONDS.match(time):
            problems.append(f"{path}:{number}: time must be UTC with seconds and a Z.")
        elif time < last_time:
            problems.append(f"{path}:{number}: time goes backwards.")
        else:
            last_time = time
        expected = chain_hash(previous, time, note)
        if chain != expected:
            problems.append(f"{path}:{number}: the chain hash does not match. An earlier line changed, or this one did.")
            break
        previous = chain
    return problems


def append_memory(path, note, now=None):
    """Append one note. Refuse if the note is not one plain line or the existing memory is already broken."""
    if not note.strip() or "\n" in note or " | " in note:
        raise ValueError("A note must be one non-empty line without ' | '.")
    path = Path(path)
    existing = verify_memory(path) if path.exists() else []
    if existing:
        raise ValueError("Refusing to append to a memory that fails its check: " + existing[0])
    entries = read_memory_lines(path) if path.exists() else []
    previous = entries[-1][1] if entries else GENESIS
    time = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    line = f"{time} | {chain_hash(previous, time, note.strip())} | {note.strip()}\n"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(line)


def check_folder(folder):
    folder = Path(folder)
    problems, names, referenced = [], [], set()
    for persona in sorted(folder.glob("*.md")):
        try:
            fields, body = parse_front_matter(persona.read_text(encoding="utf-8"))
        except ValueError as error:
            problems.append(f"{persona.name}: {error}")
            continue
        missing = [k for k in REQUIRED_KEYS if not fields.get(k)]
        if missing:
            problems.append(f"{persona.name}: missing key(s): {', '.join(missing)}.")
            continue
        if fields["phase"] not in PHASES:
            problems.append(f"{persona.name}: phase must be one of {', '.join(PHASES)}.")
        if len(checklist_items(body)) < MIN_CHECKLIST_ITEMS:
            problems.append(f"{persona.name}: the Checklist section needs at least {MIN_CHECKLIST_ITEMS} items.")
        if fields["name"] in names:
            problems.append(f"{persona.name}: duplicate persona name '{fields['name']}'.")
        names.append(fields["name"])
        memory_path = folder / fields["memory"]
        if memory_path.resolve().parent != (folder / "memory").resolve():
            problems.append(f"{persona.name}: the memory file must sit in the memory folder.")
            continue
        referenced.add(memory_path.resolve())
        if not memory_path.exists():
            problems.append(f"{persona.name}: memory file {fields['memory']} does not exist.")
            continue
        problems += [p.replace(str(folder) + "/", "") for p in verify_memory(memory_path)]
    for memory_path in sorted((folder / "memory").glob("*.md")):
        if memory_path.resolve() not in referenced:
            problems.append(f"memory/{memory_path.name}: no persona uses this memory file.")
    return problems


def persona_context(folder, name, last=5):
    """Return the persona definition plus its most recent memory lines, ready to put in a brief."""
    folder = Path(folder)
    for persona in sorted(folder.glob("*.md")):
        fields, body = parse_front_matter(persona.read_text(encoding="utf-8"))
        if fields.get("name") == name:
            notes = [note for _, _, note in read_memory_lines(folder / fields["memory"])][-last:]
            remembered = "\n".join(f"- {n}" for n in notes) or "- (nothing yet)"
            return f"{body.strip()}\n\n## What you remember\n\n{remembered}\n"
    raise KeyError(f"No persona named {name}.")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("check", "context", "record"):
        command = sub.add_parser(name)
        command.add_argument("--dir", default="example/personas")
        if name != "check":
            command.add_argument("persona")
        if name == "record":
            command.add_argument("note")
    args = parser.parse_args(argv)
    if not Path(args.dir).exists():
        raise FileNotFoundError(2, "No such file or directory", str(args.dir))
    if args.command == "check":
        problems = check_folder(args.dir)
        print("\n".join(problems) or "personas: OK")
        return 1 if problems else 0
    if args.command == "context":
        print(persona_context(args.dir, args.persona))
        return 0
    fields, _ = parse_front_matter((Path(args.dir) / f"{args.persona}.md").read_text(encoding="utf-8"))
    append_memory(Path(args.dir) / fields["memory"], args.note)
    return 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"personas: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
