2026-10-01T09:00:00Z | 971ef2274ea8 | A search that ignored case needed a test for mixed-case input.
2026-10-02T09:00:00Z | 4e70cdcdf7be | Two small commits were easier to review than one large one.
