2026-10-01T09:00:00Z | 87569e78a3ce | The spec said 'few'. A number would have saved a round of questions.
