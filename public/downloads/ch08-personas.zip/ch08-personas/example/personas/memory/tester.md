2026-10-01T09:00:00Z | 1441d0b831de | An empty search word crashed the first version.
2026-10-02T09:00:00Z | 4717ad5e4271 | A note with a tab character was accepted by mistake once.
