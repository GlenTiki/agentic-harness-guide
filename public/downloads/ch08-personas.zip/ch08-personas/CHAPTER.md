# Chapter 08: Personas

Status: design with a small working scaffold.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

Weak spot removed: one viewpoint. A single agent that builds, tests and reviews its own work tends to agree with itself. Separate roles with separate checklists disagree usefully. A role that keeps its own notes also stops repeating its own earlier mistakes.

## Steps

1. Read the five files in `example/personas/`. Each has a role, a phase and a checklist.
2. Read one memory file in `example/personas/memory/`. Each line is a time, a hash and a note.
3. Check the folder.
4. Print what the tester would load.
5. Copy the personas into `scratch/` so that your edits do not change the example. Record a new interaction in the copy. Run the check again. It still passes, because the tool extended the chain.
6. Edit an old note in the copy by hand and run the check. It fails with exit code 1.

```sh
python3 -I personas.py check  # exit 0; expect: personas: OK
python3 -I personas.py context tester  # exit 0; expect: You are the tester
mkdir -p scratch
python3 -I -c "import shutil; shutil.copytree('example/personas', 'scratch/personas', dirs_exist_ok=True)"
python3 -I personas.py record tester "A very long note broke the list output." --dir scratch/personas
python3 -I personas.py check --dir scratch/personas  # exit 0; expect: personas: OK
python3 -I -c "from pathlib import Path; p = Path('scratch/personas/memory/tester.md'); p.write_text(p.read_text().replace('empty search word', 'EMPTY SEARCH WORD'))"
python3 -I personas.py check --dir scratch/personas  # exit 1; expect: the chain hash does not match
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## Expected output

Step 3 prints `personas: OK`. The validator prints `validate: PASS`.

## One readable error

```sh
python3 -I personas.py check --dir no-such-folder  # exit 2; expect: personas: No such file or directory
```

## What is verified and what is only a design

Verified by tests: the file format, the chain check, the refusal to append to a broken memory, the context function, and the six folder defects. Not verified: that personas catch more defects, that their memory improves later work, or how a team lead should choose which persona runs when. Those are design ideas. Treat this chapter as a place to start, and measure on your own work before you trust it.

## Honest limits

The chain detects partial edits. It does not stop a full rewrite of a file. The `record` command appends to the folder you name. The steps above use a copy in `scratch/`, so the example stays as it was shipped.

## Prove the check can fail

Run the validator with `--bad`. It reports six problems: a tampered memory line, a short checklist, an unknown phase, a duplicate name, a missing memory file and an orphan memory file. It prints `validate: FAIL (6 problem(s))` and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (6 problem(s))
```
