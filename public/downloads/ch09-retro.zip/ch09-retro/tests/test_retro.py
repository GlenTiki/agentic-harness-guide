import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import retro

HERE = Path(__file__).resolve().parent.parent
NOW = datetime(2026, 1, 2, 3, 4, 5, tzinfo=timezone.utc)
ROUGH = (HERE / "example" / "rough-notes.txt").read_text(encoding="utf-8")
RAMBLE = (HERE / "fixtures" / "bad" / "ramble.txt").read_text(encoding="utf-8")


class ParseTest(unittest.TestCase):
    def test_structured_output_has_praise_first_and_three_fields(self):
        text, _, _ = retro.parse_notes(ROUGH, "T", NOW)
        self.assertLess(text.index("## What went well"), text.index("## What went wrong"))
        self.assertIn("- What it was: a missing test", text)
        self.assertIn("- What I preferred: a test written first", text)
        self.assertIn("Recorded: 2026-01-02T03:04:05Z", text)

    def test_missing_field_becomes_a_question_not_an_invention(self):
        text, _, questions = retro.parse_notes(ROUGH, "T", NOW)
        self.assertEqual(questions, ["Issue 2: What happened? Say the events in order."])
        self.assertIn(f"- What happened: {retro.OPEN}", text)

    def test_nothing_is_invented(self):
        text, proposals, _ = retro.parse_notes(ROUGH, "T", NOW)
        lowered = ROUGH.lower()
        for line in text.split("## Raw words")[0].splitlines() + proposals.splitlines():
            if line.startswith("- ") and retro.OPEN not in line and ": " in line and not line.startswith(("- From", "- Status")):
                value = line.split(": ", 1)[1] if line.split(": ", 1)[0].startswith("- What") or line.startswith("- Change") else line[2:]
                self.assertIn(value.lower(), lowered, line)

    def test_rambling_input_gives_questions_and_keeps_every_word(self):
        text, proposals, questions = retro.parse_notes(RAMBLE, "T", NOW)
        self.assertEqual(len(questions), 2)
        self.assertIn("What went well?", questions[0])
        for line in RAMBLE.splitlines():
            self.assertIn(line, text)
        self.assertIn("No proposals", proposals)

    def test_rambling_input_is_a_valid_draft_and_fails_strict(self):
        text, _, _ = retro.parse_notes(RAMBLE, "T", NOW)
        self.assertEqual(retro.check_retro(text, strict=False), [])
        self.assertTrue(any("Open questions" in p for p in retro.check_retro(text)))

    def test_empty_notes(self):
        text, proposals, questions = retro.parse_notes("", "T", NOW)
        self.assertEqual(len(questions), 1)
        self.assertEqual(retro.check_retro(text, strict=False), [])

    def test_cues_ignore_case_and_windows_line_endings(self):
        notes = "GOOD: fast review\r\nBAD: flaky test\r\nWhat Happened: it failed twice\r\n"
        text, _, _ = retro.parse_notes(notes, "T", NOW)
        self.assertIn("- fast review", text)
        self.assertIn("- What happened: it failed twice", text)

    def test_field_before_any_problem_is_unsorted(self):
        _, _, questions = retro.parse_notes("what happened: x\n+ fine\n", "T", NOW)
        self.assertEqual(questions, ["Where do these lines belong? They matched no cue."])

    def test_second_value_for_a_field_is_not_dropped_silently(self):
        notes = "+ ok\n- bad thing\nwhat happened: first\nwhat happened: second\n"
        text, _, questions = retro.parse_notes(notes, "T", NOW)
        self.assertIn("- What happened: first", text)
        self.assertIn("second", text)  # kept in the raw words block
        self.assertTrue(any("Where do these lines belong" in q for q in questions))

    def test_proposals_always_start_as_proposed(self):
        _, proposals, _ = retro.parse_notes(ROUGH, "T", NOW)
        self.assertEqual(proposals.count("- Status: proposed"), 2)

    def test_answering_the_questions_makes_the_retro_pass_strict(self):
        text, _, _ = retro.parse_notes(ROUGH, "T", NOW)
        self.assertTrue(retro.check_retro(text))
        answered = text.replace(f"{retro.OPEN}: What happened? Say the events in order.", "a reviewer asked what few meant")
        self.assertEqual(retro.check_retro(answered), [])


class CheckTest(unittest.TestCase):
    def read(self, rel):
        return (HERE / rel).read_text(encoding="utf-8")

    def test_example_passes_strict(self):
        text = self.read("example/retro.md")
        self.assertEqual(retro.check_retro(text), [])
        self.assertEqual(retro.check_proposals(self.read("example/proposals.md"), text), [])

    def test_praise_must_come_first(self):
        text = "# R\n\n## What went wrong\n\n## What went well\n\n- ok\n"
        self.assertTrue(any("praise first" in p for p in retro.check_retro(text)))

    def test_bad_fixture_reports_every_defect(self):
        text = self.read("fixtures/bad/retro.md")
        self.assertEqual(len(retro.check_retro(text)), 3)
        self.assertEqual(len(retro.check_proposals(self.read("fixtures/bad/proposals.md"), text)), 3)

    def test_cli_parse_and_check_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(retro.main(["parse", str(HERE / "example" / "rough-notes.txt"), "--out", tmp]), 0)
            self.assertEqual(retro.main(["check", str(Path(tmp) / "retro.md"), "--draft"]), 0)
            self.assertEqual(retro.main(["check", str(Path(tmp) / "retro.md")]), 1)


if __name__ == "__main__":
    unittest.main()
