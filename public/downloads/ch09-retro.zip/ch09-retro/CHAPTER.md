# Chapter 09: Retro

Weak spot removed: the same mistake twice. A mistake that is only remembered tends to come back. A mistake that becomes a check does not.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## The cues the parser reads

| Cue at the start of a line | Meaning |
| --- | --- |
| `+ `, `good:`, `went well:`, `liked:`, `win:` | something that went well |
| `- `, `bad:`, `problem:`, `issue:`, `went wrong:` | a new problem |
| `what it was:`, `it was:`, `was:` | field "What it was" of the nearest problem above |
| `what happened:`, `happened:` | field "What happened" |
| `what i preferred:`, `preferred:`, `i would have preferred`, `i preferred`, `i wanted`, `next time:` | field "What I preferred" |

Case does not matter. Any other line stays in the Raw words block and becomes a question.

## Steps

1. Read `example/rough-notes.txt`. It is how a person writes after a long day.
2. Turn it into a draft. The command writes `scratch/retro.md` and `scratch/proposals.md` and prints one open question.
3. Check it as a draft. It passes.
4. Check it strictly. It fails, because the question about issue 2 is open.
5. Answer the question in the file, then run the strict check again. It passes. The first command below answers the question for you. In your own retro you write the answer by hand.
6. Read `example/retro.md` and `example/proposals.md`. They are the finished version.
7. Run the validator.

```sh
mkdir -p scratch
python3 -I retro.py parse example/rough-notes.txt --title "Search feature" --out scratch  # exit 0; expect: 1 open question(s):
python3 -I retro.py check scratch/retro.md --draft  # exit 0; expect: retro: OK
python3 -I retro.py check scratch/retro.md  # exit 1; expect: Open questions remain
python3 -I -c "from pathlib import Path; p = Path('scratch/retro.md'); p.write_text(p.read_text().replace('NEEDS CLARIFICATION: What happened? Say the events in order.', 'The word few passed review because no check looked for it.'))"
python3 -I retro.py check scratch/retro.md  # exit 0; expect: retro: OK
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## Expected output

Step 2 prints `1 open question(s):`. The validator prints `validate: PASS`.

## One readable error

```sh
python3 -I retro.py parse no-such-notes.txt  # exit 2; expect: retro: No such file or directory
```

## Rambling input

The file `fixtures/bad/ramble.txt` holds three lines with no cue. The parser produces a draft with two questions: what went well, and where the three lines belong. It keeps every original word in the Raw words block and writes no proposals. The tests assert this.

## Honest limits

This parser is rule based. It does not understand meaning, so it cannot turn a real ramble into a good retro by itself. Its job is to be safe: it keeps the words, asks questions and invents nothing. In practice an agent that can reason would do the first pass, then use these checks as the gate. The praise-first rule is a format rule that the checker enforces. It does not judge if the praise is sincere.

## Prove the check can fail

Run the validator with `--bad`. It reports six problems and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (6 problem(s))
```
