# Retro: Search feature

Recorded: 2026-10-24T09:00:00Z

## What went well

- the hooks blocked a force push before it happened
- small commits made the review quick

## What went wrong

### Issue 1: the search feature shipped without a test for empty input

- What it was: a missing test
- What happened: a user typed nothing and the tool crashed
- What I preferred: a test written first

### Issue 2: the spec used the word few

- What it was: a vague word in a spec
- What happened: a reviewer found the word few in the spec and asked what number it meant
- What I preferred: the linter should reject vague words

## Raw words

```text
+ the hooks blocked a force push before it happened
+ small commits made the review quick
- the search feature shipped without a test for empty input
  what it was: a missing test
  what happened: a user typed nothing and the tool crashed
  i would have preferred a test written first
- the spec used the word few
  it was: a vague word in a spec
  next time: the linter should reject vague words
```
