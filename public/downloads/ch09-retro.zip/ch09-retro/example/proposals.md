# Proposals from: Search feature

## Proposal 1

- From: Issue 1
- Change: a test written first
- Status: accepted
- Check that would prove it works: a test named test_empty_word_is_refused that fails on the old code

## Proposal 2

- From: Issue 2
- Change: the linter should reject vague words
- Status: accepted
- Check that would prove it works: the plain-English linter rejects the word few
