# Proposals from: Bad example

## Proposal 1

- From: Issue 7
- Change: do better
- Status: maybe
- Check that would prove it works: NEEDS CLARIFICATION: Name the test, hook or lint rule that would catch this next time.

## Proposal 2

- From: Issue 1
- Change: add a check
- Status: accepted
- Check that would prove it works: NEEDS CLARIFICATION: Name the test, hook or lint rule that would catch this next time.
