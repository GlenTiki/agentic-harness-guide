# Retro: Bad example

Recorded: 2026-10-24T09:00:00Z

## What went wrong

### Issue 1: the build broke

- What it was: a missing import
- What happened:
- What I preferred: NEEDS CLARIFICATION: What would you have preferred instead?

## What went well

- nothing yet
