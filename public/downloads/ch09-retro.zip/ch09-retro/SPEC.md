# Chapter 09: Retro

## Purpose

This chapter stops the same mistake from happening twice. After a piece of work, the team writes a short retrospective. The retro starts with praise. It then describes each problem in three parts. The agent turns the human's rough words into that form and proposes fixes.

## The retro format

1. The first section is "What went well". It has at least one item.
2. The second section is "What went wrong". It holds one block for each problem.
3. Each problem block has three lines: "What it was", "What happened" and "What I preferred".
4. The last section, "Raw words", holds the original notes without change.

## The proposals file

Each problem with a preferred outcome gets one proposal. A proposal has four lines.

1. `From` names the issue number.
2. `Change` copies the preferred outcome.
3. `Status` holds one value: proposed, accepted or rejected. A new proposal always starts as proposed.
4. `Check that would prove it works` names a test, a hook or a lint rule.

A proposal cannot move to accepted without a real check. This ties the retro to chapter 01 and chapter 02: a lesson becomes a check.

## The rough-notes parser

The human may ramble. The parser reads cues at the start of a line, such as "+", "-", "what happened:" or "next time:". The chapter page lists them all.

1. The parser never invents content.
2. The parser puts a line it cannot place into the Raw words block.
3. The parser writes a question for each missing part. The question starts with NEEDS CLARIFICATION.
4. If the notes hold no praise, the parser writes a question. It does not make up praise.

## Draft and strict checks

A retro with open questions is a draft. The draft check allows open questions. The strict check does not. The agent asks the human each open question, writes the answers into the retro and runs the strict check.

## What the parser cannot do

The parser is a set of rules. It does not understand meaning. Rambling text with no cue produces only questions. A language model could help to turn rambling into a draft. This chapter does not include one.

## Proof that the check can fail

The folder `fixtures/bad` holds a retro with the problems before the praise, an empty field and an open question. It also holds a proposals file with an unknown issue, a wrong status and an accepted proposal without a check. The validator must report six problems.
