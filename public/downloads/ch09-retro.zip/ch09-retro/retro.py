"""Retrospectives: praise first, then each problem as what it was / what happened / what I preferred.

parse_notes turns rough notes into the structured form and a proposals file. It is a rule-based parser, not a
language model. It never invents content. Anything it cannot place becomes a question marked NEEDS CLARIFICATION,
and the original words stay in a Raw words block. A retro with open questions is a draft. Only a retro with no
open question passes the strict check.

Cues the parser reads (case does not matter):
  praise      a line starting "+ " or "good:", "went well:", "liked:", "win:"
  problem     a line starting "- " or "bad:", "problem:", "issue:", "went wrong:"
  what it was     "what it was:", "it was:", "was:"
  what happened   "what happened:", "happened:"
  what I preferred  "what i preferred:", "preferred:", "i would have preferred", "i preferred", "i wanted", "next time:"
A field cue belongs to the nearest problem above it.
"""
import argparse
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

OPEN = "NEEDS CLARIFICATION"
FIELDS = ("what", "happened", "preferred")
FIELD_LABELS = {"what": "What it was", "happened": "What happened", "preferred": "What I preferred"}
FIELD_CUES = {
    "what": ("what it was:", "it was:", "was:"),
    "happened": ("what happened:", "happened:"),
    "preferred": ("what i preferred:", "i would have preferred", "i preferred", "preferred:", "i wanted", "next time:"),
}
PRAISE_CUES = ("good:", "went well:", "liked:", "win:")
PROBLEM_CUES = ("bad:", "problem:", "issue:", "went wrong:")
QUESTIONS = {
    "what": "What was it? Name the thing that went wrong in one sentence.",
    "happened": "What happened? Say the events in order.",
    "preferred": "What would you have preferred instead?",
}


@dataclass
class Issue:
    title: str
    fields: dict = field(default_factory=dict)


def strip_cue(line, cues):
    lowered = line.lower()
    for cue in cues:
        if lowered.startswith(cue):
            return line[len(cue):].strip(" :-\t")
    return None


def classify(line):
    """Return (kind, text). Kinds: praise, problem, what, happened, preferred, other."""
    for kind, cues in FIELD_CUES.items():
        text = strip_cue(line, cues)
        if text is not None:
            return kind, text
    if line.startswith(("+ ", "- ")):
        rest = line[2:].strip()
        for kind, cues in FIELD_CUES.items():
            text = strip_cue(rest, cues)
            if text is not None:
                return kind, text
        return ("praise" if line[0] == "+" else "problem"), rest
    for kind, cues in (("praise", PRAISE_CUES), ("problem", PROBLEM_CUES)):
        text = strip_cue(line, cues)
        if text is not None:
            return kind, text
    return "other", line


def parse_notes(notes, title="Untitled retro", now=None):
    """Return (retro markdown, proposals markdown, list of open questions)."""
    praise, issues, unsorted = [], [], []
    for raw in notes.splitlines():
        line = raw.strip()
        if not line:
            continue
        kind, text = classify(line)
        if kind == "praise" and text:
            praise.append(text)
        elif kind == "problem" and text:
            issues.append(Issue(text))
        elif kind in FIELD_CUES and text and issues and kind not in issues[-1].fields:
            issues[-1].fields[kind] = text
        else:
            unsorted.append(line)
    stamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    questions = []
    lines = [f"# Retro: {title}", "", f"Recorded: {stamp}", "", "## What went well", ""]
    if not praise:
        questions.append("What went well? Name at least one thing before the problems.")
        praise = [f"{OPEN}: {questions[-1]}"]
    lines += [f"- {p}" for p in praise] + ["", "## What went wrong", ""]
    if not issues:
        lines += ["No problem was recognised in the notes.", ""]
    for number, issue in enumerate(issues, start=1):
        lines += [f"### Issue {number}: {issue.title}", ""]
        for key in FIELDS:
            value = issue.fields.get(key)
            if not value:
                value = f"{OPEN}: {QUESTIONS[key]}"
                questions.append(f"Issue {number}: {QUESTIONS[key]}")
            lines.append(f"- {FIELD_LABELS[key]}: {value}")
        lines.append("")
    if unsorted:
        questions.append("Where do these lines belong? They matched no cue.")
    lines += ["## Raw words", "", "```text", *notes.strip().splitlines(), "```", ""]
    return "\n".join(lines), render_proposals(title, issues), questions


def render_proposals(title, issues):
    lines = [f"# Proposals from: {title}", ""]
    for number, issue in enumerate(issues, start=1):
        change = issue.fields.get("preferred") or f"{OPEN}: {QUESTIONS['preferred']}"
        lines += [f"## Proposal {number}", "", f"- From: Issue {number}", f"- Change: {change}", "- Status: proposed",
                  f"- Check that would prove it works: {OPEN}: Name the test, hook or lint rule that would catch this next time.",
                  ""]
    if not issues:
        lines += ["No proposals. No problem was recognised.", ""]
    return "\n".join(lines)


def section_blocks(text):
    blocks, current = {}, None
    for line in text.splitlines():
        match = re.match(r"^## (.+?)\s*$", line)
        if match:
            current = match.group(1)
            blocks[current] = []
        elif current is not None:
            blocks[current].append(line)
    return blocks


def check_retro(text, strict=True):
    """Return a list of problems. With strict=False, open questions are allowed (a draft)."""
    problems = []
    headings = re.findall(r"^## (.+?)\s*$", text, re.MULTILINE)
    if not headings or headings[0] != "What went well":
        problems.append("The first section must be 'What went well' (praise first).")
    blocks = section_blocks(text)
    praise = [l for l in blocks.get("What went well", []) if l.startswith("- ") and l[2:].strip()]
    if not praise:
        problems.append("'What went well' needs at least one item.")
    if "What went wrong" not in blocks:
        problems.append("The section 'What went wrong' is missing.")
    wrong = "\n".join(blocks.get("What went wrong", []))
    for chunk in re.split(r"(?m)^### ", wrong)[1:]:
        title = chunk.splitlines()[0]
        for label in FIELD_LABELS.values():
            match = re.search(rf"(?m)^- {label}: (.*)$", chunk)
            if not match or not match.group(1).strip():
                problems.append(f"Issue '{title}': '{label}' is missing or empty.")
    if strict and OPEN in text.split("## Raw words")[0]:
        problems.append("Open questions remain (NEEDS CLARIFICATION). Answer them first.")
    return problems


def check_proposals(text, retro_text):
    problems = []
    issue_count = len(re.findall(r"(?m)^### Issue \d+:", retro_text))
    for chunk in re.split(r"(?m)^## ", text)[1:]:
        name = chunk.splitlines()[0]
        source = re.search(r"(?m)^- From: Issue (\d+)\s*$", chunk)
        status = re.search(r"(?m)^- Status: (\w+)\s*$", chunk)
        check = re.search(r"(?m)^- Check that would prove it works: (.*)$", chunk)
        if not source or not 1 <= int(source.group(1)) <= issue_count:
            problems.append(f"{name}: 'From' must name an issue in the retro.")
        if not status or status.group(1) not in ("proposed", "accepted", "rejected"):
            problems.append(f"{name}: 'Status' must be proposed, accepted or rejected.")
        elif status.group(1) == "accepted" and (not check or OPEN in check.group(1) or not check.group(1).strip()):
            problems.append(f"{name}: an accepted proposal needs a real check.")
    return problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    parse = sub.add_parser("parse")
    parse.add_argument("notes_file")
    parse.add_argument("--title", default="Untitled retro")
    parse.add_argument("--out", default=".", help="folder for retro.md and proposals.md")
    check = sub.add_parser("check")
    check.add_argument("retro_file")
    check.add_argument("--draft", action="store_true", help="allow open questions")
    args = parser.parse_args(argv)
    if args.command == "parse":
        retro, proposals, questions = parse_notes(Path(args.notes_file).read_text(encoding="utf-8"), args.title)
        (Path(args.out) / "retro.md").write_text(retro, encoding="utf-8")
        (Path(args.out) / "proposals.md").write_text(proposals, encoding="utf-8")
        print(f"{len(questions)} open question(s):")
        for question in questions:
            print(f"  - {question}")
        return 0
    problems = check_retro(Path(args.retro_file).read_text(encoding="utf-8"), strict=not args.draft)
    print("\n".join(problems) or "retro: OK")
    return 1 if problems else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"retro: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
