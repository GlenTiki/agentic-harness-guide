# Chapter 00: Baseline

## Purpose

This chapter gives you a small project and a check that can fail.

## The sample project

The sample project is a notes tool. It keeps one note on each line of a text file. Each line holds a time stamp, a tab and the note text.

## What the tool must do

1. The tool adds a note to the file.
2. The tool lists all notes in the order the user added them.
3. The tool searches notes for a word and ignores letter case.
4. The tool refuses an empty note.
5. The tool refuses a note that holds a new line or a tab.
6. The tool writes each time stamp in UTC, with seconds and a Z at the end.

## What the check must do

1. The check runs all unit tests.
2. The check exits with code 0 when every test passes.
3. The check exits with a non-zero code when one test fails.

## Proof that the check can fail

The folder `fixtures/bad` holds a copy of the tool with a known fault. The fault cuts the seconds from the time stamp. The check must go red on that copy.
