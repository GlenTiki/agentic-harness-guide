import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import notes

FIXED = datetime(2026, 1, 2, 3, 4, 5, tzinfo=timezone.utc)


class NotesTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.file = Path(self.dir.name) / "notes.txt"

    def tearDown(self):
        self.dir.cleanup()

    def test_stamp_is_utc_seconds_with_z(self):
        self.assertEqual(notes.utc_stamp(FIXED), "2026-01-02T03:04:05Z")

    def test_add_then_list(self):
        notes.add_note(self.file, "buy milk", now=FIXED)
        self.assertEqual(notes.list_notes(self.file), [("2026-01-02T03:04:05Z", "buy milk")])

    def test_empty_note_is_refused(self):
        with self.assertRaises(ValueError):
            notes.add_note(self.file, "   ")

    def test_tab_in_note_is_refused(self):
        with self.assertRaises(ValueError):
            notes.add_note(self.file, "a\tb")

    def test_missing_file_lists_nothing(self):
        self.assertEqual(notes.list_notes(self.file), [])

    def test_search_ignores_case(self):
        notes.add_note(self.file, "Buy Milk", now=FIXED)
        notes.add_note(self.file, "walk dog", now=FIXED)
        self.assertEqual([t for _, t in notes.search_notes(self.file, "milk")], ["Buy Milk"])


if __name__ == "__main__":
    unittest.main()
