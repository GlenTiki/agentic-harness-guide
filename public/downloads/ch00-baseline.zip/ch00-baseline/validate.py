"""Run the unit tests of a project directory. Exit 0 if they pass, 1 if not.

Usage: python3 -I validate.py            check the sample notes tool
       python3 -I validate.py --bad      check a copy that is broken on purpose
"""
import subprocess
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run_tests(project):
    result = subprocess.run(
        [sys.executable, "-I", "-m", "unittest", "discover", "-s", "tests", "-t", "."],
        cwd=project, capture_output=True, text=True,
    )
    sys.stdout.write(result.stdout)
    sys.stderr.write(result.stderr)
    return result.returncode


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    project = HERE / "fixtures" / "bad" if "--bad" in argv else HERE
    code = run_tests(project)
    print("validate: PASS" if code == 0 else "validate: FAIL")
    return 0 if code == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
