"""A plain-text notes tool. One note per line: a UTC time stamp, a tab, then the text."""
import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path


def utc_stamp(now=None):
    now = now or datetime.now(timezone.utc)
    return now.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def add_note(path, text, now=None):
    text = text.strip()
    if not text:
        raise ValueError("A note cannot be empty.")
    if "\n" in text or "\t" in text:
        raise ValueError("A note cannot contain a new line or a tab.")
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(f"{utc_stamp(now)}\t{text}\n")


def list_notes(path):
    path = Path(path)
    if not path.exists():
        return []
    notes = []
    for line in path.read_text(encoding="utf-8").splitlines():
        stamp, _, text = line.partition("\t")
        notes.append((stamp, text))
    return notes


def search_notes(path, word):
    needle = word.lower()
    return [note for note in list_notes(path) if needle in note[1].lower()]


def main(argv=None):
    parser = argparse.ArgumentParser(prog="notes")
    parser.add_argument("--file", default="notes.txt")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list")
    add = sub.add_parser("add")
    add.add_argument("text")
    find = sub.add_parser("search")
    find.add_argument("word")
    args = parser.parse_args(argv)
    if args.command == "add":
        add_note(args.file, args.text)
        return 0
    notes = list_notes(args.file) if args.command == "list" else search_notes(args.file, args.word)
    for stamp, text in notes:
        print(f"{stamp}  {text}")
    return 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"notes: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
