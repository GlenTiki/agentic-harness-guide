# Chapter 00: Baseline

Goal: have a small project and one command that tells you if it is healthy. Without that command, every later chapter has nothing to protect.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `notes.py`. It is a plain-text notes tool with no dependencies.
2. Run the tests.
3. Run the validator. It runs the same tests and prints one verdict.
4. Use the tool once, so that you have seen it work. The first command makes the `scratch` folder.

```sh
python3 -I -m unittest discover -s tests -t .  # exit 0; expect: OK
python3 -I validate.py  # exit 0; expect: validate: PASS
mkdir -p scratch
python3 -I notes.py --file scratch/notes.txt add "buy milk"
python3 -I notes.py --file scratch/notes.txt list  # exit 0; expect: buy milk
```

## Expected output

The validator prints the Python version it runs under, then `validate: PASS`, and exits with code 0. The `list` command prints the time stamp, two spaces and the note.

## One readable error

A path that cannot be used gives one line and exit code 2, not a traceback.

```sh
python3 -I notes.py --file scratch/no-such-folder/notes.txt add "x"  # exit 2; expect: notes: No such file or directory
```

## Prove the check can fail

Run the validator with `--bad`. It runs the same tests against `fixtures/bad`, a copy of the tool that drops the seconds from the time stamp. Two tests fail, `test_add_then_list` and `test_stamp_is_utc_seconds_with_z`. The validator prints `validate: FAIL` and the exit code is 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL
```

A check that has never been seen failing is not yet evidence of anything.
