# Chapter 11: Surfaces

## Purpose

You may use more than one agent tool: a terminal agent, a desktop app, a browser and an editor. Each tool reads its own instruction file and keeps its own memory of a session. This chapter makes the tools see the same rules, and gives them a plain way to leave messages for each other.

## Part 1: one set of rules

1. `AGENTS.md` holds the shared rules. It is the single source.
2. `CLAUDE.md` is optional. If it exists, it has a line `@AGENTS.md` that imports the shared rules. It adds only notes for Claude Code.
3. `.gemini/settings.json` is optional. If it exists, its `context.fileName` list includes `AGENTS.md`.
4. The layout check fails when `AGENTS.md` is missing or empty.
5. The layout check fails when `CLAUDE.md` exists without the import line.
6. The layout check fails when `CLAUDE.md` repeats a long line from `AGENTS.md`. A copy drifts.
7. The layout check fails when the Gemini file name list leaves out `AGENTS.md`.
8. The layout check fails when `AGENTS.md` is longer than 200 lines. This is the target in the Claude Code memory documentation.

## What the documentation says

These statements come from the tool documentation. The tests in this chapter do not check them.

1. Claude Code reads `AGENTS.md` when no `CLAUDE.md` is present. Otherwise add `@AGENTS.md` to `CLAUDE.md`.
2. Codex CLI joins the `AGENTS.md` files from the project root down to the current folder. The default size limit is 32 KiB.
3. Gemini CLI reads `GEMINI.md`. The setting `context.fileName` can add other names, such as `AGENTS.md`. The Gemini documentation says that Antigravity CLI replaced Gemini CLI for some users on 2026-06-18. Check the product status before you rely on it.
4. `AGENTS.md` is an open format. The Agentic AI Foundation, part of the Linux Foundation, looks after it.

## Part 2: the message exchange

A message is one markdown file. The folder name shows the recipient. Any tool that can write a file can post a message. Any tool that can read a folder can read its inbox.

1. The path is `exchange/to-<recipient>/<time>-<sender>-<hash>.md`.
2. The front matter holds `from`, `to`, `time`, `subject` and `status`. It may hold `re`, the file name of the message that this one answers.
3. The status is `new`, `read` or `done`.
4. A post writes a temporary file and links it into place. A reader never sees half a message. A post never overwrites a message.
5. The exchange check fails on a wrong folder, a bad time or a bad status.
6. It also fails on a file name that disagrees with the message.
7. It fails on a reply to a message that does not exist.

## Protocols as options

A shared folder needs no server. A protocol gives a live call. These protocols exist, and this chapter uses none of them.

1. MCP: the 2026-07-28 revision defines two transports, stdio and Streamable HTTP, both over JSON-RPC.
2. ACP: a protocol between editors and coding agents. Local agents use JSON-RPC over stdio. Remote support is in progress.
3. A2A: an open protocol for agent-to-agent calls. The Linux Foundation hosts it, and Google contributed it. It uses JSON-RPC 2.0 over HTTP or HTTPS.

## Proof that the check can fail

The folder `fixtures/bad` holds a project with four layout problems and an exchange with four message problems. The validator must report all eight.
