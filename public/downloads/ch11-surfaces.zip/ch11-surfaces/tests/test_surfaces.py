import tempfile
import threading
import unittest
from datetime import datetime, timezone
from pathlib import Path

import exchange as ex
import layout

HERE = Path(__file__).resolve().parent.parent
NOW = datetime(2026, 10, 24, 9, 0, 0, tzinfo=timezone.utc)


class ExchangeTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def post(self, **kw):
        args = dict(sender="claude", recipient="codex", subject="S", body="B", now=NOW)
        args.update(kw)
        return ex.post_message(self.root, **args)

    def test_post_creates_a_named_file_in_the_recipient_folder(self):
        path = self.post()
        self.assertEqual(path.parent.name, "to-codex")
        self.assertRegex(path.name, r"^20261024T090000Z-claude-[0-9a-f]{4}\.md$")
        self.assertEqual(ex.check_exchange(self.root), [])

    def test_message_round_trip(self):
        message = ex.parse_message(self.post(subject="Hello", body="Line one.\nLine two."))
        self.assertEqual((message.fields["subject"], message.fields["status"]), ("Hello", "new"))
        self.assertEqual(message.body, "Line one.\nLine two.")

    def test_same_message_at_the_same_second_is_refused_not_overwritten(self):
        self.post()
        with self.assertRaises(FileExistsError):
            self.post()

    def test_no_temporary_file_is_left_behind(self):
        self.post()
        with self.assertRaises(FileExistsError):
            self.post()
        self.assertEqual(list((self.root / "to-codex").glob("*.tmp")), [])

    def test_concurrent_posts_all_land_once(self):
        threads = [threading.Thread(target=self.post, kwargs={"subject": f"S{i}"}) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(len(list((self.root / "to-codex").glob("*.md"))), 8)

    def test_unsafe_names_are_refused(self):
        for bad in ("../x", "A", "a b", ""):
            with self.assertRaises(ValueError, msg=bad):
                self.post(recipient=bad)

    def test_multiline_subject_is_refused(self):
        with self.assertRaises(ValueError):
            self.post(subject="a\nb")

    def test_inbox_filters_by_status_and_set_status_changes_only_the_status(self):
        first = self.post(subject="First")
        self.post(subject="Second", now=datetime(2026, 10, 24, 9, 0, 1, tzinfo=timezone.utc))
        ex.set_status(first, "done")
        self.assertEqual([m.fields["subject"] for m in ex.list_inbox(self.root, "codex", "new")], ["Second"])
        self.assertEqual(ex.parse_message(first).body, "B")

    def test_bad_status_is_refused(self):
        with self.assertRaises(ValueError):
            ex.set_status(self.post(), "maybe")

    def test_empty_inbox(self):
        self.assertEqual(ex.list_inbox(self.root, "nobody"), [])

    def test_unreadable_message_is_reported_not_skipped(self):
        path = self.post()
        path.write_text("no front matter", encoding="utf-8")
        self.assertTrue(ex.check_exchange(self.root))

    def test_example_is_clean_and_bad_has_four_problems(self):
        self.assertEqual(ex.check_exchange(HERE / "example" / "exchange"), [])
        self.assertEqual(len(ex.check_exchange(HERE / "fixtures" / "bad" / "exchange")), 4)


class LayoutTest(unittest.TestCase):
    def project(self, files):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        for name, text in files.items():
            path = Path(tmp.name) / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        return tmp.name

    def test_agents_only_is_fine(self):
        self.assertEqual(layout.check_project(self.project({"AGENTS.md": "rules"})), [])

    def test_missing_or_empty_agents_file(self):
        self.assertTrue(layout.check_project(self.project({"CLAUDE.md": "@AGENTS.md"})))
        self.assertTrue(layout.check_project(self.project({"AGENTS.md": "  \n"})))

    def test_claude_file_must_import_agents(self):
        problems = layout.check_project(self.project({"AGENTS.md": "rules", "CLAUDE.md": "notes"}))
        self.assertEqual(len(problems), 1)

    def test_claude_file_with_import_is_fine(self):
        self.assertEqual(layout.check_project(self.project({"AGENTS.md": "rules", "CLAUDE.md": "@AGENTS.md\nmore"})), [])

    def test_copied_long_lines_are_found_but_short_ones_are_not(self):
        long_line = "Run the full check before you report anything to the user."
        files = {"AGENTS.md": f"{long_line}\nShort.", "CLAUDE.md": f"@AGENTS.md\n{long_line}\nShort."}
        problems = layout.check_project(self.project(files))
        self.assertEqual(len(problems), 1)
        self.assertIn("copies", problems[0])

    def test_gemini_settings_must_include_agents_file(self):
        base = {"AGENTS.md": "rules"}
        ok = layout.check_project(self.project({**base, ".gemini/settings.json": '{"context": {"fileName": ["AGENTS.md"]}}'}))
        string_form = layout.check_project(self.project({**base, ".gemini/settings.json": '{"context": {"fileName": "AGENTS.md"}}'}))
        bad = layout.check_project(self.project({**base, ".gemini/settings.json": '{"context": {"fileName": ["GEMINI.md"]}}'}))
        broken = layout.check_project(self.project({**base, ".gemini/settings.json": "{}"}))
        self.assertEqual((ok, string_form), ([], []))
        self.assertEqual((len(bad), len(broken)), (1, 1))

    def test_long_agents_file_is_flagged(self):
        problems = layout.check_project(self.project({"AGENTS.md": "x\n" * 250}))
        self.assertIn("target", problems[0])

    def test_example_is_clean_and_bad_has_four_problems(self):
        self.assertEqual(layout.check_project(HERE / "example" / "project"), [])
        self.assertEqual(len(layout.check_project(HERE / "fixtures" / "bad" / "project")), 4)


if __name__ == "__main__":
    unittest.main()
