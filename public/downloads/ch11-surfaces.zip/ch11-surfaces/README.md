# ch11-surfaces

This kit is one chapter of the harness case study. It uses only the Python standard library.

Python: 3.9 or newer. `validate.py` prints the Python version it runs under and stops with one line if the version is older than 3.9. The kit was run from a fresh folder under Python 3.9.6, 3.12.8, 3.13.1 and 3.14.5. Versions 3.10 and 3.11 were not tested.

Run every command from this folder. Each command is `python3 -I <file>` or `python3 -I -m unittest`.

## Run it

```sh
python3 -I validate.py  # exit 0; expect: validate: PASS
python3 -I -m unittest discover -s tests -t .  # exit 0; expect: OK
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL
```

The first command checks the example and expects `validate: PASS`. The second runs the unit tests. The third runs the same check on a failing fixture and expects `validate: FAIL` with exit code 1, which proves the check can fail.

Read `SPEC.md` first and `CHAPTER.md` second. The steps in `CHAPTER.md` use only files in this folder. Where a step writes a file, it writes into `scratch/`.

`SHA256SUMS.txt` lists the SHA-256 hash of every other file in this kit.
