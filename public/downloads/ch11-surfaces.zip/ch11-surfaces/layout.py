"""Check the instruction-file layout of a project so that every agent tool reads the same rules.

Layout:
  AGENTS.md              the one place for shared rules
  CLAUDE.md              optional. Imports AGENTS.md with a line "@AGENTS.md" and adds only Claude-specific notes
  .gemini/settings.json  optional. Its context.fileName list must include AGENTS.md

Why: Claude Code reads AGENTS.md by itself only when no CLAUDE.md exists. When both exist, CLAUDE.md must import
AGENTS.md, or the rules fork. Codex reads AGENTS.md. Gemini CLI reads GEMINI.md unless context.fileName says otherwise.
The check also finds long lines that CLAUDE.md copies from AGENTS.md, because a copy drifts.
"""
import argparse
import json
import sys
from pathlib import Path

MIN_COPIED_LINE = 30
LINE_TARGET = 200


def check_project(project):
    project = Path(project)
    agents, claude, gemini = project / "AGENTS.md", project / "CLAUDE.md", project / ".gemini" / "settings.json"
    problems = []
    if not agents.exists() or not agents.read_text(encoding="utf-8").strip():
        return ["AGENTS.md is missing or empty."]
    agent_lines = agents.read_text(encoding="utf-8").splitlines()
    if len(agent_lines) > LINE_TARGET:
        problems.append(f"AGENTS.md has {len(agent_lines)} lines; the documented target is under {LINE_TARGET}.")
    if claude.exists():
        claude_lines = claude.read_text(encoding="utf-8").splitlines()
        if "@AGENTS.md" not in [line.strip() for line in claude_lines]:
            problems.append("CLAUDE.md exists but has no line '@AGENTS.md'. The rules would fork.")
        shared = {line.strip() for line in agent_lines if len(line.strip()) >= MIN_COPIED_LINE}
        copied = [line.strip() for line in claude_lines if line.strip() in shared]
        problems += [f"CLAUDE.md copies a line from AGENTS.md: '{line[:50]}'." for line in copied]
    if gemini.exists():
        try:
            names = json.loads(gemini.read_text(encoding="utf-8"))["context"]["fileName"]
        except (ValueError, KeyError, TypeError):
            return problems + [".gemini/settings.json must hold context.fileName."]
        if "AGENTS.md" not in ([names] if isinstance(names, str) else names):
            problems.append(".gemini/settings.json: context.fileName does not include AGENTS.md.")
    return problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("project")
    project = parser.parse_args(argv).project
    if not Path(project).exists():
        raise FileNotFoundError(2, "No such file or directory", project)
    problems = check_project(project)
    print("\n".join(problems) or "layout: OK")
    return 1 if problems else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"layout: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
