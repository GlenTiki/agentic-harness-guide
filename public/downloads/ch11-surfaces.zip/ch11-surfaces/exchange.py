"""A plain-text inbox and outbox that any tool can use. A message is one markdown file.

Layout:   <root>/to-<recipient>/<YYYYMMDDTHHMMSSZ>-<sender>-<hash4>.md
The folder name is the recipient. A tool that can write a file can post. A tool that can read a folder can listen.

Message file:
    ---
    from: sender-name
    to: recipient-name
    time: 2026-10-24T09:00:00Z
    subject: One line
    status: new            (new, read or done)
    re: <file name of the message this answers>      (optional)
    ---
    Body text.

Safety: a file is written under a temporary name, then linked into place, so a reader never sees half a message
and a post never overwrites an existing message.
"""
import argparse
import hashlib
import os
import re
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

STATUSES = ("new", "read", "done")
NAME = re.compile(r"^[a-z0-9][a-z0-9-]*$")
UTC_SECONDS = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
FILE_NAME = re.compile(r"^(\d{8}T\d{6}Z)-([a-z0-9-]+)-([0-9a-f]{4})\.md$")
REQUIRED = ("from", "to", "time", "subject", "status")


@dataclass(frozen=True)
class Message:
    path: Path
    fields: dict
    body: str


def parse_message(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    if not lines or lines[0] != "---" or "---" not in lines[1:]:
        raise ValueError(f"{path}: the file needs a front matter block.")
    end = lines.index("---", 1)
    fields = {}
    for line in lines[1:end]:
        key, separator, value = line.partition(":")
        if not separator:
            raise ValueError(f"{path}: expected 'key: value', got '{line}'.")
        fields[key.strip()] = value.strip()
    return Message(Path(path), fields, "\n".join(lines[end + 1:]).strip())


def post_message(root, sender, recipient, subject, body, answers=None, now=None):
    for label, value in (("sender", sender), ("recipient", recipient)):
        if not NAME.match(value):
            raise ValueError(f"The {label} name must use lower case letters, digits and hyphens.")
    if not subject.strip() or "\n" in subject:
        raise ValueError("The subject must be one non-empty line.")
    moment = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = moment.strftime("%Y-%m-%dT%H:%M:%SZ")
    short = hashlib.sha256(f"{subject}\n{body}".encode("utf-8")).hexdigest()[:4]
    folder = Path(root) / f"to-{recipient}"
    folder.mkdir(parents=True, exist_ok=True)
    final = folder / f"{moment.strftime('%Y%m%dT%H%M%SZ')}-{sender}-{short}.md"
    lines = ["---", f"from: {sender}", f"to: {recipient}", f"time: {stamp}", f"subject: {subject.strip()}", "status: new"]
    if answers:
        lines.append(f"re: {answers}")
    text = "\n".join(lines + ["---", body.strip(), ""])
    handle, temporary = tempfile.mkstemp(dir=folder, suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            stream.write(text)
        os.link(temporary, final)  # raises FileExistsError instead of overwriting
    finally:
        os.unlink(temporary)
    return final


def list_inbox(root, recipient, status=None):
    folder = Path(root) / f"to-{recipient}"
    messages = [parse_message(p) for p in sorted(folder.glob("*.md"))] if folder.exists() else []
    return [m for m in messages if status is None or m.fields.get("status") == status]


def set_status(path, status):
    if status not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}.")
    message = parse_message(path)
    text = Path(path).read_text(encoding="utf-8")
    updated = re.sub(r"(?m)^status: .*$", f"status: {status}", text, count=1)
    handle, temporary = tempfile.mkstemp(dir=Path(path).parent, suffix=".tmp")
    with os.fdopen(handle, "w", encoding="utf-8") as stream:
        stream.write(updated)
    os.replace(temporary, path)
    return message.fields.get("status")


def check_exchange(root):
    root = Path(root)
    problems, names = [], set()
    files = sorted(root.glob("to-*/*.md"))
    names = {f.name for f in files}
    for path in files:
        label = f"{path.parent.name}/{path.name}"
        match = FILE_NAME.match(path.name)
        if not match:
            problems.append(f"{label}: the file name must be <time>-<sender>-<hash4>.md.")
        try:
            fields = parse_message(path).fields
        except ValueError as error:
            problems.append(str(error))
            continue
        missing = [k for k in REQUIRED if not fields.get(k)]
        if missing:
            problems.append(f"{label}: missing key(s): {', '.join(missing)}.")
            continue
        if fields["to"] != path.parent.name[3:]:
            problems.append(f"{label}: 'to' does not match the folder.")
        if not UTC_SECONDS.match(fields["time"]):
            problems.append(f"{label}: time must be UTC with seconds and a Z.")
        elif match and fields["time"].replace("-", "").replace(":", "") != match.group(1):
            problems.append(f"{label}: the time in the file name differs from the time in the message.")
        if match and fields["from"] != match.group(2):
            problems.append(f"{label}: 'from' differs from the sender in the file name.")
        if fields["status"] not in STATUSES:
            problems.append(f"{label}: status must be new, read or done.")
        if fields.get("re") and fields["re"] not in names:
            problems.append(f"{label}: 're' names a message that does not exist.")
    return problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", default="example/exchange")
    sub = parser.add_subparsers(dest="command", required=True)
    post = sub.add_parser("post")
    for name in ("sender", "recipient", "subject", "body"):
        post.add_argument(name)
    post.add_argument("--re", dest="answers")
    inbox = sub.add_parser("inbox")
    inbox.add_argument("recipient")
    inbox.add_argument("--status")
    sub.add_parser("check")
    args = parser.parse_args(argv)
    if args.command != "post" and not Path(args.root).exists():
        raise FileNotFoundError(2, "No such file or directory", args.root)
    if args.command == "post":
        print(post_message(args.root, args.sender, args.recipient, args.subject, args.body, args.answers).name)
        return 0
    if args.command == "inbox":
        for message in list_inbox(args.root, args.recipient, args.status):
            print(f"{message.path.name}  [{message.fields.get('status')}]  {message.fields.get('subject')}")
        return 0
    problems = check_exchange(args.root)
    print("\n".join(problems) or "exchange: OK")
    return 1 if problems else 0


def run(argv=None):
    try:
        return main(argv)
    except OSError as error:
        print(f"exchange: {error.strerror or error}: {error.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(run())
