# Chapter 11: Surfaces

Weak spot removed: tools cannot see each other. Rules written for one tool are invisible to another, and an answer in one window never reaches the other. Two plain-text conventions fix both without a server.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read `example/project/AGENTS.md`, `CLAUDE.md` and `.gemini/settings.json`.
2. Check the layout. It prints `layout: OK`.
3. Read the two messages in `example/exchange/`. The reply names the first message in its `re` line.
4. List an inbox.
5. Post a message into a scratch folder, then check that folder.
6. Run the validator.

```sh
python3 -I layout.py example/project  # exit 0; expect: layout: OK
python3 -I exchange.py --root example/exchange inbox claude  # exit 0; expect: [new]
mkdir -p scratch
python3 -I exchange.py --root scratch/exchange post claude codex "Please review" "Read notes.py."
python3 -I exchange.py --root scratch/exchange check  # exit 0; expect: exchange: OK
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## Expected output

Step 2 prints `layout: OK`. Step 4 prints one line with the status `new` and the subject of the reply. The validator prints `validate: PASS`.

## One readable error

```sh
python3 -I layout.py no-such-project  # exit 2; expect: layout: No such file or directory
```

## Using it with real tools

Tell each agent in its instruction file how to use the exchange. The shared `AGENTS.md` in the example does this in two lines. A hook from chapter 02 or the monitor from chapter 10 can also watch the folder.

## Honest limits

Verified by tests: the layout check, the message format, the safe write and 8 concurrent posts. Not verified: how any real tool behaves when it reads these files. The statements about Claude Code, Codex and Gemini come from their documentation. Nobody ran this layout in those tools for this chapter. A polling convention is not a real-time channel. An agent only sees a message when it looks. MCP, ACP and A2A are described in the spec and not built.

## Prove the check can fail

Run the validator with `--bad`. It reports eight problems: four in the layout and four in the exchange. It prints `validate: FAIL (8 problem(s))` and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (8 problem(s))
```
