"""Check the example instruction layout and the example message exchange. With --bad, check the broken copies.

Usage: python3 -I validate.py [--bad]
"""
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exchange  # noqa: E402
import layout  # noqa: E402


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    if "--bad" in argv:
        project, root = HERE / "fixtures/bad/project", HERE / "fixtures/bad/exchange"
    else:
        project, root = HERE / "example/project", HERE / "example/exchange"
    problems = layout.check_project(project) + exchange.check_exchange(root)
    for problem in problems:
        print(f"FAIL {problem}")
    print("validate: PASS" if not problems else f"validate: FAIL ({len(problems)} problem(s))")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
