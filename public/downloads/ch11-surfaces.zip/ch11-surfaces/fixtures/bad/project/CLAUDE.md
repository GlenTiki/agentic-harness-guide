# Claude notes

1. Write a failing test before you write code.
2. Run `./check.sh` before you report. Quote its last line.
Write specs in simple English. Keep sentences short and active.
