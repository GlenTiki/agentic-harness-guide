@AGENTS.md

## Claude Code notes

Hooks in `.claude/settings.json` enforce the rules above. Subagents follow the same file.
