# Notes tool

Plain-text notes tool. One note on each line of a text file.

## Rules for every agent

1. Write a failing test before you write code.
2. Run `./check.sh` before you report. Quote its last line.
3. Write specs in simple English. Keep sentences short and active.
4. Do not push, delete data or edit `check.sh`.

## Where to talk to other tools

Post a message in `exchange/to-<name>/`. Read your own inbox in `exchange/to-<your-name>/`.
