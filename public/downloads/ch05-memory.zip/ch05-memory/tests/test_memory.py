import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import memory
import validate

HERE = Path(__file__).resolve().parent.parent


def doc(name="n", description="d", type_="fact", tags="a, b", updated="2026-09-01T09:00:00Z", body="body text"):
    return f"---\nname: {name}\ndescription: {description}\ntype: {type_}\ntags: {tags}\nupdated: {updated}\n---\n{body}\n"


class ParseTest(unittest.TestCase):
    def test_parses_fields(self):
        m = memory.parse_memory(doc())
        self.assertEqual((m.name, m.tags, m.body), ("n", ("a", "b"), "body text"))

    def test_missing_front_matter_raises_with_path(self):
        with self.assertRaisesRegex(memory.MemoryFormatError, "x.md"):
            memory.parse_memory("hello", "x.md")

    def test_missing_key_raises(self):
        with self.assertRaisesRegex(memory.MemoryFormatError, "type"):
            memory.parse_memory("---\nname: a\ndescription: b\nupdated: 2026-09-01T09:00:00Z\n---\nx")

    def test_time_must_be_utc_seconds_z(self):
        for bad in ("2026-09-01", "2026-09-01T09:00Z", "2026-09-01T09:00:00+01:00"):
            with self.assertRaises(memory.MemoryFormatError, msg=bad):
                memory.parse_memory(doc(updated=bad))

    def test_unclosed_front_matter(self):
        with self.assertRaises(memory.MemoryFormatError):
            memory.parse_memory("---\nname: a\n")

    def test_tags_are_optional_and_absent_is_empty_tuple(self):
        text = "---\nname: a\ndescription: b\ntype: c\nupdated: 2026-09-01T09:00:00Z\n---\nx"
        self.assertEqual(memory.parse_memory(text).tags, ())


class LoadAndSelectTest(unittest.TestCase):
    def folder(self, files):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        for name, text in files.items():
            (Path(tmp.name) / name).write_text(text, encoding="utf-8")
        return tmp.name

    def test_bad_file_is_not_skipped_silently(self):
        with self.assertRaises(memory.MemoryFormatError):
            memory.load_memories(self.folder({"a.md": doc(), "b.md": "junk"}))

    def test_duplicate_names_raise(self):
        with self.assertRaisesRegex(memory.MemoryFormatError, "Duplicate"):
            memory.load_memories(self.folder({"a.md": doc(), "b.md": doc()}))

    def test_budget_is_never_exceeded(self):
        memories = memory.load_memories(self.folder({f"{i}.md": doc(name=f"m{i}", body="shared word " * 40) for i in range(6)}))
        chosen, used = memory.select("shared word", memories, budget_tokens=300, max_items=10)
        self.assertLessEqual(used, 300)
        self.assertGreater(len(chosen), 0)
        self.assertLess(len(chosen), 6)

    def test_max_items_is_respected(self):
        memories = memory.load_memories(self.folder({f"{i}.md": doc(name=f"m{i}", body="shared") for i in range(6)}))
        self.assertEqual(len(memory.select("shared", memories, 10_000, max_items=2)[0]), 2)

    def test_irrelevant_prompt_selects_nothing(self):
        memories = memory.load_memories(self.folder({"a.md": doc(body="apples")}))
        self.assertEqual(memory.select("volcano", memories)[0], [])

    def test_same_prompt_same_selection_every_time(self):
        memories = memory.load_memories(HERE / "example" / "memories")
        runs = {tuple((m.name, round(s, 9)) for m, s in memory.select("commit message for this change", memories)[0])
                for _ in range(10)}
        self.assertEqual(len(runs), 1)

    def test_token_estimate_rounds_up(self):
        self.assertEqual([memory.estimate_tokens(t) for t in ("", "a", "abcd", "abcde")], [0, 1, 1, 2])


class RecallLogTest(unittest.TestCase):
    def test_log_line_has_utc_seconds_hash_and_no_prompt_text(self):
        memories = memory.load_memories(HERE / "example" / "memories")
        chosen, used = memory.select("commit message", memories)
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "log.jsonl"
            memory.log_recall(log, "commit message", chosen, used, 400, now=datetime(2026, 1, 2, 3, 4, 5, tzinfo=timezone.utc))
            memory.log_recall(log, "commit message", chosen, used, 400)
            lines = log.read_text(encoding="utf-8").splitlines()
        first = json.loads(lines[0])
        self.assertEqual(first["time"], "2026-01-02T03:04:05Z")
        self.assertEqual(len(first["prompt_sha256"]), 64)
        self.assertNotIn("commit message", lines[0])
        self.assertEqual(len(lines), 2)


class ValidateTest(unittest.TestCase):
    def test_example_is_clean_and_golden_passes(self):
        self.assertEqual(validate.check_files(HERE / "example" / "memories"), [])
        golden = json.loads((HERE / "example" / "golden.json").read_text(encoding="utf-8"))
        self.assertEqual(validate.check_golden(HERE / "example" / "memories", golden), [])

    def test_bad_folder_reports_every_problem(self):
        errors = validate.check_files(HERE / "fixtures" / "bad" / "memories")
        self.assertEqual(len(errors), 5)


if __name__ == "__main__":
    unittest.main()
