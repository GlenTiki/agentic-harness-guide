import unittest

import bm25


class BM25Test(unittest.TestCase):
    def setUp(self):
        self.index = bm25.BM25Index(["apple banana", "banana", "cherry"])

    def test_known_score_by_hand(self):
        # idf = ln(1 + 2.5/1.5) = 0.98083; length norm = 0.25 + 0.75 * 2/1.3333 = 1.375
        # score = 0.98083 * 2.5 / (1 + 1.5 * 1.375) = 0.8007
        self.assertAlmostEqual(self.index.score("apple", 0), 0.8007, places=4)

    def test_shorter_document_wins_on_equal_term_frequency(self):
        self.assertEqual([i for i, _ in self.index.rank("banana")], [1, 0])

    def test_unknown_term_scores_zero_and_is_not_ranked(self):
        self.assertEqual(self.index.rank("zebra"), [])

    def test_stopwords_are_ignored(self):
        self.assertEqual(bm25.tokenize("The cat and the hat"), ["cat", "hat"])

    def test_idf_is_never_negative(self):
        index = bm25.BM25Index(["a b", "a c", "a d"])
        self.assertGreaterEqual(index.idf("a"), 0)

    def test_ties_break_by_document_order(self):
        index = bm25.BM25Index(["same words", "same words"])
        self.assertEqual([i for i, _ in index.rank("same")], [0, 1])

    def test_empty_index(self):
        self.assertEqual(bm25.BM25Index([]).rank("anything"), [])

    def test_repeat_runs_are_identical(self):
        runs = {tuple(self.index.rank("apple banana cherry")) for _ in range(20)}
        self.assertEqual(len(runs), 1)


if __name__ == "__main__":
    unittest.main()
