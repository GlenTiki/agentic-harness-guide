"""Check every memory file, then check the golden recall cases. With --bad, check the broken memory folder.

Usage: python3 -I validate.py [--bad]
"""
import json
import platform
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import memory  # noqa: E402


def check_files(folder):
    errors, names = [], []
    for path in sorted(Path(folder).glob("*.md")):
        try:
            names.append(memory.parse_memory(path.read_text(encoding="utf-8"), path.name).name)
        except memory.MemoryFormatError as error:
            errors.append(str(error))
    errors += [f"Duplicate memory name: {n}" for n in sorted({n for n in names if names.count(n) > 1})]
    return errors


def check_golden(folder, golden):
    errors = []
    memories = memory.load_memories(folder)
    for case in golden["cases"]:
        chosen, _ = memory.select(case["prompt"], memories, golden["budget_tokens"])
        names = [m.name for m, _ in chosen]
        if case.get("expect_none") and names:
            errors.append(f"'{case['prompt']}': expected no memory, got {names}")
        if "expect_first" in case and (not names or names[0] != case["expect_first"]):
            errors.append(f"'{case['prompt']}': expected {case['expect_first']} first, got {names}")
    return errors


MIN_PYTHON = (3, 9)


def main(argv):
    if sys.version_info < MIN_PYTHON:
        print(f"validate: needs Python 3.9 or newer; this is {platform.python_version()}.", file=sys.stderr)
        return 1
    print(f"python: {platform.python_version()}")
    bad = "--bad" in argv
    folder = HERE / ("fixtures/bad/memories" if bad else "example/memories")
    errors = check_files(folder)
    if not errors and not bad:
        errors = check_golden(folder, json.loads((HERE / "example" / "golden.json").read_text(encoding="utf-8")))
    for error in errors:
        print(f"FAIL {error}")
    print("validate: PASS" if not errors else f"validate: FAIL ({len(errors)} problem(s))")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
