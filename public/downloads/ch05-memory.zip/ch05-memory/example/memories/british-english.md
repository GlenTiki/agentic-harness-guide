---
name: british-english
description: The user writes in British English.
type: preference
tags: language, writing, spelling
updated: 2026-09-01T09:00:00Z
---
Use British spelling: colour, organise, behaviour. Dates are written day first. Do not switch to American spelling in documents or commit messages.
