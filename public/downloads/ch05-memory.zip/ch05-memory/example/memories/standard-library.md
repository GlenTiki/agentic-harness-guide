---
name: standard-library
description: Prefer the Python standard library.
type: preference
tags: python, dependencies, simplicity
updated: 2026-09-06T09:00:00Z
---
Add a third party package only when the standard library cannot do the job. Say why in the pull request.
