---
name: review-checklist
description: The review checklist for every pull request.
type: procedure
tags: review, quality, pull-request
updated: 2026-09-08T09:00:00Z
---
Check the tests, the error messages, the names and the docs. Ask what happens on empty input, on retries and on a crash half way through.
