---
name: tests-first
description: The user wants a failing test before the code.
type: preference
tags: testing, tdd, quality
updated: 2026-09-03T09:00:00Z
---
Write the failing test first, run it and watch it fail. Then write the code that makes it pass. A test never seen failing is not trusted.
