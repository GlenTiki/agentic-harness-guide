---
name: plain-text-first
description: The user prefers plain text files over databases.
type: preference
tags: storage, files, simplicity
updated: 2026-09-05T09:00:00Z
---
Keep data in plain text files that a person can read and diff. Choose boring tools that will still work in ten years.
