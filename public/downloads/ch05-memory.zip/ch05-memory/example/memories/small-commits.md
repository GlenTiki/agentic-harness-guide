---
name: small-commits
description: The user wants small, single-purpose commits.
type: preference
tags: git, commits, review
updated: 2026-09-02T09:00:00Z
---
Each commit holds one logical change. The message says what changed and why. Do not mix a refactor with a feature in one commit.
