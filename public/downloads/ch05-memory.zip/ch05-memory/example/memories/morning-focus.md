---
name: morning-focus
description: The user does deep work in the morning.
type: fact
tags: calendar, meetings, focus
updated: 2026-09-07T09:00:00Z
---
Do not schedule meetings before midday. Batch questions for the afternoon. Morning is for writing and design.
