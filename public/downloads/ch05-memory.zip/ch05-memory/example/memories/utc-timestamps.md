---
name: utc-timestamps
description: Store every time stamp in UTC with seconds.
type: fact
tags: time, dates, storage, logs
updated: 2026-09-04T09:00:00Z
---
Use ISO 8601 UTC with seconds and a Z suffix, such as 2026-10-01T10:00:00Z. Convert to local time only when showing a value to a person.
