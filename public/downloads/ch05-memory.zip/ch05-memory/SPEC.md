# Chapter 05: Memory

## Purpose

This chapter lets the agent remember the user. Memory lives in plain text files. A loader picks a small set of files for each prompt.

## The memory file

A memory file is a markdown file with a front matter block. The block starts and ends with a line of three hyphens. Each line in the block has a key, a colon and a value.

1. `name` is a short unique name.
2. `description` is one line that says what the memory is for.
3. `type` names the kind of memory, such as preference, fact or procedure.
4. `updated` is a UTC time with seconds and a Z at the end.
5. `tags` is an optional list, separated by commas.

The body follows the block.

## The loader

1. The loader reads every memory file in a folder.
2. The loader refuses a bad file and names its path. It never skips a bad file in silence.
3. The loader ranks the memories against the prompt with BM25. BM25 is a fixed formula, so the same input gives the same ranking.
4. The loader adds memories from the top of the ranking until the token budget is full.
5. The loader adds no memory with a score of zero.

The loader counts one token for every four characters. This is a rough estimate. It is not a real tokenizer.

## The recall log

The loader can append one line of JSON to a log for each recall. The line holds the UTC time, the SHA-256 hash of the prompt, the names and scores of the chosen memories, and the tokens used. The log does not hold the prompt text.

## Why filters save tokens

A prompt that matches nothing loads nothing. A budget caps the cost of a prompt that matches many files.

## Proof that the check can fail

The folder `fixtures/bad/memories` holds six broken files. Two of them share a name. The validator must report five problems.
