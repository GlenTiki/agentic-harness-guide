# Chapter 05: Memory

Weak spot removed: the agent forgets you. Preferences stated once should apply next week, without you repeating them and without loading every note into every prompt.

Run every command from the kit folder, the one that holds this file. The steps write only into `scratch/`.

## Steps

1. Read the eight files in `example/memories/`. Each is a plain text file you could edit by hand.
2. Read `bm25.py`. It is about 40 lines and follows the published formula.
3. Recall for a prompt. The log goes to `scratch/`.
4. Read the log line it wrote.
5. Run the validator. It checks every file and six golden prompts in `example/golden.json`.

```sh
mkdir -p scratch
python3 -I memory.py "Write the commit message for this change" --dir example/memories --log scratch/recall.jsonl  # exit 0; expect: small-commits
python3 -I -c "print(open('scratch/recall.jsonl').read())"  # exit 0; expect: prompt_sha256
python3 -I validate.py  # exit 0; expect: validate: PASS
```

## Expected output

Step 3 prints three memories, headed `small-commits`, `tests-first` and `british-english`, and `-- 3 memories, about 149 of 400 tokens` on stderr. The validator prints `validate: PASS`.

## One readable error

```sh
python3 -I memory.py "x" --dir no-such-folder  # exit 2; expect: memory: No such file or directory
```

## Honest limits

BM25 matches words, not meaning. A prompt about "tidy history" will not find a memory about "small commits". The next chapter measures that gap. You can see it now: the golden prompt says "time stamp" because the same prompt with "timestamp" returns the `standard-library` memory (it matches the word "add") and misses `utc-timestamps`, which writes "time stamp" with a space. This was observed when the chapter was built. The token count is an estimate of four characters per token.

## Prove the check can fail

Run the validator with `--bad`. It reports five problems (a line with no colon, a time in the wrong format, a file with no front matter, a missing key and a duplicate name) and exits with code 1.

```sh
python3 -I validate.py --bad  # exit 1; expect: validate: FAIL (5 problem(s))
```
