---
name: bad-time
description: wrong time format
type: fact
updated: 2026-09-01 09:00
---
body
