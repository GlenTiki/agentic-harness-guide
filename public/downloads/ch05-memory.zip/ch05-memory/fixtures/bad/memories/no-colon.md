---
name: no-colon
description: broken line
type: fact
updated: 2026-09-01T09:00:00Z
this line has no colon
---
body
